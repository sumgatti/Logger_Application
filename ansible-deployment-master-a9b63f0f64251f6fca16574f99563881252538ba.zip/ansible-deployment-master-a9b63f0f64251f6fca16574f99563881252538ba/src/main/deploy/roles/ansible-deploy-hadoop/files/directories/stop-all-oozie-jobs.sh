#!/usr/bin/env bash

# check and wait for running jobs to finish
running=$(oozie jobs | grep RUNNING | awk '{print $1}' )
#while [[ -n "${running}" ]]; do
#    sleep 5m
#    running=$(oozie jobs | grep RUNNING | awk '{print $1}' )
#done
#date && echo "All running jobs have ended."
if [[ -n "${running}" ]]; then
    for job in ${running}; do
        oozie job -suspend ${job}
    done
    echo SUSPENDED jobs
fi