#!/usr/bin/env bash

local_dir=$1
hdfs_dir=$2

trigger=${hdfs_dir}/bundle/bundle
echo "RUN ${trigger}.xml"
hdfs dfs -chmod -R ug+x ${hdfs_dir}
oozie job -run -verbose -config ${local_dir}/bundle/job.properties -Doozie.bundle.application.path="${trigger}.xml"

