#!/usr/bin/env bash

project=$1

job_ids=$(oozie jobs -jobtype bundle | grep ${project} | grep RUNNING | awk '{print $1}' )
if [[ -n "${job_ids}" ]]; then
    for job_id in ${job_ids}; do
        echo "DECOMMISSION running job: ${job_id}" && oozie job -kill ${job_id} -value endtime=$(date +%Y-%m-%dT%H:%MZ)
    done
fi
