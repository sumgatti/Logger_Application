#!/usr/bin/env bash

# Set ownership for hadoop_deploy and cdhprd001_admin as group
hdfs dfs -chown -R hadoop_deploy:cdhprd001_admin /process
hdfs dfs -chown -R hadoop_deploy:cdhprd001_admin /storehouse
hdfs dfs -chown -R hadoop_deploy:cdhprd001_admin /app

# Set HDFS ACLs
# - Delete Previous ACLs
hdfs dfs -setfacl -R -k /storehouse
hdfs dfs -setfacl -R -b /storehouse
hdfs dfs -setfacl -R -k /process
hdfs dfs -setfacl -R -b /process
hdfs dfs -setfacl -R -k /app
hdfs dfs -setfacl -R -b /app


# permissions for hadoop deploy on /storehouse, /process, /app
hdfs dfs -setfacl -R -m user:hadoop_deploy:rwx /storehouse
hdfs dfs -setfacl -R -m user:hadoop_deploy:rwx /process
hdfs dfs -setfacl -R -m user:hadoop_deploy:rwx /app
hdfs dfs -setfacl -R -m default:user:hadoop_deploy:rwx /storehouse
hdfs dfs -setfacl -R -m default:user:hadoop_deploy:rwx /process
hdfs dfs -setfacl -R -m default:user:hadoop_deploy:rwx /app

# permissions for hive on /storehouse and /process
hdfs dfs -setfacl -R -m user:hive:rwx /storehouse
hdfs dfs -setfacl -R -m user:hive:rwx /process
hdfs dfs -setfacl -R -m default:user:hive:rwx /storehouse
hdfs dfs -setfacl -R -m default:user:hive:rwx /process

# permissions for impala on /storehouse and /process
hdfs dfs -setfacl -R -m user:impala:rwx /storehouse
hdfs dfs -setfacl -R -m user:impala:rwx /process
hdfs dfs -setfacl -R -m default:user:impala:rwx /storehouse
hdfs dfs -setfacl -R -m default:user:impala:rwx /process

# permissions for cdhprd001_admin group on /storehouse, /process, /app
hdfs dfs -setfacl -R -m group:cdhprd001_admin:r-x /storehouse
hdfs dfs -setfacl -R -m group:cdhprd001_admin:r-x /process
hdfs dfs -setfacl -R -m group:cdhprd001_admin:r-x /app
hdfs dfs -setfacl -R -m default:group:cdhprd001_admin:r-x /storehouse
hdfs dfs -setfacl -R -m default:group:cdhprd001_admin:r-x /process
hdfs dfs -setfacl -R -m default:group:cdhprd001_admin:r-x /app

# permissions for cdhprd001_dev group on /storehouse, /process, /app
hdfs dfs -setfacl -R -m group:cdhprd001_dev:r-x /storehouse
hdfs dfs -setfacl -R -m group:cdhprd001_dev:r-x /process
hdfs dfs -setfacl -R -m group:cdhprd001_dev:r-x /app
hdfs dfs -setfacl -R -m default:group:cdhprd001_dev:r-x /storehouse
hdfs dfs -setfacl -R -m default:group:cdhprd001_dev:r-x /process
hdfs dfs -setfacl -R -m default:group:cdhprd001_dev:r-x /app

# permissions for cdhprd001_business group on /storehouse, /process, /app
hdfs dfs -setfacl -R -m group:cdhprd001_business:r-x /storehouse
hdfs dfs -setfacl -R -m group:cdhprd001_business:r-x /process
hdfs dfs -setfacl -R -m group:cdhprd001_business:--- /app
hdfs dfs -setfacl -R -m default:group:cdhprd001_business:r-x /storehouse
hdfs dfs -setfacl -R -m default:group:cdhprd001_business:r-x /process
hdfs dfs -setfacl -R -m default:group:cdhprd001_business:--- /app