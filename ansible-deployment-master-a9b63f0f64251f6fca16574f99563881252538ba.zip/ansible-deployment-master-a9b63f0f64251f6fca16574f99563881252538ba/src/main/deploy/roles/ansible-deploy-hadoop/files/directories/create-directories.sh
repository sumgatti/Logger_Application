#!/usr/bin/env bash

current=$1

echo "UPDATING scripts and libraries"
shopt -s dotglob
#       current=${tmp_directory}/${artifact_id}-${version}

    rmput() {
        for i in "$1"/*;do
            scr=$(echo $i | sed "s:${current}::" )
            if [ -d "$i" ];then
                rmput "$i"
            elif [ -f "$i" ]; then
                if [[ $(basename "$i") == ".ignore" ]]; then
                    echo "CREATE $(echo $(dirname $i) | sed "s:${current}::")"
                    hdfs dfs -mkdir -p $(echo $(dirname $i) | sed "s:${current}::" )
                elif [[ $(basename "$i") != ".ignore" ]]; then
                    echo "UPDATE ${scr}"
                    hdfs dfs -rm -f ${scr}
                    hdfs dfs -put $i ${scr}
                fi
            fi
        done
    }
        rmput ${current}
shopt -u dotglob
