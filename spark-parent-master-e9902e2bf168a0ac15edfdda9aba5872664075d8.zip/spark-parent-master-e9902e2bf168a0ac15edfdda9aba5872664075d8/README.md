# Spark Parent

The spark parent project provides all the dependencies needed to create spark artifacts and publish them to our TFS package manager.

It provides the dependencies needed to successfully run spark in the cluster

It provides test dependencies needed to create spark unit tests

Provides configurations on how to build the project and create reports.

### Usage

To use the spark-parent add the following to your pom.xml

```xml
<project>
...
    <parent>
        <groupId>ie.esb.ei.bi.datalake</groupId>
        <artifactId>spark-parent</artifactId>
        <version>1.0</version>
    </parent>
...
</project>

```