package ie.esb.datalake.commons

/**
  * Created by Sabater_A on 24/08/2017.
  */

import ie.esb.datalake.commons.Environment.Env
import org.apache.log4j.{LogManager, Logger}

import sys.process._
import scala.util.{Failure, Success, Try}

object Environment {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  object Env extends Enumeration {
    type Env = Value
    val PROD = Value("prod")
    val TEST = Value("test")
    val DEV = Value("dev")
  }

  def parseEnv(envHint: String): Env.Value = {
    log.info(s"The ENV to be parsed is: ${envHint}")
    val env = envHint match {
      case "head" => Env.PROD
      case "datc" => Env.TEST
      case _ => Env.DEV
    }
    log.info(s"The selected ENV is: ${env.toString}")
    env
  }

  def getServiceName(shell: shell = new shell): String = {
    val pattern = "(?i)(?s)(datc|head)rhl\\d{3}.*".r
    val shellCmd: String = shell.hdfsReportCapture
    log.info(s"The output of the hdfs dfsadmin command is: ${shellCmd}")
    shell.hdfsReportCapture match {
      case pattern(env) => env
      case _ => ""
    }
  }

  def current: Env.Value = parseEnv(getServiceName())

  def master(env: Env.Value) = {
    log.info("Master is: " + env);
    env match {
      case Env.PROD => "yarn-cluster"
      case Env.TEST => "yarn-cluster"
      case Env.DEV => "local"
    }
  }

}

class shell {
  //def hdfsReportCapture: String = Try("hdfs dfsadmin -report" #| "grep Hostname" #| "head -n 1" !!) match {
  def hdfsReportCapture: String = Try("hostname" !!) match {
    case Success(s) => s
    case Failure(f) => ""
  }
}

