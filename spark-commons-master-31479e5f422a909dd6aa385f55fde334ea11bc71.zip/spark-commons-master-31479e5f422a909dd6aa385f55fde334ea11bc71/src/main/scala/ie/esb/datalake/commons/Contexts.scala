package ie.esb.datalake.commons

import ie.esb.datalake.commons.Environment.getClass
import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import ie.esb.datalake.commons.LoadedProperties._
import org.apache.log4j.{LogManager, Logger}

/**
  * Created by Sabater_A on 24/08/2017.
  */
object Contexts {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  private val appId = conf.getString("application.id")
  private val master: String = Environment.master(Environment.current)

  log.info(s"The application id is: ${appId}")
  log.info(s"The spark master is: ${master}")

  //private lazy val sparkConf = new SparkConf()
  lazy val sparkConf = new SparkConf()
    .setAppName(appId)
    .setMaster(master)
    .set("spark.yarn.app.id", appId + "_" + System.currentTimeMillis() / 1000)
    .set("spark.sql.parquet.compression.codec", "snappy")

  lazy val sc: SparkContext = new SparkContext(sparkConf)
  lazy val sqlCtx: SQLContext = new SQLContext(sc)

}
