package ie.esb.datalake.commons

import java.io.FileNotFoundException

import com.typesafe.config.{Config, ConfigException, ConfigFactory}
import ie.esb.datalake.commons.Environment.Env
import org.apache.log4j.{LogManager, Logger}

import scala.util.{Failure, Success, Try}

/**
  * Created by Sabater_A on 24/08/2017.
  */
object LoadedProperties {

  lazy val masterConf = ConfigFactory.load()
  lazy val conf = masterConf.withFallback(ConfigFactory.parseResources(envSpecific)).resolve()
  lazy val log: Logger = LogManager.getLogger(getClass)

  private def envSpecific = {
    lazy val env = Environment.current
    "conf/" + env + "/app.conf"
  }

  def fromFile(src: String, env: Option[Env.Value]): Config = {
    val propFile = src + ".conf"
    val envStr: String = if (env.isDefined) env.get.toString else "NOT-SET"
    log.info(s"Looking for property file: ${propFile}")
    log.info(s"Environment: ${envStr}")
    val conf = Try({
      val load = ConfigFactory.parseResources(propFile)
      if(env.isDefined) load.getConfig(envStr) else load
    }) match {
      case Success(s) => s
      case Failure(f) => log.error(f.getMessage); ConfigFactory.empty()
    }
    conf.isEmpty match {
      case true => throw new FileNotFoundException(s"File ${propFile} not found")
      case false => conf
    }
  }
}
