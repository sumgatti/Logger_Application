package ie.esb.datalake.commons

import ie.esb.datalake.commons.Environment.Env
import org.mockito.Mockito
import org.scalatest.junit.JUnitRunner
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 24/08/2017.
  */

class EnvironmentTest extends FlatSpec with Matchers {

  "getServiceName" should "get the cluster" in {
    val shellMock = Mockito.mock(classOf[shell])
    val a: String = System.getProperty("runpath")
    println(a)
    val expectedResult = "headrhl012s.cld1.tld.int"
    Mockito.when(shellMock.hdfsReportCapture) thenReturn expectedResult
    val result = Environment.getServiceName(shellMock)
    result shouldEqual "head"
  }

  "parseEnv" should "detect a production environment" in {
    val shellMock = Mockito.mock(classOf[shell])
    val expectedResult = "headrhl012s.cld1.tld.int"
    Mockito.when(shellMock.hdfsReportCapture) thenReturn expectedResult
    val env = Environment.getServiceName(shellMock)
    val result = Environment.parseEnv(env)
    result shouldEqual Env.PROD
  }

  "parseEnv" should "detect a test environment" in {
    val shellMock = Mockito.mock(classOf[shell])
    val expectedResult = "datcrhl004s.cld1.tld.int"
    Mockito.when(shellMock.hdfsReportCapture) thenReturn expectedResult
    val env = Environment.getServiceName(shellMock)
    val result = Environment.parseEnv(env)
    result shouldEqual Env.TEST
  }

  "parseEnv" should "detect a development environment" in {
    val shellMock = Mockito.mock(classOf[shell])
    val expectedResult = "Unknown"
    Mockito.when(shellMock.hdfsReportCapture) thenReturn expectedResult
    val env = Environment.getServiceName(shellMock)
    val result = Environment.parseEnv(env)
    result shouldEqual Env.DEV
  }

  "master" should "return a YARN master" in {
    val resultProd = Environment.master(Env.PROD)
    val resultTest = Environment.master(Env.TEST)
    val resultDev = Environment.master(Env.DEV)
    resultProd shouldEqual "yarn-cluster"
    resultTest shouldEqual "yarn-cluster"
    resultDev shouldEqual "local"
  }
}
