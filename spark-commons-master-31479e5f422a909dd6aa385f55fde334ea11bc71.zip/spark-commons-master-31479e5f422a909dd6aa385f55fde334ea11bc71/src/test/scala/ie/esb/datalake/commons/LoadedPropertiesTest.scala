package ie.esb.datalake.commons

import java.io.FileNotFoundException

import com.typesafe.config.Config
import org.scalatest.{FlatSpec, Matchers}
import ie.esb.datalake.commons.LoadedProperties._
import ie.esb.datalake.commons.Environment.Env._

/**
  * Created by Sabater_A on 24/08/2017.
  */
class LoadedPropertiesTest extends FlatSpec with Matchers {

  "Properties" should "load" in {
    val env = Environment.current

    val cluster = env.toString match {
      case "prod" => "CDHPRD001"
      case "test" => "CDHTST001"
      case "dev" => "local"
    }

    conf.getString("application.id") shouldEqual "NOT-SET"
    conf.getString(s"${env.toString}.cluster") shouldEqual cluster
  }

  "Properties" should "load different property files" in {
    val app = fromFile("reference", None)
    val devEnv = fromFile("env-test", Some(DEV))
    val tstEnv = fromFile("env-test", Some(TEST))
    val prdEnv = fromFile("env-test", Some(PROD))

    app.getString("application.id") shouldEqual "NOT-SET"
    app shouldBe a[Config]
    devEnv.getString("master") shouldEqual "local"
    tstEnv.getString("master") shouldEqual "yarn-cluster"
    prdEnv.getString("master") shouldEqual "yarn-cluster"
    intercept[FileNotFoundException] {
      fromFile("NOT-SET", None)
    }.getMessage shouldEqual "File NOT-SET.conf not found"
  }
}
