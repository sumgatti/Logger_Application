drop table if exists ods.attributes_residential;

create table ods.attributes_residential
STORED AS PARQUET
LOCATION '/data/ods/attributes/attributes_residential'
AS
SELECT distinct bp.partner businesspartnerno, lpad(cast(ca.contractaccountno as string),12,"0") contractaccountno,
cast(co.contractno as bigint) contractno, cast(te.mprn as string) mprn, cast(te.technicalinstallationno as bigint) technicalinstallationno,
(case when to_date(bp.partnerbirthdate) = '1900-01-01' then 0
      when to_date(bp.partnerbirthdate) is null then 0
      when bp.partnerbirthdate > current_timestamp() then 0
      when (year(current_date) - year(to_date(bp.partnerbirthdate))) > 90 then 0
      when (year(current_date) - year(to_date(bp.partnerbirthdate))) < 18 then 0
      else year(current_date) - year(to_date(bp.partnerbirthdate)) end) as age,
(case when to_date(bp.partnerbirthdate) = '1900-01-01' then 0
      when to_date(bp.partnerbirthdate) is null then 0
      when bp.partnerbirthdate > current_timestamp() then 0
      when (year(current_date) - year(to_date(bp.partnerbirthdate))) > 90 then 0
      when (year(current_date) - year(to_date(bp.partnerbirthdate))) < 18 then 0
      else 1 end) as has_ValidAge,
(case when bp.partneremail like '%.%' and bp.partneremail like '%@%' then 1
      else 0 end ) has_ValidEmail,
bp.hasMobile has_mobile,
bp.hasvalidLandline as validLandline,
regexp_replace(TRIM(bp.city1), '[0-9]+$', '') as bpcounty,
(case when bp.PARTNERTITLE = ' '  or  bp.PARTNERTITLE = 'Unknown' then 0
      when bp.PARTNERTITLE is null then 0 else 1 end) as has_title,
bp.idorigin,
(case when bp.firstname = ' ' or bp.firstname = '' or bp.firstname = 'Unknown' then 0 when bp.firstname is null then 0 else 1 end) has_firstname,
(case when bp.lastname = ' ' or bp.lastname = ''or bp.lastname = 'Unknown' then 0 when bp.lastname is null then 0 else 1 end) has_lastname,
ca.dunningprocedure, ca.city1 as ca_county,
(case when ca.languagetype = '(' then 1 else 0 end) as irish_flag,
(case when bp.ebillflag = 'X' then 1
 else 0 end) as ebilling_flag,
case when (length(trim(bp.housenum1)) +length(trim(bp.housenum2)) + length(trim(bp.housenum2)) + length(trim(bp.street)) + length(trim(bp.STREETSUPPL1))
+ length(trim(bp.STREETSUPPL2)) + length(trim(bp.STREETSUPPL3)) + length(trim(bp.city1))) > 10 then 1 else 0 end has_BPAddress,
case when (length(trim(ca.housenum1)) +length(trim(ca.housenum2)) + length(trim(ca.housenum2)) + length(trim(ca.street)) + length(trim(ca.STREETSUPPL1))
+ length(trim(ca.STREETSUPPL2)) + length(trim(ca.STREETSUPPL3)) + length(trim(ca.city1))
) > 10 then 1 else 0 end has_ca_Address,
(case when ca.contractaccountname = '' or ca.contractaccountname = ' ' then 0
       when ca.contractaccountname is null then 0 else 1 end) as has_caName,
co.contractstartdate as moveindate, co.contractenddate as moveoutdate,
case when to_date(co.moveoutdate) >= to_date(current_date()) then 1
     when to_date(co.moveoutdate) < to_date(current_date()) then 0
     else '' end LiveFlag,
(case when to_date(co.moveoutdate) = '9999-12-31' then cast(months_between(to_date(current_date()), to_date(co.moveindate)) as DECIMAL(14,2))
      else cast(months_between(to_date(co.moveoutdate), to_date(co.moveindate)) as DECIMAL(14,2)) end) as total_tenure,
(case when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) <= 3 then '0 - 3 Mths'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 3 and months_between(to_date(current_date()),co.moveindate ) <= 6 then '3 - 6months'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 6 and months_between(to_date(current_date()),co.moveindate ) <= 12 then '6 - 12months'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 12 and months_between(to_date(current_date()),co.moveindate ) <= 18 then '12 - 18months'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 18 and months_between(to_date(current_date()),co.moveindate ) <= 24 then '18 - 24months'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 24 and months_between(to_date(current_date),co.moveindate ) <= 60 then '2 - 5years'
      when to_date(co.moveoutdate) = '9999-12-31' and months_between(to_date(current_date()),co.moveindate ) > 60 then '>5years'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) <= 3 then '0 - 3 Mths'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 3 and months_between(co.moveoutdate,co.moveindate ) <= 6 then '3 - 6months'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 6 and months_between(co.moveoutdate,co.moveindate ) <= 12 then '6 - 12months'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 12 and months_between(co.moveoutdate,co.moveindate ) <= 18 then '12 - 18months'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 18 and months_between(co.moveoutdate,co.moveindate ) <= 24 then '18 - 24months'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 24 and months_between(co.moveoutdate,co.moveindate ) <= 60 then '2 - 5years'
      when to_date(co.moveoutdate) != '9999-12-31' and months_between(co.moveoutdate,co.moveindate ) > 60 then '>5years'
      else '' end) as tenure_range,
te.ratecategorycode, te.duosgroupcode,
(case when substr(mtr.meterconfigcode,1,3) = 'MCC' then mtr.meterconfigcode
  else 'UNK' end) as meterconfigcode,
te.industrycode,ca.city1 as site_region,
(case when substr(te.ratecategorycode,1,2) = 'ED' then 'Residential Electricity'
	  when substr(te.ratecategorycode,1,2) = 'GD' then 'Residential Gas'
	  when substr(te.ratecategorycode,1,2) = 'EN' then 'residential Electricity'
	  when substr(te.ratecategorycode,1,2) = 'GN' then 'residential Gas'
	  when substr(te.ratecategorycode,1,2) = 'EU' then 'Unmetered Electricity'
	  else 'Unknown' end) as CustomerType,
(case when substr(te.ratecategorycode,1,1) = 'E' then 'Electricity'
	  when substr(te.ratecategorycode,1,1) = 'G' then 'Gas'
	  else 'Electricity' end) as FuelType,
di.discountcode,di.discountpackage,
di.discountpercent, di.discountpackageinstallationfromdate as discountfrom, di.discountpackageinstallationtodate as discountto,
(case when pay.perferred_payment is null then 'Unknown' else pay.perferred_payment end) as preferredpayment,
co.moveindate as contractstartdate, co.moveoutdate as contractenddate,co.productid productcode, co.PRODUCTDESCRIPTION product, co.productstartdate,co.productenddate,co.salestype as saletype,
case when co.salesorigin like 'FOTS - SCL' THEN 'FOTS Sales Channel' ELSE co.salesorigin END as saleorigin,
co.processtype as salesprocesstype,
(case when to_date(co.contractenddate) = '9999-12-31' then year(to_date(current_date())) - year(to_date(co.contractstartdate))
  else (year(to_date(co.contractenddate)) - year(to_date(co.contractstartdate))) end) as contract_tenure,
CASE WHEN geo.sub_building_name > ' ' THEN geo.sub_building_name ELSE ' ' END AS SITEADDRESS,
CASE WHEN GEO.thoroughfare > ' ' THEN GEO.thoroughfare  ELSE EID.street END AS SITEADDRESS1,
CASE WHEN GEO.building_number > ' ' THEN GEO.building_number ELSE EID.housenr END AS SITEADDRESS2,
CASE WHEN GEO.addr_line_1 > ' ' THEN GEO.addr_line_1 ELSE EID.zzstreet2 END AS SITEADDRESS3,
CASE WHEN GEO.building_group_name > ' ' THEN GEO.building_group_name ELSE ' ' END AS SITEADDRESS4,
CASE WHEN GEO.addr_line_4 > ' ' THEN GEO.addr_line_4 ELSE ' ' END AS SITEADDRESS5,
CASE WHEN GEO.principal_post_town  > ' ' THEN GEO.principal_post_town ELSE ' ' END AS SITEADDRESS6,
CASE WHEN GEO.county  > ' ' THEN GEO.county ELSE EID.CITY END AS SITEADDRESS7,
ca.rewardsflag,
bp.churnscore,
dual.dualindicator,
dual.status_flag,
bp.landlord as landlordflag,
te.premise as premiseid,
te.ctfflag as ctfflag
FROM ods.businesspartner bp
join (select distinct businesspartnerno, contractaccount contractaccountno, isucontract, dunningprocedurecodedescription as dunningprocedure,
languagetype, ebillflag as ebillingflag, contractaccountname, city1,housenum1,housenum2,street,STREETSUPPL1,
STREETSUPPL2,STREETSUPPL3,rewardsflag from ods.contractaccount where idorigin = 'SRP') ca on bp.partner = ca.businesspartnerno
join (select distinct isucontract contractno, contracaccount contractaccountno, installation technicalinstallationno,
moveindate contractstartdate,moveindate, moveoutdate,moveoutdate contractenddate,productstartdate,productenddate,salestype,salesorigin,processtype,productid,
PRODUCTDESCRIPTION from ods.isucontract
where idorigin = 'SRP') co
on ca.isucontract = co.contractno
join (select  pod mprn, installation technicalinstallationno, ratecategory ratecategorycode, duosgroupcode,
             industrycode,premise,ctfflag from ods.installation where idorigin = 'SRP') te
on co.technicalinstallationno = te.technicalinstallationno
left join (select distinct installation technicalinstallationno,discountcode,discountpackage,discountpercent,discountpackageinstallationfromdate,discountpackageinstallationtodate from ods.disc_current) di on te.technicalinstallationno = di.technicalinstallationno
left join (select distinct contractaccountno ,documentdescription as perferred_payment from ods.preferedpayment) pay
on ca.contractaccountno = pay.contractaccountno 
left join (select businesspartnerno,dualindicator,status_flag from ods.dualflag1) dual 
on bp.partner = dual.businesspartnerno
left outer join 
(SELECT TBL1.*
FROM
(SELECT
     TBL.*, ROW_NUMBER() OVER (PARTITION BY TBL.technicalinstallationno ORDER BY insertdate DESC) AS RNUM
FROM 
	(select  installation technicalinstallationno, pod, factvalue as meterconfigcode,insertdate from ods.installationfacts
		where idorigin = 'SRP' and installationfact = 'MTR_CNG_CD'
	)TBL
)TBL1 
WHERE TBL1.RNUM = 1) mtr 
on mtr.technicalinstallationno = te.technicalinstallationno and  te.mprn = mtr.pod
left outer join
(SELECT TBL1.*
FROM
(SELECT
     TBL.*, ROW_NUMBER() OVER (PARTITION BY TBL.mprn ORDER BY building_id DESC) AS RNUM
FROM
     (
        SELECT * FROM  ods.geodirectory
     )TBL
)TBL1
WHERE TBL1.RNUM = 1) geo on te.mprn = geo.mprn
left outer join
(SELECT TBL1.*
FROM
(SELECT
     TBL.*, ROW_NUMBER() OVER (PARTITION BY TBL.ext_ui ORDER BY processeddate DESC) AS RNUM
FROM
     (
        SELECT * FROM  storehouse_sapds_srp.EIDESWTMSGDATA
     )TBL
)TBL1
WHERE TBL1.RNUM = 1
) EID on cast(eid.ext_ui as bigint) = te.mprn
where bp.idorigin = 'CRP' AND (substr(te.ratecategorycode,1,2) = 'ED' or substr(te.ratecategorycode,1,2) = 'GD');