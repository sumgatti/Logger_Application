package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.RddOrDf
import org.scalatest.{FlatSpec, Matchers}
import ie.esb.datalake.ingestion._
import ie.esb.datalake.ingestion.mocking.PipelineMock
import org.mockito.Mockito._
import org.mockito.ArgumentMatchers.any

/**
  * Created by Sabater_A on 31/08/2017.
  */
class MapJobTest extends FlatSpec with Matchers{

  "a MapJob" should "continue" in {
    val job: MapJob[Staging] = new testMapJob
    val (plMock, dfArg) = PipelineMock.pipeline[Staging](Stub.dfDemographic, "datasource", List())

    job(plMock)

    verify(plMock) continue any[Map[String, RddOrDf]]
  }
}

class testMapJob extends MapJob[Staging] {
  override def runMapped(pl: Pipeline[Staging]): Map[String, RddOrDf] = {
    val df = Stub.dfDemographic
    Map("demographic_info" -> df)
  }
}
