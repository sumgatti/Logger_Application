package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.RddOrDf
import org.scalatest.{FlatSpec, Matchers}
import ie.esb.datalake.ingestion.mocking.PipelineMock
import ie.esb.datalake.ingestion._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{BooleanType, DataType}
import org.mockito.Mockito._
import org.apache.spark.sql.functions._

/**
  * Created by Sabater_A on 31/08/2017.
  */
class JobTest extends FlatSpec with Matchers {


  "a Job" should "continue" in {
    val job: Job[Staging] = new testJob
    val jobList = List(job)
    val (plMock, dfArg) = PipelineMock.pipeline[Staging](Stub.dfDemographic, "datasource", jobList)

    job(plMock)

    verify(plMock) continue dfArg.capture()
    dfArg.getValue.head.right.get shouldEqual Stub.dfDemographic
  }

  "a Job" should "continue multiple times" in {
    val colName = "bool"
    val job: Job[Staging] = new testJob
    val job1: Job[Staging] = new testJobAddStaticColumn[BooleanType, Boolean](colName,true, BooleanType)
    val jobList = List(job1)
    val (plMock, dfArg) = PipelineMock.pipeline[Staging](Stub.dfDemographic, "webtrends", jobList)

    val plResult = job(plMock)
    val dfResult: DataFrame = plResult.first
    val expectedResult = Stub.dfDemographic.withColumn(colName, lit(true).cast(BooleanType))

    dfResult.schema shouldEqual expectedResult.schema
  }
}

class testJob extends Job[Staging] {
  override def run(pl: Pipeline[Staging]): Seq[RddOrDf] = {
    val df = Stub.dfDemographic
    Seq(df)
  }
}

class testJobAddStaticColumn[T <: DataType, S](name: String, v: S, dt: T) extends Job[Staging] {
  override def run(pl: Pipeline[Staging]): Seq[RddOrDf] = {
    val df = pl.first
    val dfResult = df.withColumn(name, lit(v).cast(BooleanType))
    Seq(dfResult)
  }
}

