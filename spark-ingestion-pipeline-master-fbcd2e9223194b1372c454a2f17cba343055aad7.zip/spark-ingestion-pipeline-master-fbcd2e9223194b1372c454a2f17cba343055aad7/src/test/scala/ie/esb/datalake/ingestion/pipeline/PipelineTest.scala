package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.{RddOrDf}
import org.scalatest.{FlatSpec, Matchers}

import scala.collection.immutable.Seq

/**
  * Created by Sabater_A on 31/08/2017.
  */
class PipelineTest extends FlatSpec with Matchers {

  val data = Stub.dfDemographic
  //val precedenceData = Stub.fakeDataFrame
  val datasource = "never mind"
  val dataSeq: Seq[RddOrDf] = for (i <- 1 to 3) yield Right(data)
  val schema: Seq[String] = (1 to 3).map(_.toString).toSeq

  "a Pipeline" should "take a dataSetParam and a List of empty jobs" in {
    val pl = new Pipeline[Landing](datasource, List(), dataSetParam = dataSeq)
    pl.first shouldEqual Some(dataSeq.head)
    pl.sequence shouldEqual dataSeq
  }

  it should "take a sequence of just one RddOrDf" in {
    val pl = new Pipeline[Landing](datasource, List(), dataSetParam = Seq(Right(data)))
    pl.first shouldEqual Some(Right(data))
    pl.sequence shouldEqual Seq(Right(data))
  }

  it should "create a pipeline of filetransfer type" in {
    val pl = new Pipeline[FileTransfer]("ivr_call_logs", List(), dataSetParam = Seq(Right(data)))
    pl.first shouldEqual Some(Right(data))
    pl.sequence shouldEqual Seq(Right(data))
    pl.path shouldEqual "landing/ABTRAN"
    pl.in shouldEqual List("/landing/ABTRAN/a","/landing/ABTRAN/b")
    pl.out shouldEqual List("/storehouse/landing/abtran/a","/storehouse/landing/abtran/b")
  }

  it should "work without data or dataset" in {
    val pl = new Pipeline[Landing](datasource, List())
    pl.first shouldEqual None
    pl.sequence shouldEqual Seq()
  }

  it should "take schema and sequences" in {
    val pl = new Pipeline[Landing](datasource, List(), dataSetParam = dataSeq, dataSetScheme = schema)
    pl.first shouldEqual Some(dataSeq.head)
    pl.sequence shouldEqual dataSeq
    pl.map("1") shouldEqual dataSeq.head
    pl.map("2") shouldEqual dataSeq.tail.head
  }

  it should "fail with invalid input" in {
    val schemaNoData = intercept[IllegalArgumentException] {
      new Pipeline[Landing](datasource, List(), dataSetScheme = schema)
    }
    schemaNoData.getMessage shouldEqual "Schema without data"
  }

  it should "Adjust data when less or more DataFrames than map keys" in {
    val pl = new Pipeline[Landing](datasource, List(), dataSetParam = Seq(Right(data)), dataSetScheme = schema)
    pl.map.size shouldEqual 1
    pl.first shouldEqual Some(Right(data))
    pl.sequence shouldEqual Seq(Right(data))
  }

  it should "allow for everything passed expicitely" in {
    val pl = new Pipeline[Landing](datasource, List(), dataSetParam = dataSeq, dataSetScheme = schema)
    pl.first shouldEqual Some(Right(data))
    pl.sequence shouldEqual dataSeq
    pl.map("1") shouldEqual dataSeq.head
    pl.map("2") shouldEqual dataSeq.tail.head
  }
}
