package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.commons.Contexts
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._

/**
  * Created by Sabater_A on 31/08/2017.
  */
object Stub {
  def sparkContext = Contexts.sc
  def sqlContext = Contexts.sqlCtx

  val dfDemographic = sqlContext.createDataFrame(TestSets.demographicSet).toDF(Schemas.demographicSchema.map(sf => sf.name): _*)
  val rddRow: RDD[Row] = sparkContext.parallelize(TestSets.rowSet)
  val tabbedFile: String = getClass.getClassLoader.getResource("data/misc/tab-separated-file.txt").getPath
}


object TestSets {

  val demographicSet = List(
    ("Alejandro", "Sabater", 26, "M", 1.70, false, 10.4068, 66.9036),
    ("Shaun", "Collin", 30, "M", 1.80, true, 53.3498, 6.2603),
    ("Coen", "Gary", 52, "M", 1.84, true, 53.3444, 6.8903),
    ("Fal", "Willian", 28, "M", 1.64, false, 53.8898, 5.6503),
    ("Shaun", "Collin", 30, "M", 1.80, true, 54.0798, 6.7895)
  )

  val rowSet = Seq(
    Row("row", "family", "qualifier1", "jsonString1"),
    Row("row1", "family", "qualifier2", "jsonString2"),
    Row("row2", "family", "qualifier3", "jsonString3")
  )
}

object Schemas {

  val demographicSchema =
    StructType(List(
      StructField("name", StringType, true),
      StructField("surname", StringType, true),
      StructField("age", IntegerType, true),
      StructField("gender", StringType, true),
      StructField("height", DoubleType, true),
      StructField("married", BooleanType, true),
      StructField("lat", DoubleType, true),
      StructField("lon", DoubleType, true)
    ))

}

