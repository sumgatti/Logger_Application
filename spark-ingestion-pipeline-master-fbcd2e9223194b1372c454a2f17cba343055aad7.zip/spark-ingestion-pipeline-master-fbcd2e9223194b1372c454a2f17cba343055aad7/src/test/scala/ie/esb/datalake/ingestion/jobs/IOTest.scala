package ie.esb.datalake.ingestion.jobs

import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.Stub
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 11/09/2017.
  */
class IOTest extends FlatSpec with Matchers {

  private val io: IO = new IO
  // keep io stateless
  val testFile = Stub.tabbedFile

  "Parquet files" should "be read into a dataframe" in {
    //val path = getClass.getClassLoader.getResource("webtrends/").getPath
    //io.readParquetToDf(path).schema should equal(TestSets.webtrends_test_schema)
  }

  "RDDs" should "be created from textfiles" in {
    io.readCsvToRdd(testFile).count() should equal(6)
    io.readCsvToRdd(testFile, "\t").first() should equal(Row("a", "B", "2015-01-28"))
  }

  "jsonToDf" should "create a dataframe from JSON" in {
    io.readJsonToDf("{\"name\":\"Jane\",\"age\":21}").first()(0) should equal(21)
  }

  "readCSVsToDataFrame" should "read from a path that has CSV files to a dataframe" in {
    val df = io.readMultipleCsvToDf(getClass.getResource("/data/misc/csv/extract/").getPath, ",")

    df.columns should equal(Array("Name", "Surname"))
    df.first() should equal(Row.fromSeq(Seq("Alejandro", "Sabater")))

    io.readCsvToDf(getClass.getResource("/data/misc/csv/single").getPath, ",").first() should equal (Row.fromSeq(Seq("blah","blah","blah")))
  }

  "readCSVsToDataFrameWithFileName" should "read from a path that includes cvs to a dataframe and the filename should be added as a column" in {
    val df = io.readMultipleCsvToDf(getClass.getResource("/data/misc/csv/extract/").getPath, ",", true)

    df.columns should equal(Array("Name", "Surname", "filename"))
    df.show
    df.first() should equal(Row.fromSeq(Seq("Alejandro", "Sabater", "file1.csv")))
  }

  "readExcelFile" should "read .xls just providing the path" in {
    val path = getClass.getResource("/data/misc/xls/myFile.xls").getPath
    val io = new IO
    val df = io.readExcelFile(path)
    df.count shouldEqual 10
  }

  "readExcelFile" should "read .xls without headers" in {
    val path = getClass.getResource("/data/misc/xls/myFile.xls").getPath
    val io = new IO
    val df = io.readExcelFile(path, useHeaders = false)
    df.columns shouldEqual Array("C0","C1","C2","C3","C4","C5","C6")
    df.count shouldEqual 11
  }

  "readMultipleExcelFiles" should "read multiple excel files and include the filename" in {
    val path = getClass.getResource("/data/misc/xls").getPath
    val io = new IO
    val dfResult = io.readMultipleExcelFiles(path, filenameIncluded = true)
    dfResult.count shouldEqual 2353
    dfResult.columns.contains("filename") shouldEqual true
  }

  "readMultipleExcelFiles" should "read multiple excel files and not include the filename" in {
    val path = getClass.getResource("/data/misc/xls").getPath
    val io = new IO
    val dfResult = io.readMultipleExcelFiles(path, filenameIncluded = false)
    dfResult.count shouldEqual 2353
    dfResult.columns.contains("filename") shouldEqual false
  }
}
