package ie.esb.datalake.ingestion.pipeline


import com.typesafe.config.Config
import org.scalatest.{FlatSpec, Matchers}
import ie.esb.datalake.commons.LoadedProperties
import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.commons.Environment
import ie.esb.datalake.commons.Environment.Env._

/**
  * Created by Sabater_A on 31/08/2017.
  */
class PropertyTest extends FlatSpec with Matchers{

  "a property" should "be loaded" in {
    LoadedProperties.conf.getString("application.id") shouldEqual("ingestion-pipeline-test")
    Contexts.sparkConf.get("spark.master") shouldEqual(Environment.current match {
      case DEV => "local"
      case TEST => "yarn-cluster"
      case PROD => "yarn-cluster"
    })
  }

  "ingestionDb and stagingDb" should "import the db" in {
    Property.ingestionDb shouldEqual "process"
    Property.stagingDb shouldEqual "storehouse"
    Property.ingestion shouldBe a[Config]
  }

}
