package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 31/08/2017.
  */
class RddOrDfTest extends FlatSpec with Matchers {

  "RddOrDf" should "implicitly convert to DataFrame" in {
    val data: RddOrDf = Right(Stub.dfDemographic)

    val implicitDf: RddOrDf = Stub.dfDemographic

    data.right.get.first() shouldBe implicitDf.right.get.first()
  }

  it should "implicitly convert to RDD" in {
    val data: RddOrDf = Left(Stub.rddRow)

    val implicitRdd: RddOrDf = Stub.rddRow

    data.left.get shouldBe implicitRdd.left.get
  }

  "RDD" should "implicitly convert to RddOrDf" in {
    val data: RddOrDf = Stub.rddRow

    val implicitRdd: RDD[Row] = data

    data.left.get shouldBe implicitRdd
  }

  it should "convert to optional RddOrDf" in {
    val rdd: RDD[Row] = Stub.rddRow

    val data: Option[RddOrDf] = rdd

    rdd shouldBe data.get.left.get
  }

  "DataFrame" should "implicitly convert to RddOrDf" in {
    val data: RddOrDf = Right(Stub.dfDemographic)

    val implicitDf: DataFrame = data

    data.right.get shouldBe implicitDf
  }

  it should "convert to optional RddOrDf" in {
    val df: DataFrame = Stub.dfDemographic

    val data: Option[RddOrDf] = df

    df shouldBe data.get.right.get
  }

  "Optionals" should "implicitly convert to DataFrame" in {
    val data: Option[RddOrDf] = Some(Right(Stub.dfDemographic))

    val implicitDf: DataFrame = data

    data.get.right.get shouldBe implicitDf
  }

  it should "implicitly convert to RDD" in {
    val data: Option[RddOrDf] = Some(Left(Stub.rddRow))

    val implicitRdd: RDD[Row] = data

    data.get.left.get shouldBe implicitRdd
  }

  "Bad implicit conversion" should "be thrown" in {
    intercept[IllegalAccessError] { val df: DataFrame = None }
    intercept[IllegalAccessError] { val rdd: RDD[Row] = None }
  }

}
