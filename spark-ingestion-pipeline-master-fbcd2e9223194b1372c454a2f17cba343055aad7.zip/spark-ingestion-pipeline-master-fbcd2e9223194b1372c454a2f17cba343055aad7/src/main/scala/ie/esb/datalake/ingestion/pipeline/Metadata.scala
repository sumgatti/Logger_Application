package ie.esb.datalake.ingestion.pipeline

/**
  * Created by Sabater_A on 30/08/2017.
  */
case class Metadata private[ingestion] (appId: String) {

}
