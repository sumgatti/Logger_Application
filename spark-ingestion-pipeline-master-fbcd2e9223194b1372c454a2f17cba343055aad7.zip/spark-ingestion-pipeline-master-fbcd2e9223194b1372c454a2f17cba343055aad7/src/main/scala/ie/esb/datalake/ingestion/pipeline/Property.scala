package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.commons.LoadedProperties._
import ie.esb.datalake.commons.Environment._
import collection.JavaConversions._

/**
  * Created by Sabater_A on 30/08/2017.
  */
object Property {

  // ingestion
  def ingestion = fromFile("pipeline", None)

  def ingestionDb: String = ingestion.getString("ingestion.db")

  def stagingDb: String = ingestion.getString("staging.db")

  def fileTransferDb: String = ingestion.getString("file-transfer.db")
  def fileTransferSource: String = ingestion.getString("file-transfer.source")
  def fileTransferFiles: List[String] = ingestion.getStringList("file-transfer.files").toList
}
