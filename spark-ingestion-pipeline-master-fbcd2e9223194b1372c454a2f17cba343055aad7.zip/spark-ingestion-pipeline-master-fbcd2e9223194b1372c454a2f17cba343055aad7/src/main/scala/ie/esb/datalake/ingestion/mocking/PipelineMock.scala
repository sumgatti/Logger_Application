package ie.esb.datalake.ingestion.mocking

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{Etl, Job, Pipeline}
import org.apache.spark.sql.{DataFrame, Row}
import org.mockito.{Answers, ArgumentCaptor}
import org.mockito.Mockito._
import ie.esb.datalake.ingestion._
import org.apache.spark.rdd.RDD
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import org.mockito.ArgumentMatchers.any

/**
  * Created by Sabater_A on 31/08/2017.
  */
object PipelineMock {

  def pipeline[T <: Etl](sequence: Seq[RddOrDf], datasource: String, schema: Seq[String] = Seq(), jobs: List[Job[T]] = List())(implicit m: Manifest[T]): (Pipeline[T], ArgumentCaptor[Seq[RddOrDf]]) = {
    val plMock: Pipeline[T] = mock(classOf[Pipeline[T]])
    val dfArg: ArgumentCaptor[Seq[RddOrDf]] = ArgumentCaptor.forClass(classOf[Seq[RddOrDf]])
    val typ = m.runtimeClass.newInstance.asInstanceOf[T]
    val (db, path) = (typ.db, typ.path)

    when(plMock.db) thenReturn db
    when(plMock.path) thenReturn path
    when(plMock.out) thenReturn List(s"/${db}/${path}/${datasource}/output")
    when(plMock.in) thenReturn List(s"/${db}/${path}/${datasource}/input")
    when(plMock.datasource) thenReturn datasource
    when(plMock.sequence) thenReturn sequence
    when(plMock.first) thenReturn Some(sequence.head)
    when(plMock.map) thenReturn (if(!schema.isEmpty && !sequence.isEmpty) (schema zip sequence) toMap else Map[String, RddOrDf]())
    val answer = new Answer[Pipeline[T]]{
      override def answer(invocation: InvocationOnMock): Pipeline[T] = {
        val source: Seq[RddOrDf] = invocation.getArgument(0).asInstanceOf[Seq[RddOrDf]]
        if(jobs.nonEmpty) jobs.head(pipeline[T](source, datasource, schema, jobs.tail)._1) else pipeline[T](source, datasource, schema, jobs)._1
      }
    }
    when(plMock.continue(any[Seq[RddOrDf]]())) thenAnswer(answer)
    //when(plMock.run) thenReturn (if(jobs.nonEmpty) jobs.head(pipeline[T](sequence, datasource, schema, jobs)._1) else pipeline[T](sequence, datasource, schema, jobs)._1)
    (plMock, dfArg)
  }

  def pipeline[T <: Etl](sequenceDf: Seq[DataFrame], datasource: String)(implicit m: Manifest[T]): (Pipeline[T], ArgumentCaptor[Seq[RddOrDf]]) = {
    val seq: Seq[RddOrDf] = if(!sequenceDf.isEmpty) sequenceDf.map(df => df.get) else Seq()
    pipeline[T](seq, datasource, Seq[String]())
  }

  def pipeline[T <: Etl](df: DataFrame, datasource: String, jobs: List[Job[T]] = List())(implicit m: Manifest[T]): (Pipeline[T], ArgumentCaptor[Seq[RddOrDf]]) = {
    val seq: Seq[RddOrDf] = Seq(df)
    pipeline[T](seq, datasource, Seq[String](), jobs)
  }

  def pipeline[T <: Etl](datasource: String)(implicit m: Manifest[T]): (Pipeline[T], ArgumentCaptor[Seq[RddOrDf]]) = {
    pipeline[T](Seq(), datasource, Seq[String]())
  }

  def pipeline[T <: Etl](df: RDD[Row], datasource: String)(implicit m: Manifest[T]): (Pipeline[T], ArgumentCaptor[Seq[RddOrDf]]) = {
    val seq: Seq[RddOrDf] = Seq(df)
    pipeline(seq, datasource, Seq[String]())
  }
}
