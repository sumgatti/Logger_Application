package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.RddOrDf

/**
  * Created by Sabater_A on 30/08/2017.
  */
trait MapJob[T <: Etl] extends Job[T] {

  /**
    * A map job is applied differently as it has to handle
    * the correct pipeline continue.
    * @param pipeline the pipeline to continue on
    * @return the continued pipeline copy
    */
  override def apply(pipeline: Pipeline[T]): Pipeline[T] = {
    pipeline.continue(this.runMapped(pipeline))
  }

  override def run(pl: Pipeline[T]): Seq[RddOrDf] = {
    runMapped(pl).values.toSeq
  }

  def runMapped(pl: Pipeline[T]): Map[String, RddOrDf]
}
