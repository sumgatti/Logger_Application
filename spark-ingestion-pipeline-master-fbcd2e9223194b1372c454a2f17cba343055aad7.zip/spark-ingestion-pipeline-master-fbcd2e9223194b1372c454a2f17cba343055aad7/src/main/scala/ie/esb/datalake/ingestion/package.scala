package ie.esb.datalake

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}

/**
  * Created by Sabater_A on 30/08/2017.
  */
package object ingestion {
  // reinstate prefix when testing
  val prefix = ""
  /**
    * As there is no common super type for RDDs and DataFrames
    * in spark this alias allows us to handle both at the same time.
    * It is vital to the usage of jobs and their data transfer between
    * each other.
    * {{{
    *   // converts implicitly
    *   val rdd:RDD[Row] = rddOrDf // to rdd
    *   val df:DataFrame = rddOrDf // to data frame
    *   val optDf:DataFrame = optionRddOrDf // from option
    *   ...
    * }}}
    *
    * Have a look at the implicit conversion in
    * [[ie.esb.datalake.ingestion]] to see all
    * possible conversions.
    */
  type RddOrDf = Either[RDD[Row], DataFrame]

  // from rddOrDf to object
  implicit def rddOrDf2DataFrame(rddOrDf: RddOrDf): DataFrame = rddOrDf.right.get
  implicit def rddOrDf2RDD(rddOrDf: RddOrDf): RDD[Row] = rddOrDf.left.get

  // from object to rddOrDf
  implicit def dataFrame2rddOrDf(df: DataFrame): RddOrDf = Right(df)
  implicit def rdd2rddOrDf(rdd: RDD[Row]): RddOrDf = Left(rdd)

  // from object to option of rddOrDf
  implicit def dataFrame2OptionRddOrDf(df: DataFrame): Option[RddOrDf] = Some(Right(df))
  implicit def rdd2OptionRddOrDf(rdd: RDD[Row]): Option[RddOrDf] = Some(Left(rdd))

  // from option of rddOrDf to object
  implicit def optionRddOrDf2DataFrame(optionRddOrDf: Option[RddOrDf]): DataFrame = optionRddOrDf match {
    case Some(rddOrdDf) => rddOrdDf
    case None => throw new IllegalAccessError("Bad implicit conversion of empty RddOrDf")
  }
  implicit def optionRddOrDf2RDD(optionRddOrDf: Option[RddOrDf]): RDD[Row] = optionRddOrDf match {
    case Some(rddOrdDf) => rddOrdDf
    case None => throw new IllegalAccessError("Bad implicit conversion of empty RddOrDf")
  }

}
