package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion
import ie.esb.datalake.ingestion.RddOrDf

/**
  * Created by Sabater_A on 30/08/2017.
  */

/**
  * The Pipeline object represents the actually run pipeline of jobs.
  * It handles the hand over of one job to another and provides each job with
  * the correct input and output directories.
  *
  * To create a pipeline you need to first create a list of jobs.
  * Once you have gathered the required jobs you can hand it into
  * the pipeline with the given global name of your data source.
  * Finally you only need to run the pipeline.
  * {{{
  *   // create list of jobs
  *   val jobs = List(new ReadCSVToDfJob(..), new ParsingJob(..), ...)
  *
  *   // create pipeline
  *   val pl = new Pipeline[Staging]("myDataSource", jobs)
  *
  *   // run pipeline
  *   pl run
  * }}}
  *
  * As seen, a pipeline may consist of two types. This typed creation of
  * the pipeline allows to handle where the pipeline persists to and what
  * kind of jobs are allowed for a pipeline. To see the available types
  * of a pipeline, please see
  * [[ie.esb.datalake.ingestion.pipeline.Etl Pipelines]].
  *
  * @param datasource Name of the data source ingested
  * @param jobs list pf jobs to run within this pipeline
  */
case class Pipeline[T <: Etl](datasource: String,
                              jobs: List[Job[T]],
                              private val dataSetParam: Seq[RddOrDf] = Seq(),
                              private val dataSetScheme: Seq[String] = Seq())
                             (implicit m: Manifest[T]) {

  require(!jobs.contains(null), "job should not be null")
  private val plType: T = m.runtimeClass.newInstance.asInstanceOf[T]
  /**
    * The database this pipeline has to store to and read from
    */
  val db = plType.db

  val (path, in, out) = plType match {
    case x: FileTransfer => {
      val plTypeFile = plType.asInstanceOf[FileTransfer]
      val pathIn = s"${plTypeFile.path}/${plTypeFile.source.toUpperCase()}"
      val pathOut = s"${plTypeFile.path}/${plTypeFile.source.toLowerCase()}"
      val i: List[String] = plTypeFile.files.map(str => s"/${pathIn}/${str}")
      val o: List[String] = plTypeFile.files.map(str => s"/${db}/${pathOut}/${str}")
      (pathIn, i, o)
    }
    case x: Landing => {
      val p = ingestion.prefix + "/" + db + "/" + plType.path + "/" + datasource + "/"
      val (i, o) =  (p + "input/", p + "output/")
      (p, List(i), List(o))
    }
    case x: Staging => {
      val p = ingestion.prefix + "/" + db + "/" + plType.path + "/" + datasource + "/"
      val (i, o) =  (p + "input/", p + "output/")
      (p, List(i), List(o))
    }
  }

  /**
    * Call this method to run all jobs in a pipeline
    * {{{
    *   val pl = new Pipeline[Staging]("myDataSource", jobs)
    *   pl.run() // runs entire pipeline
    * }}}
    * @return the final copy of the pipeline after all jobs ran
    */
  def run(): Pipeline[T] = {
    if (jobs.nonEmpty) jobs.head(this) else this
  }

  /**
    * Continue with the next job after a job ran.
    * @param newData data handed over by previous job
    * @return copy of the pipeline with the newly altered data
    */
  def continue(newData: Seq[RddOrDf]): Pipeline[T] = {
    Pipeline[T](datasource, jobs.tail, dataSetParam = newData).run()
  }

  /**
    * Continue with the next job after a map job ran
    * @param newData mapped data handed over by previous job
    * @return copy of the pipeline with the newly altered data
    */
  def continue(newData: Map[String, RddOrDf]): Pipeline[T] = {
    Pipeline[T](datasource, jobs.tail,
      dataSetParam = newData.values.toSeq,
      dataSetScheme = newData.keys.toSeq).run()
  }

  lazy val first: Option[RddOrDf] = sequence.size match {
    case 0 => None
    case _ => Some(sequence.head)
  }

  val (sequence: Seq[RddOrDf], map: Map[String, RddOrDf]) =
    (dataSetParam, dataSetScheme) match {
      // all empty
      case (Seq(), Seq()) => (Seq(), Map())
      // only sequence
      case (ds, Seq()) if ds.nonEmpty => (ds, ds.zipWithIndex.toMap)
      // only schema
      case (Seq(), _) => throw new IllegalArgumentException("Schema without data")
      // sequence & schema
      case (ds, dm) if ds.nonEmpty & dm.nonEmpty => (ds, dm zip ds toMap)
    }

}

/**
  * Interface for the definition of pipeline types.
  * This interface specifies the required fields for
  * each specific type of pipeline.
  */
sealed trait Etl {
  def path: String
  def db: String
}

/**
  * Landing implementation of pipeline.
  * Landing pipelines assure data is written to:
  * ''/process/landing/databaseName''
  */
class Landing extends Etl {
  override def path: String = "landing"
  override def db: String = Property.ingestionDb
}

/**
  * Staging implementation of pipeline.
  * Staging pipelines assure data is written to:
  * ''/storehouse/staged/databaseName''
  */
class Staging extends Etl {
  override def path: String = "staged"
  override def db: String = Property.stagingDb
}

class FileTransfer extends Etl {
  def source = Property.fileTransferSource
  override def db: String = Property.fileTransferDb
  override def path: String = "landing"
  def files: List[String] = Property.fileTransferFiles
}



