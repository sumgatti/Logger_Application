package ie.esb.datalake.ingestion.pipeline

import ie.esb.datalake.ingestion.RddOrDf

/**
  * Created by Sabater_A on 30/08/2017.
  */
trait Job[T <: Etl] extends ((Pipeline[T]) => Pipeline[T]) {

  /**
    * Internal implementation continuing the pipeline with this runMultiple
    * following the template method pattern.
    * @param pipeline
    * @return
    */
  def apply(pipeline: Pipeline[T]): Pipeline[T] = {
    pipeline.continue(this.run(pipeline))
  }

  def run(pl: Pipeline[T]): Seq[RddOrDf]
}
