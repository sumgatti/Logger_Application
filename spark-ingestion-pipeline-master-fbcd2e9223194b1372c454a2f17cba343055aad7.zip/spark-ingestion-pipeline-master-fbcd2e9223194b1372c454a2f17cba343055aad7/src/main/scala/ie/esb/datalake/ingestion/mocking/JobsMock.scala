package ie.esb.datalake.ingestion.mocking

/**
  * Created by Sabater_A on 31/08/2017.
  */
object JobsMock {

}
