package ie.esb.datalake.ingestion.jobs.io

import com.databricks.spark.avro._
import ie.esb.datalake.commons.Contexts
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path, PathFilter}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, DataFrameReader, DataFrameWriter, Row}

import scala.util.{Failure, Success, Try}

/**
  * Created by Sabater_A on 06/09/2017.
  */

/**
  * General purpose IO objects gathering all IO operations
  * within the standard Jobs. These operations can be used
  * for any custom job if desired. In addition this handling
  * of IO in a separate object allows to invert control for
  * testing purposes of custom jobs:
  * {{{
  *   import org.mockito.Mockito._ // get mockito mocking libs
  *   val ioMock = mock(classOf[IO]) // create mock
  *   new CustomJob(io = ioMock, ...).run(...) // run implementation
  *   verify(ioMock) someMethod() // verify method call on mock
  * }}}
  *
  */
class IO {

  /**
    * Contexts to perform the io ops on
    */
  lazy val sc = Contexts.sc
  /**
    * Context to perform sql based io ops on
    */
  lazy val sqlCtx = Contexts.sqlCtx

  /**
    * Reads a parquet to dataframe
    * @param path path to read from
    * @return DataFrame read
    */
  def readParquetToDf(path: String): DataFrame = {
    sqlCtx.read.parquet(path)
  }

  /**
    * Reads a CSV file to RDD
    * @param file path to file to read
    * @param delim delimiter to split by
    * @return RDD of Row read
    */
  def readCsvToRdd(file: String, delim: String = "\t"): RDD[Row] = {
    sqlCtx.read.format("com.databricks.spark.csv").option("delimiter", delim).load(file).rdd
  }

  /**
    * Reads an avro to DataFrame
    * @param path path to read from
    * @return DataFrame read
    */
  def readAvroToDf(path: String): DataFrame = {
    sqlCtx.read.avro(path)
  }

  def getListOfFiles(path: String, fileExtension: String):List[FileStatus] = {
    val conf = sc.hadoopConfiguration

    val fs = FileSystem.get(conf)
    val filter = new PathFilter(){
      def accept(file: Path) : Boolean = {
        file.getName().endsWith(fileExtension)
      }
    }
    fs.listStatus(new Path(path), filter).toList
  }


  /**
    * reads mutiple CSVs and parses them to DataFrame
    * @param path path to read from
    * @param delimiter delimiter to split by
    * @param filenameIncluded include filename as extra column
    * @param header specifies if file includes headers
    * @param inferSchema infers schema
    * @param nullValue value to replace nulls with
    * @param fileExtension file extension of file on disk
    * @param mode read mode to use (see com.databricks.spark.csv)
    * @param schema optional schema if not inferred
    * @param fileSizeIncluded adds additional column with file size
    * @return CSVs parsed into DataFrame
    */
  def readMultipleCsvToDf(path: String,
                          delimiter: String=",",
                          filenameIncluded: Boolean = false,
                          header: Boolean = true,
                          inferSchema: Boolean = true,
                          nullValue: String = "",
                          fileExtension: String = ".csv",
                          mode: String = "PERMISSIVE",
                          schema: Option[StructType] = None,
                          fileSizeIncluded: Boolean = false,
                          enclosingCharacter: String = "\""): DataFrame = {

    val df: List[DataFrame] = getListOfFiles(path, fileExtension).map(f => {
      val fileSize = f.getLen
      val fileSplit: Array[String] = f.getPath.toString.split("/")
      val filename = fileSplit(fileSplit.length -1)

      (filenameIncluded, fileSizeIncluded) match {
        case (true, false) => readCsvToDf(f.getPath.toString, delimiter, header, inferSchema, nullValue, mode, schema, enclosingCharacter).withColumn("filename", lit(filename))
        case (true, true) =>  readCsvToDf(f.getPath.toString, delimiter, header, inferSchema, nullValue, mode, schema, enclosingCharacter).withColumn("filename", lit(filename)).withColumn("filesize", lit(fileSize))
        case (false, false) => readCsvToDf(f.getPath.toString, delimiter, header, inferSchema, nullValue, mode, schema, enclosingCharacter)
        case (false, true) => readCsvToDf(f.getPath.toString, delimiter, header, inferSchema, nullValue, mode, schema, enclosingCharacter).withColumn("filesize", lit(fileSize))
      }
    })

    val unionFunction = (df1: DataFrame, df2: DataFrame) => {
      Try(df1 unionAll df2) match {
        case Success(s) => s
        case Failure(f) => df1
      }
    }

    if(df.size > 1) df.reduce((df1, df2) => unionFunction(df1, df2))
    else if(df.size == 1) df(0)
    else sqlCtx.emptyDataFrame
  }

  /**
    *
    * @param path path to read from
    * @param delimiter delimiter to split by
    * @param header specifies if file includes headers
    * @param inferSchema infers schema
    * @param nullValue value to replace nulls with
    * @param mode read mode to use (see com.databricks.spark.csv)
    * @param schema optional schema if not inferred
    * @return CSV parsed into DataFrame
    */
  def readCsvToDf(path: String,
                  delimiter: String,
                  header: Boolean = true,
                  inferSchema: Boolean = true,
                  nullValue: String = "",
                  mode: String = "PERMISSIVE",
                  schema: Option[StructType] = None,
                  enclosingCharacter: String = "\"") = {

    val optionsMap = Map("header" -> header.toString, "delimiter" -> delimiter, "inferSchema" -> inferSchema.toString, "treatEmptyValuesAsNulls" -> "true", "nullValue" -> nullValue, "mode" -> mode, "quote" -> enclosingCharacter)
    val fnDfReader: DataFrameReader = sqlCtx.read.format("com.databricks.spark.csv").options(optionsMap)

    schema match {
      case None => fnDfReader.load(path)
      case Some(m) => fnDfReader.schema(m).load(path)
    }
  }

  /**
    * Write a DataFrame as parquet
    * @param df DataFrame to write
    * @param path path to write to
    * @param mode write mode (overwrite, append, ...)
    */
  def writeParquet(df: DataFrame, path: String, mode: String = "append"): Unit = {

    df.write
      .mode(mode)
      .parquet(path)
  }

  /**
    * Write DatafFame as date partitioned parquet structure
    * @param df dataframe to write
    * @return
    */
  @deprecated("use writePartitionedParquetTable() instead")
  def writePartitionedDF(df: DataFrame): DataFrameWriter = {
    df.write.partitionBy("year", "month", "day")
  }

  /**
    * reads json into a DataFrame
    * @param json json to distribute
    * @return DataFrame with json rows
    */
  def readJsonToDf(json: String): DataFrame = {
    readJson(sc.parallelize(json :: Nil))
  }

  /**
    * Read RDD of String holding json string representations to DataFrame
    * @param rdd rdd to parse
    * @return DataFrame parsed from json
    */
  def readJson(rdd: RDD[String]): DataFrame = {
    sqlCtx.read.json(rdd)
  }

  /**
    * write DataFrame as CSV textfile
    * @param df DataFrame to write
    * @param path path to write to
    * @param delimeter delimiter to use for CSV
    */
  def writeTextFile(df: DataFrame, path: String, delimeter: String = "\t"): Unit = {
    df.map { row: Row => row.mkString(delimeter) }.saveAsTextFile(path)
  }

  def readMultipleExcelFiles(parentPath: String,
                             useHeaders: Boolean = true,
                             inferSchema: Boolean = true,
                             treatEmptyValueAsNull: Boolean = true,
                             filenameIncluded: Boolean = false) = {

    val files: Seq[FileStatus] = getListOfFiles(parentPath, fileExtension = ".xls")

    val dfList: Seq[DataFrame] = files.map(f => {
      val filename: String = f.getPath.getName

      filenameIncluded match {
        case true => readExcelFile(f.getPath.toString, useHeaders, inferSchema, treatEmptyValueAsNull).withColumn("filename", lit(filename))
        case false => readExcelFile(f.getPath.toString, useHeaders, inferSchema, treatEmptyValueAsNull)
      }
    })

    val unionFunction = (df1: DataFrame, df2: DataFrame) => {
      Try(df1 unionAll df2) match {
        case Success(s) => s
        case Failure(f) => df1
      }
    }

    if(dfList.size > 1) dfList.reduce((df1, df2) => unionFunction(df1, df2))
    else if(dfList.size == 1) dfList(0)
    else sqlCtx.emptyDataFrame

  }

  def readExcelFile(path: String,
                    useHeaders:
                    Boolean = true,
                    inferSchema: Boolean = true,
                    treatEmptyValueAsNull: Boolean = true): DataFrame = {

    val dfReader = Contexts.sqlCtx.read
      .format("com.crealytics.spark.excel")
      .option("location", path)
      .option("useHeader", useHeaders.toString.toLowerCase) // Required
      .option("treatEmptyValuesAsNulls", treatEmptyValueAsNull.toString.toLowerCase) // Optional, default: true
      .option("inferSchema", inferSchema.toString.toLowerCase) // Optional, default: false
      .option("addColorColumns", "false") // Optional, default: false
      .load()
    dfReader
  }



}
