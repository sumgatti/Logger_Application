# --- PREPARING AND TRANSFORMING DATA ----------------------
library(RODBC)
library(reshape2)
library(dplyr)
library(data.table)
library(stringr)
library(plyr)
library(ggplot2)

setwd("P:/Documents/R_Code/ValueModel/data")
data_residential <- readRDS('../data/res_customers.rds')
#data_sample <- readRDS('../data/res_samplecustomers.rds')

#==================================================================
#bring in cost information

connection <- odbcConnect("SPSS_Database")

cost_query <-  
  "SELECT [CostDriver],[CostType],[CT],[Electricity Unit Cost],[Gas Unit Cost]FROM [SPSS].[dbo].[VL_valueCustomerCostings] where CT = 'CT'"

cost_data <- sqlQuery(connection, cost_query)
cost_data <- data.table(cost_data)

options(scipen = 999)
ctsbill <- filter(cost_data, CostType == 'Paper Bills - print and paper cost')
ctsbillpost <- filter(cost_data, CostType == 'Paper Bills - postage cost') 
ctsbillpost[,'Electricity Unit Cost'] + ctsbill[,'Electricity Unit Cost']

costdd <- filter(cost_data, CostType == 'DD - cost')   #costdd[,'Electricity Unit Cost']
costpo <- filter(cost_data, CostType == 'An Post - cost')  #costpo[,'Electricity Unit Cost']
costpayother <- filter(cost_data, CostType == 'Other - cost') #costpayother[,'Electricity Unit Cost']

ctsdunn <- filter(cost_data, CostType == 'Dunn. Letters - print and paper cost') 
ctsdunnpost <- filter(cost_data, CostType == 'Dunn. Letters - postage cost') 
ctsdunn[,'Electricity Unit Cost'] + ctsdunnpost[,'Electricity Unit Cost']

ctsarvato <- filter(cost_data, CostType == 'Arvato BCW contract - ext. debt mgmt cost')  #ctsarvato[,'Electricity Unit Cost']
ctsdiscon <- filter(cost_data, CostType == 'Disconnection / Reconnection - cost')  #ctsdiscon[,'Electricity Unit Cost']

cost_dialler <- 3.16
cost_ivr <- 0.23
cost_acd <- .4
cost_agent <- 4.18
cost_payg_agent <- 4.78
cost_admin <- 4.74

ctspayroll_comm <- filter(cost_data, CostDriver == 'CTS Payroll Costs' & CostType == 'Commercial')  #ctspayroll_comm[,'Electricity Unit Cost']
ctspayroll_ops <- filter(cost_data, CostDriver == 'CTS Payroll Costs' & CostType == 'Customer Operations')  #ctspayroll_ops[,'Electricity Unit Cost']

ctapayroll_comm <- filter(cost_data, CostDriver == 'CTA Payroll Costs' & CostType == 'Commercial')  #ctapayroll_comm[,'Electricity Unit Cost']
ctapayroll_ops <- filter(cost_data, CostDriver == 'CTA Payroll Costs' & CostType == 'Customer Operations')  #ctapayroll_ops[,'Electricity Unit Cost']

cta_marketing <- 6.69
cta_fots_win <- filter(cost_data, CostType == "FOTS 'Winback' - cost")  #cta_fots_win[,'Electricity Unit Cost']
cta_fots_ret <- filter(cost_data, CostType == "FOTS 'Retention' - cost")  #cta_fots_ret[,'Electricity Unit Cost']
cta_in_win <- filter(cost_data, CostType == "Inbound  Tele 'Winback' - cost")  #cta_in_win[,'Electricity Unit Cost']
cta_in_ret <- filter(cost_data, CostType == "Inbound Tele 'Retention' - cost") #cta_in_ret[,'Electricity Unit Cost']
cta_out_win <- filter(cost_data, CostType == "Outbound 'Winback' - cost") #cta_out_win[,'Electricity Unit Cost']
cta_out_ret <- filter(cost_data, CostType == "Outbound Tele 'Retention' - cost") #cta_out_ret[,'Electricity Unit Cost']
cta_web_win <- filter(cost_data, CostType == "Web - EI Website 'Winback' - cost") #cta_web_win[,'Electricity Unit Cost']
cta_web_ret <- filter(cost_data, CostType == "Web - EI Website 'Retention' - cost") #cta_web_ret[,'Electricity Unit Cost']
cta_evt_win <- filter(cost_data, CostType == "FMI / SCL Events - cost Winback") #cta_evt_win[,'Electricity Unit Cost']
cta_evt_ret <- filter(cost_data, CostType == "FMI / SCL Events - cost Retention") #cta_evt_ret[,'Electricity Unit Cost']
cta_admin <- filter(cost_data, CostType == "Admin (Fixed)") #cta_admin[,'Electricity Unit Cost']
cta_spayg <- 201 
cta_payg_life <- 154

#==================================================================
#billing details per customer
data_billing <- readRDS('../data/billing.rds')
data_billing <- data_billing[contractaccount %in% data_residential$contractaccount]

#bill <- data_billing[,.N, by=contractaccount] 
#head(data_billing, 3)
#summary(data_billing)

bill2 <- aggregate(amount ~ contractaccount + activity, data_billing, sum) 
bill3 <- aggregate(amount ~ contractaccount + activity, data_billing, length) 

billing<- merge(bill2, bill3, by = c('contractaccount', 'activity'))

names(billing)[names(billing)=="amount.x"] <- "totalbilled"
names(billing)[names(billing)=="amount.y"] <- "countbills"
rm(bill2, bill3)
cols <- c("contractaccount", "totalbilled", "countbills")
billing <- billing[,cols]

#==================================================================
#current balance per customer
data_balance <- readRDS('../data/balance.rds')
data_balance <- data_balance[contractaccount %in% data_residential$contractaccount]

balance <- data_balance
balance <- aggregate(amount ~ contractaccount, balance, sum) 

names(balance)[names(balance)=="amount"] <- "currentbal"
#==================================================================
#meter reads per customer
data_meter_reads <- readRDS('../data/meter_reads.rds')
data_meter_reads <- data_meter_reads[contractaccount %in% data_residential$contractaccount]


meter <- subset(data_meter_reads, activity == "Meter reading by customer - SAP" | activity == "Networks Provided Customer Reading"
                  | activity == "Meter reading by utility - SAP")
meter <- aggregate(amount ~ contractaccount, meter, length) 

names(meter)[names(meter)=="amount"] <- "totalreads"

#==================================================================
#dunning per customer
data_dunning <- readRDS('../data/dunning.rds')
data_dunning <- data_dunning[contractaccount %in% data_residential$contractaccount]

data_dunning$dunningletter <- data_dunning[, str_detect(activity, "LETTER")] 
data_dunning$dunning_call <- data_dunning[, str_detect(activity, "DIALLER")] 
data_dunning$dunning_sms <- data_dunning[, str_detect(activity, "DUTL_A")] 

dunning <- aggregate(cbind(dunningletter, dunning_call, dunning_sms) ~ contractaccount, data_dunning, sum) 


#==================================================================
#retention per customer
data_retention <- readRDS('../data/retention.rds')
data_retention <- data_retention[contractaccount %in% data_residential$contractaccount]

#data_retention$retention <- data_retention[, str_detect(activity, "RETEN")] 
#data_retention$cross_sell <- data_retention[, str_detect(activity, "CRSSE")] 

temp_ret <- data_retention

retention<- temp_ret %>% group_by(contractaccount, activity) %>% 
  summarise( sum=sum(amount)) %>% 
  melt(id.var=c("contractaccount", "activity")) %>% 
  dcast(contractaccount ~  variable + activity )

retention[is.na(retention)] <- 0
names(retention)<- gsub("sum_", "", names(retention), fixed = TRUE)
#retention <- aggregate(cbind(retention,cross_sell, amount)  ~ contractaccount, data_retention, sum) 

#names(retention)[names(retention)=="amount"] <- "totalretsale"

#data_retention[contractaccount == "950115545",]

#==================================================================
#payg installs per customer
data_payg <- readRDS('../data/payg.rds')
data_payg <- data_payg[contractaccount %in% data_residential$contractaccount]

data_payg$payg_industry <- data_payg[, str_detect(activity, "^9")] 
data_payg$payg_lifestyle <- data_payg[, str_detect(activity, "^E")] 
data_payg$payg_ni <- data_payg[, str_detect(activity, "^K")] 

payg <- aggregate(cbind(payg_industry, payg_lifestyle, payg_ni) ~ contractaccount, data_payg, sum) 


#==================================================================
#email details per customer
data_emails <- readRDS('../data/emails.rds')
data_emails <- data_emails[contractaccount %in% data_residential$contractaccount]

emails <- aggregate(amount ~ contractaccount, data_emails, sum) 

names(emails)[names(emails)=="amount"] <- "totalemails"

#em2[contractaccount == "950115545",]


#==================================================================
#switch gains per customer
data_switches <- readRDS('../data/switches.rds')
data_switches <- data_switches[contractaccount %in% data_residential$contractaccount]

switch <- aggregate(amount ~ contractaccount, data_switches, sum) 

temp_switch <- data_switches

switch<- temp_switch %>% group_by(contractaccount, activity) %>% 
  summarise( sum=sum(amount)) %>% 
  melt(id.var=c("contractaccount", "activity")) %>% 
  dcast(contractaccount ~  variable + activity )

switch[is.na(switch)] <- 0
names(switch)<- gsub("sum_", "", names(switch), fixed = TRUE)


#==================================================================
#instalment plans per customer
data_instalments <- readRDS('../data/instalments.rds')
data_instalments <- data_instalments[contractaccount %in% data_residential$contractaccount]

ip <- aggregate(amount ~ contractaccount, data_instalments, length) 

names(ip)[names(ip)=="amount"] <- "totalips"

#==================================================================
#ivr calls per customer
data_ivr_calls <- readRDS('../data/ivr_calls.rds')
data_ivr_calls <- data_ivr_calls[contractaccount %in% data_residential$contractaccount]

ivr <- aggregate(amount ~ contractaccount, data_ivr_calls, length) 

names(ivr)[names(ivr)=="amount"] <- "ivr_calls"

#==================================================================
#acd calls per customer
data_acd_calls <- readRDS('../data/acd_calls.rds')
data_acd_calls <- data_acd_calls[contractaccount %in% data_residential$contractaccount]

acd <- aggregate(amount ~ contractaccount, data_acd_calls, length) 

names(acd)[names(acd)=="amount"] <- "acd_calls"

#==================================================================
#smart payg installs per customer
data_spayg <- readRDS('../data/spayinstalls.rds')
data_spayg <- data_spayg[contractaccount %in% data_residential$contractaccount]

spayg <- aggregate(amount ~ contractaccount, data_spayg, sum) 

names(spayg)[names(spayg)=="amount"] <- "spayg_installs"

#==================================================================

#payment.sql details per customer
data_payments <- readRDS('../data/payments.rds')
data_payments <- data_payments[contractaccount %in% data_residential$contractaccount]

temp_pay <- data_payments

temp_pay<- temp_pay %>% group_by(contractaccount, activity) %>% 
  summarise(count=n(), sum=sum(amount)) %>% 
  melt(id.var=c("contractaccount", "activity")) %>% 
  dcast(contractaccount ~  variable + activity )

temp_pay[is.na(temp_pay)] <- 0
payment <- temp_pay[, -grep("sum_", colnames(temp_pay))]

#test <- rowSums(temp_pay[,grep('Post', colnames(temp_pay))])

#calculate cost of payments
dd <- c(grep( "V.A.D.D" , names(payment), value = TRUE), grep( "Equaliser" , names(payment), value = TRUE),
        grep( "EFT" , names(payment), value = TRUE), grep( "Siemens" , names(payment), value = TRUE))
po <- c(grep( "Post" , names(payment), value = TRUE), grep( "Cash" , names(payment), value = TRUE))
ca <- grep( "contract" , names(payment), value = TRUE)

#this is correct 
others <- payment[ ,!(names(payment) %in% c(dd, po,ca))]
ddebit <- payment[ ,(names(payment) %in% dd)]
post <- payment[ ,(names(payment) %in% po)]

payment$pay_dd <- rowSums(ddebit)
payment$pay_po <- rowSums(post)
payment$pay_others <- rowSums(others)
payment$pay_total <- rowSums(temp_pay[,grep('sum_', colnames(temp_pay))])

ex <- c(grep( "pay_" , names(payment), value = TRUE), ca)

payment <- payment[, (names(payment) %in% ex)]

#======================== testing =================================================
#rowSums(temp_pay[,grep('Post', colnames(temp_pay))])
#matches <- rowSums(temp_pay[,grep(paste(dd,collapse="|"), colnames(temp_pay))])
#====================================================================================

#==================================================================
#ex-gratia payments to customer
data_exgratia <- readRDS('../data/res_res_exgratia.rds')
data_exgratia <- data_exgratia[contractaccount %in% data_residential$contractaccount]

exgratia <- aggregate(amount ~ contractaccount, data_exgratia, sum) 

names(exgratia)[names(exgratia)=="amount"] <- "ex_gratia_pay"

#==================================================================
# add all aggregated data together and clean up any unneeded tables
rm(data_acd_calls, data_payg, data_payments, data_ivr_calls, data_emails, 
   data_dunning, data_retention, data_meter_reads, data_billing)
rm(data_balance, data_instalments, data_spayg, data_switches)

acd[is.na(acd)] <- 0
spayg[is.na(spayg)] <-0

customer_trans <-Reduce(function(x, y) merge(x, y, all=TRUE), list(data_residential, billing, meter, emails, acd, ivr, 
                                                                   retention, payg, dunning, payment, spayg, switch,
                                                                   ip, balance, exgratia))


#customer_costs <-Reduce(function(x, y) merge(x, y, all=TRUE), list(customer_costs, exgratia))


#customer_trans[is.na(customer_trans)] <- 0

#customer_trans <- customer_trans %>%
#  mutate(spayg_installs = ifelse(is.na(spayg_installs),0,spayg_installs))

#customer_trans <- customer_trans %>%
#  mutate(acd_calls = ifelse(is.na(acd_calls),0,acd_calls))

customers <- nrow(customer_trans)

customer_costs <- customer_trans[, list(billed = totalbilled, 
                                        bills = countbills,
                                        paid = pay_total, 
                                        payments = (pay_dd + pay_po * + pay_others),
                                        balance = currentbal,
                                        cost_bill = countbills * (ctsbillpost[,'Electricity Unit Cost'] + ctsbill[,'Electricity Unit Cost']),
                                        
                                        cost_payment = (pay_dd * (costdd[,'Electricity Unit Cost']) + (pay_po * costpo[,'Electricity Unit Cost']) 
                                                                    + (pay_others * costpayother[,'Electricity Unit Cost'])),
                                        cost_dunning = (dunningletter * (ctsdunn[,'Electricity Unit Cost'] + ctsdunnpost[,'Electricity Unit Cost'])),
                                        count_dunning = dunningletter + dunning_sms + dunning_call,
                                        cost_sms = (dunning_sms * 0.02),
                                        cost_dialler = (dunning_call * cost_dialler),
                                        cost_read = (totalreads * cost_admin),
                                        meter_read = totalreads,
                                        cost_ip = (totalips * cost_admin),
                                        ip = totalips,
                                        cost_email = (totalemails * cost_admin),
                                        emails = totalemails,
                                        cost_ivr = (ivr_calls * cost_ivr),
                                        ivr = ivr_calls,
                                        cost_acd = ((acd_calls * cost_acd) + (acd_calls * cost_agent)), # cost_payg_agent 
                                        acd = acd_calls,
                                        cost_retent = ((`RETEN FOTS` * cta_fots_ret[,'Electricity Unit Cost']) +
                                                       (`RETEN TELEI` * cta_in_ret[,'Electricity Unit Cost']) +
                                                       (`RETEN WEB` * cta_web_ret[,'Electricity Unit Cost']) + 
                                                       (if('RETEN TELEO' %in% colnames(customer_trans))
                                                        {
                                                          (`RETEN TELEO` * cta_out_ret[,'Electricity Unit Cost'])
                                                        } else 0) +
                                                       (`CRSSE FOTS` * cta_fots_ret[,'Electricity Unit Cost']) +
                                                       (`CRSSE TELEI` * cta_in_ret[,'Electricity Unit Cost']) +
                                                       (if('CRSSE TELEO' %in% colnames(customer_trans))
                                                         {
                                                           (`CRSSE TELEO` * cta_out_ret[,'Electricity Unit Cost'])
                                                         } else 0) +
                                                         (if('CRSSE WEB' %in% colnames(customer_trans))
                                                         {
                                                           (`CRSSE WEB` * cta_web_ret[,'Electricity Unit Cost'])
                                                         } else 0)),
                                        retentions = (`RETEN FOTS`  +
                                                         (`RETEN TELEI`) +
                                                         (`RETEN WEB`) + 
                                                         (if('RETEN TELEO' %in% colnames(customer_trans))
                                                         {
                                                           (`RETEN TELEO`)
                                                         } else 0) +
                                                         (`CRSSE FOTS` ) +
                                                         (`CRSSE TELEI`) +
                                                         (if('CRSSE TELEO' %in% colnames(customer_trans))
                                                         {
                                                           (`CRSSE TELEO`)
                                                         } else 0) +
                                                         (if('CRSSE WEB' %in% colnames(customer_trans))
                                                         {
                                                           (`CRSSE WEB`)
                                                         } else 0)),
                                        cost_winb = ((`CoS AcquisitionFOTS` * cta_fots_win[,'Electricity Unit Cost']) +
                                                     (`CoS AcquisitionTELEI` * cta_in_win[,'Electricity Unit Cost']) +
                                                     (if('Gas CoS AcquisitionFOTS' %in% colnames(customer_trans))
                                                       {
                                                       (`Gas CoS AcquisitionFOTS` * cta_fots_win[,'Electricity Unit Cost']) 
                                                       } else 0)+
                                                     (if('Gas CoS AcquisitionTELEI' %in% colnames(customer_trans))
                                                       {
                                                       (`Gas CoS AcquisitionTELEI` * cta_in_win[,'Electricity Unit Cost']) 
                                                       } else 0) +
                                                     (if('New ConnectionFOTS' %in% colnames(customer_trans))
                                                       {
                                                       (`New ConnectionFOTS` * cta_fots_win[,'Electricity Unit Cost']) 
                                                       } else 0) +
                                                     (if('New ConnectionTELEI' %in% colnames(customer_trans))
                                                       {
                                                       (`New ConnectionTELEI` * cta_in_win[,'Electricity Unit Cost'])
                                                       } else 0) +
                                                     (if('CoS AcquisitionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`CoS AcquisitionWEB` * cta_web_ret[,'Electricity Unit Cost'])
                                                       } else 0) +
                                                     (if('Gas CoS AcquisitionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`Gas CoS AcquisitionWEB` * cta_web_ret[,'Electricity Unit Cost'])
                                                       } else 0) +
                                                     (if('New ConnectionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`New ConnectionWEB` * cta_web_ret[,'Electricity Unit Cost'])
                                                       } else 0) +   
                                                     (if('Gas New ConnectionWEB' %in% colnames(customer_trans))
                                                      {
                                                        (`Gas New ConnectionWEB` * cta_web_ret[,'Electricity Unit Cost'])
                                                      } else 0)),
                                        winbacks = ((`CoS AcquisitionFOTS`) +
                                                       (`CoS AcquisitionTELEI`) +
                                                       (if('Gas CoS AcquisitionFOTS' %in% colnames(customer_trans))
                                                       {
                                                         (`Gas CoS AcquisitionFOTS`) 
                                                       } else 0)+
                                                       (if('Gas CoS AcquisitionTELEI' %in% colnames(customer_trans))
                                                       {
                                                         (`Gas CoS AcquisitionTELEI`) 
                                                       } else 0) +
                                                       (if('New ConnectionFOTS' %in% colnames(customer_trans))
                                                       {
                                                         (`New ConnectionFOTS`) 
                                                       } else 0) +
                                                       (if('New ConnectionTELEI' %in% colnames(customer_trans))
                                                       {
                                                         (`New ConnectionTELEI`)
                                                       } else 0) +
                                                       (if('CoS AcquisitionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`CoS AcquisitionWEB`)
                                                       } else 0) +
                                                       (if('Gas CoS AcquisitionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`Gas CoS AcquisitionWEB`)
                                                       } else 0) +
                                                       (if('New ConnectionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`New ConnectionWEB`)
                                                       } else 0) +   
                                                       (if('Gas New ConnectionWEB' %in% colnames(customer_trans))
                                                       {
                                                         (`Gas New ConnectionWEB`)
                                                       } else 0)),
                                        cost_marketing = cta_marketing,
                                        cost_industry = 0,
                                        cost_lifestyle = (payg_lifestyle * cta_payg_life),
                                        lifestyle = payg_lifestyle,
                                        cost_smart = (spayg_installs * cta_spayg),
                                        smart = spayg_installs,
                                        exgratia = ex_gratia_pay,
                                        cts_payroll = ((ctspayroll_comm[,'Electricity Unit Cost'] + ctspayroll_ops[,'Electricity Unit Cost']) /customers),
                                        cta_payroll = ((ctapayroll_comm[,'Electricity Unit Cost'] + ctspayroll_ops[,'Electricity Unit Cost']) /customers)
                                  ),
                                 by=contractaccount]


customer_costs[is.na(customer_costs)] <- 0
customer_costs$totalbilled[customer_trans$Ebiller=="Yes"] <- 0

customer_costs[, total_costs := (cost_bill + cost_payment + cost_dunning + cost_sms + cost_dialler + 
                                cost_read + cost_ip + cost_email + cost_ivr + cost_acd + cost_retent + cost_winb + 
                                cost_marketing + cost_industry + cost_lifestyle + cost_smart +
                                cts_payroll + cta_payroll)]
customer_costs[, CTS := (cost_bill + cost_payment + cost_dunning + cost_sms + cost_dialler + 
                                   cost_read + cost_ip + cost_email + cost_ivr + cost_acd + cts_payroll)]
customer_costs[, CTA := (cost_retent + cost_winb + cost_marketing + cost_industry + cost_lifestyle + cost_smart + cta_payroll)]
customer_costs[, Value := billed - total_costs - balance]#(paid + total_costs)]

#customer_costs[is.na(customer_costs)] <- 0
customer_costs$percentile <- ntile(customer_costs$Value, 10)
customer_value <- data.table(customer_costs)
#customer_value <- customer_value[, list(contractaccount=contractaccount)]



setkey(customer_value, contractaccount)
saveRDS(customer_value, '../data/customer_costs.rds')


