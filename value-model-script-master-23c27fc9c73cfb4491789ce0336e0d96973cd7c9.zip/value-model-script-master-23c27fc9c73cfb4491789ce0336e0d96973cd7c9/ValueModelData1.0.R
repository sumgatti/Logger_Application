
library(RODBC)
library(data.table)
library(plyr)
library(bit64)

connection <- odbcConnect("BI_Database")

#------------------------- billing Details --------------------------------------#

query <- 
"select	bill.ContractAccountNo, bill.BillingDate, bill.DocumentTypeDescription, sum(bill.[Amount]) as BillAmount	
from
(SELECT ca.ContractAccountNo, d1.DayDate as BillingDate, doc.DocumentTypeDescription, cl_b.[Amount] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactClearedBill] cl_b
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca	on cl_b.[ContractAccountSID] = ca.[ContractAccountSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDocumentType] doc on doc.DocumentTypeSID = cl_b.[DocumentTypeSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on cl_b.DateSID = d1.DateSID
union all
SELECT ca1.ContractAccountNo, d2.DayDate as BillingDate, doc1.DocumentTypeDescription, op_b.[Amount] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactOpenBill] op_b
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca1 on op_b.[ContractAccountSID] = ca1.[ContractAccountSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDocumentType] doc1 on doc1.DocumentTypeSID = op_b.[DocumentTypeSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d2 on op_b.DateSID = d2.DateSID) bill

where datediff(MONTH, bill.BillingDate, getdate()) <= 13 
group by bill.ContractAccountNo, bill.BillingDate, bill.DocumentTypeDescription"

data <- sqlQuery(connection, query)
bill_data <- data.table(data)
bill_data <- bill_data[, list(contractaccount=ContractAccountNo,date=as.IDate(BillingDate), 
                         activity=DocumentTypeDescription,amount=BillAmount)]

setkey(bill_data, contractaccount, date)
saveRDS(bill_data, '../data/billing.rds')

#--------------------- Payments Details ----------------------#
library(RODBC)
connection <- odbcConnect("BI_Database")

pay_query <-  
"select pay.ContractAccountNo, pay.PaymentDate, pay.DocumentTypeDescription, sum(pay.[Amount]) as PaymentAmount 
from (SELECT ca.ContractAccountNo, d1.DayDate as PaymentDate, doc.DocumentTypeDescription, cl_p.[Amount] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactClearedPayment] cl_p  
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca on cl_p.[ContractAccountSID] = ca.[ContractAccountSID]
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDocumentType] doc on doc.DocumentTypeSID = cl_p.[DocumentTypeSID]
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on cl_p.DateSID = d1.DateSID
union all
      SELECT ca1.ContractAccountNo, d2.DayDate as PaymentDate, doc1.DocumentTypeDescription, op_p.[Amount] * -1 
      FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactOpenPayment] op_p
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca1 on op_p.[ContractAccountSID] = ca1.[ContractAccountSID]
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDocumentType] doc1 on doc1.DocumentTypeSID = op_p.[DocumentTypeSID]
      join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d2 on op_p.DateSID = d2.DateSID ) pay
where datediff(MONTH, pay.PaymentDate, getdate()) <= 13 
group by pay.ContractAccountNo, pay.PaymentDate, pay.DocumentTypeDescription"

pay_data <- sqlQuery(connection, pay_query)
pay_data <- data.table(pay_data)
pay_data <- pay_data[, list(contractaccount=ContractAccountNo,date=as.IDate(PaymentDate), 
                              activity=DocumentTypeDescription,amount=PaymentAmount)]

setkey(pay_data, contractaccount, date)
saveRDS(pay_data, '../data/payments.rds')

odbcCloseAll()

#--------------------- Account Balance Details ----------------------#
library(RODBC)
connection <- odbcConnect("BI_Database")

bal_query <-  
  "SELECT cast([ContractAccountNumber] as int) as ContractAccountNumber,[auDateEffectiveStart] as BalanceEffective, 'Balance' as Activity, [CAOpenBalance] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimCAOpenBalance] ca
where datediff(MONTH, [auDateEffectiveStart], getdate()) <= 13 and auCurrentRow = 1"

bal_data <- sqlQuery(connection, bal_query)
bal_data <- data.table(bal_data)

bal_data <- bal_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(BalanceEffective), 
                            activity=Activity,amount=CAOpenBalance)]

setkey(bal_data, contractaccount, date)
saveRDS(bal_data, '../data/balance.rds')

odbcCloseAll()

# ===============  All Customer switch actions for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

switch_query <-   
  "SELECT ca.[ContractAccountNo], sdate3.DayDate as ChangeDate, stype.[Description] + cc.SaleTypeCode as TypeDescription, 1 as Switchcount
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimSwitchDocumentHeader] sdoc
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSwitchType] stype on sdoc.[SwitchTypeSID] = stype.[SwitchTypeSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSwitchServiceStatus] sstatus on sdoc.[SwitchServiceStatusSID] = sstatus.[SwitchServiceStatusSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] sdate3 on sdoc.[ChangedDateSID] = sdate3.DateSID
left join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca on sdoc.ContractAccountSID = ca.ContractAccountSID
join (SELECT srp_con.ContractAccountNo, cont.ContractSID, org.[Code] as SaleTypeCode FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimCRMContract] cont  
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSalesType] st_sale on cont.SalesTypeSID = st_sale.SalesTypeSID
join (SELECT ContractSID, [ContractNo], ContractAccountNo, MoveInDate, MoveOutDate FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContract]) srp_con 
on cont.ContractSID = srp_con.ContractSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSalesOrigin] org on cont.SalesOriginSID = org.[SalesOriginSID]
where auCurrentRow = 1) cc on ca.ContractAccountNo =  cc.ContractAccountNo
where sdoc.[auCurrentRow] = 1 and datediff(MONTH, sdate3.DayDate, getdate()) <= 13 and stype.[Code] in  ('81', '91', '86', '96')
and sstatus.[Code]  = 'Z3' and ca.ContractAccountNo != 0	"

switch_data <- sqlQuery(connection, switch_query)
switch_data <- data.table(switch_data)
switch_data <- switch_data[, list(contractaccount=ContractAccountNo,date=as.IDate(ChangeDate), 
                            activity=TypeDescription,amount=Switchcount)]

setkey(switch_data, contractaccount, date)
saveRDS(switch_data, '../data/switches.rds')

odbcCloseAll()

# ===============  All Customer dunning actions for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

dunn_query <-   
 "SELECT ca.ContractAccountNo, d1.DayDate as IssueDate, [ApplicationForm], [Balance] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactDunning] dun
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca on dun.[ContractAccountSID] = ca.[ContractAccountSID]
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on dun.IssueDateSID = d1.DateSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDunningProcedure] st_dp on dun.DunningProcedureSID = st_dp.DunningProcedureSID
where datediff(MONTH, d1.DayDate, getdate()) <= 13 and ca.ContractAccountNo != 0"

dunn_data <- sqlQuery(connection, dunn_query)
dunn_data <- data.table(dunn_data)
dunn_data <- dunn_data[, list(contractaccount=ContractAccountNo,date=as.IDate(IssueDate), 
                                  activity=ApplicationForm,amount=Balance)]

setkey(dunn_data, contractaccount, date)
saveRDS(dunn_data, '../data/dunning.rds')

odbcCloseAll()

# ===============  All Customer emails for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

email_query <-   
  "SELECT bp2.ContractAccountNumber, d1.DayDate as ChangedDate, em.[EmailID], 1 as Emailcount 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactCRMEmail] em
join (select bp.BusinessPartnerNo, m2.CA as ContractAccountNumber, bp.[BusinessPartnerEmail] 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimBusinessPartner] bp
join (select BusinessPartnerNumber, max(ContractAccountNumber) as CA, max(Move_In) as MI, max(Move_Out) as MO 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[SPSS].[CurrentPosition] group by BusinessPartnerNumber) m2
on bp.BusinessPartnerNo = m2.BusinessPartnerNumber
where bp.[auCurrentRow] =1 and bp.[BusinessPartnerEmail] != '') bp2	
on upper(em.[SenderEmail]) = upper(bp2.[BusinessPartnerEmail])
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on em.ChangedOnDateSID = d1.DateSID
where datediff(MONTH, d1.DayDate, getdate()) <= 13 and bp2.ContractAccountNumber is not null"

email_data <- sqlQuery(connection, email_query)
email_data <- data.table(email_data)
email_data <- email_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(ChangedDate), 
                              activity="Email",amount=Emailcount)]

setkey(email_data, contractaccount, date)
saveRDS(email_data, '../data/emails.rds')

odbcCloseAll()

# ===============  All Customer interactions for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

int_query <-   
  "SELECT bp2.ContractAccountNumber, d1.DayDate as CreatedDate, st_cat.Description as ActivityCategory, 1 as Interactioncount 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactCRMInteraction] int
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on int.CreatedDateSID = d1.DateSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatActivityCategory] st_cat on int.ActivityCategorySID = st_cat.ActivityCategorySID
join (select bp.BusinessPartnerSID, bp.BusinessPartnerNo, CA as ContractAccountNumber 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimBusinessPartner] bp
      join (select BusinessPartnerNumber , max(ContractAccountNumber) as CA, max(Move_In) as MI, max(Move_Out) as MO 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[SPSS].[CurrentPosition] group by BusinessPartnerNumber) m2
      on bp.BusinessPartnerNo = m2.BusinessPartnerNumber) bp2
on int.ContactPartnerSID = bp2.BusinessPartnerSID
where bp2.BusinessPartnerNo != 0 and datediff(MONTH, d1.DayDate, getdate()) <= 13"

int_data <- sqlQuery(connection, int_query)
int_data <- data.table(int_data)
int_data <- int_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(CreatedDate), 
                                activity=ActivityCategory,amount=Interactioncount)]

setkey(int_data, contractaccount, date)
saveRDS(int_data, '../data/interactions.rds')

odbcCloseAll()


# ===============  All Customer activities for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

act_query <-   
  "SELECT bp2.ContractAccountNumber, d3.DayDate as CreatedDate, case when st_ag.Description  = 'UNKNOWN' then ActivityDescription else st_ag.Description + ' ' + st_ar.Description end as ActivityReason, 1 as activitycount 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactCRMActivity] act
join (select bp.BusinessPartnerSID, bp.BusinessPartnerNo, CA as ContractAccountNumber 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimBusinessPartner] bp
      join (select BusinessPartnerNumber , max(ContractAccountNumber) as CA, max(Move_In) as MI, max(Move_Out) as MO 
from virtsql203s.[DM_ESB_ELECTRICIRELAND].[SPSS].[CurrentPosition] group by BusinessPartnerNumber) m2
      on bp.BusinessPartnerNo = m2.BusinessPartnerNumber) bp2
on act.ContactPartnerSID = bp2.BusinessPartnerSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d3 on act.[CreatedONDateSID] = d3.DateSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatActivityReasonCode] st_ar	on act.ReasonCodeSID = st_ar.ReasonCodeSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatActivityReasonGroup] st_ag on act.ReasonGroupSID = st_ag.ReasonGroupSID
where bp2.BusinessPartnerNo != 0 and datediff(MONTH, d3.DayDate, getdate()) <= 13"


act_data <- sqlQuery(connection, act_query)
act_data <- data.table(act_data)
act_data <- act_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(CreatedDate), 
                            activity=ActivityReason,amount=activitycount)]

setkey(act_data, contractaccount, date)
saveRDS(act_data, '../data/activities.rds')

odbcCloseAll()

# ===============  All Customer meter readings for the last 13 months =============== ***/
library(RODBC)
connection <- odbcConnect("BI_Database")

mr_query <-   
"SELECT m1.ContractAccountNo, d1.DayDate as ReadingDate, st_mt.MeterReadingTypeDescription, [MeterRead] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactMeterReading] mr
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatMeterReadingType] st_mt	on mr.MeterReadingTypeSID = st_mt.MeterReadingTypeSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on mr.MeterReadDateSID = d1.DateSID
join (select c.[TechnicalInstallationNo], c.ContractAccountNo, MoveInDate, MoveOutDate from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContract] c) m1
on mr.InstallationNumber = m1.TechnicalInstallationNo
where m1.MoveInDate < d1.DayDate and m1.MoveOutDate > d1.DayDate and datediff(MONTH, d1.DayDate, getdate()) <= 13"


mr_data <- sqlQuery(connection, mr_query)
mr_data <- data.table(mr_data)
mr_data <- mr_data[, list(contractaccount=ContractAccountNo,date=as.IDate(ReadingDate), 
                            activity=MeterReadingTypeDescription,amount=MeterRead)]

setkey(mr_data, contractaccount, date)
saveRDS(mr_data, '../data/meter_reads.rds')

odbcCloseAll()


# ===============  All Customer instalments plans for the last 13 months =============== 
library(RODBC)
connection <- odbcConnect("BI_Database")

ip_query <-   
  "SELECT ca.ContractAccountNo, d1.DayDate as PostingDate, st_ca.[Description] as CategoryDescription, [PaymentAmount] 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactInstalmentPlanHeader] ip
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContractAccount] ca on ip.ContractAccountSID = ca.ContractAccountSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1 on ip.[PostingDateSID] = d1.DateSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatInstalmentPlanCategory] st_ca on ip.[InstalmentPlanCategorySID] = st_ca.[InstalmentPlanCategorySID]
where datediff(MONTH, d1.DayDate, getdate()) <= 13"

ip_data <- sqlQuery(connection, ip_query)
ip_data <- data.table(ip_data)
ip_data <- ip_data[, list(contractaccount=ContractAccountNo,date=as.IDate(PostingDate), 
                          activity=CategoryDescription,amount=PaymentAmount)]

setkey(ip_data, contractaccount, date)
saveRDS(ip_data, '../data/instalments.rds')

odbcCloseAll()

# ===============  All Customer PAYG meter installed for the last 13 months =============== ***/
library(RODBC)
connection <- odbcConnect("BI_Database")

payg_query <-   
"select [LibertyCustomerMPRN] as MPRN, date3.DayDate as InstallDate,date3.DayDate as InDate, LibertyMeterNo + 'PAYG meter install' as ActivityType 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimLibertyCustomer] lib
join  virtsql203s.[DM_ESB_ELECTRICIRELAND].DWH.DimDate date3 on lib.[LibertyCustomerInstallDateSID] = date3.DateSID	
where datediff(MONTH, date3.DayDate, getdate()) <= 13 and lib.auCurrentRow = 1 and left(lib.LibertyMeterNo ,1) in ('9', 'E', 'K')"

payg_data <- sqlQuery(connection, payg_query)

odbcCloseAll()


# ===============  All Customer retention sales for the last 13 months =============== ***/
library(RODBC)
connection <- odbcConnect("BI_Database")

ret_query <-   
  "SELECT srp_con.ContractAccountNo, d2.DayDate as ChangedDate, st_sale.Code  + ' '  +org.[Code] as SaleTypeCode, 1 as Retentioncount 
FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimCRMContract] cont  
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSalesType] st_sale on cont.SalesTypeSID = st_sale.SalesTypeSID
join (SELECT ContractSID, [ContractNo], ContractAccountNo, MoveInDate, MoveOutDate FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimContract]) srp_con 
on cont.ContractSID = srp_con.ContractSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d2 on cont.ChangedDateSID = d2.DateSID
join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[DimStatSalesOrigin] org on cont.SalesOriginSID = org.[SalesOriginSID]
where datediff(MONTH, d2.DayDate, getdate()) <= 13 and  st_sale.Code in ('RETEN', 'CRSSE') and auCurrentRow = 1"

ret_data <- sqlQuery(connection, ret_query)

ret_data <- data.table(ret_data)
ret_data <- ret_data[, list(contractaccount=ContractAccountNo,date=as.IDate(ChangedDate), 
                          activity=SaleTypeCode,amount=Retentioncount)]

setkey(ret_data, contractaccount, date)
saveRDS(ret_data, '../data/retention.rds')

odbcCloseAll()

# ===============  All Customer ivr and ACD calls for the last 13 months =============== ***/
library(RODBC)
connection <- odbcConnect("BI_Database")

call_query <-   
"SELECT isnull(ivr.[IVRCallLogID], acd.CallLogID) as CallLogID
,isnull(ivr.[EndDateTime], acd.[TerminatedDate]) as Call_EndTime
,ivr.[ContractAccountNumber]
,ivr.ivr_count
,isnull(ivr.formatedivrphone, acd.formatedacdphone) as formatedphone
,acd.[LocalUserID]
,acd.[AssignedWorkGroup]
,acd_count
FROM (select [IVRCallLogID],[EndDateTime], [ContractAccountNumber]
      ,case when [IVRCallLogID]  is null then 0 else 1 end as ivr_count
      ,(case when left(ltrim(rtrim([CLI])),3) = 'sip' then ''
        when left(ltrim(rtrim([CLI])),2) = '44' and len([CLI]) = 12 then '+' + [CLI]
        when left(ltrim(rtrim([CLI])),3) = '044' and len(ltrim(rtrim([CLI]))) > 12 then '+44'+substring([CLI], Patindex('%[^0 ]%', [CLI] + ' '), len([CLI]))
        when left(ltrim(rtrim([CLI])),4) = '0044' and len(ltrim(rtrim([CLI]))) > 12 then '+'+substring([CLI], Patindex('%[^0 ]%', [CLI] + ' '), len([CLI]))
        when left(ltrim(rtrim([CLI])),1) = '0' and len(ltrim(rtrim([CLI]))) = 10 then '+353'+substring([CLI], Patindex('%[^0 ]%', [CLI] + ' '), len([CLI]))
        when left(ltrim(rtrim([CLI])),1) = '0' and len(ltrim(rtrim([CLI]))) = 9 then '+353'+substring([CLI], Patindex('%[^0 ]%', [CLI] + ' '), len([CLI]))
        when left(ltrim(rtrim([CLI])),1) like '[^a-zA-Z0-9]%' then ''
        when left(ltrim(rtrim([CLI])),4)='+353' then ltrim([CLI])
        when left(ltrim(rtrim([CLI])),1)!='0' then '+353' + [CLI]
        else '' end) as formatedivrphone 
      from [DM_ESB_ELECTRICIRELAND].[DWH].[DimAbtranIVRCallLog]
      where datediff(MONTH, [EndDateTime], getdate()) <= 13   )ivr
full outer join 
(SELECT [CallId] as CallLogID,[LocalUserID],[AssignedWorkGroup],[TerminatedDate], case when [AssignedWorkGroup] = '-' then 0 else 1 end as acd_count
  ,(case when left(ltrim(rtrim([TelephoneNumber])),3) = 'sip' then ''
    when left(ltrim(rtrim([TelephoneNumber])),2) = '44' and len([TelephoneNumber]) = 12 then '+' + [TelephoneNumber]
    when left(ltrim(rtrim([TelephoneNumber])),3) = '044' and len(ltrim(rtrim([TelephoneNumber]))) > 12 then '+44'+substring([TelephoneNumber], Patindex('%[^0 ]%', [TelephoneNumber] + ' '), len([TelephoneNumber]))
    when left(ltrim(rtrim([TelephoneNumber])),4) = '0044' and len(ltrim(rtrim([TelephoneNumber]))) > 12 then '+'+substring([TelephoneNumber], Patindex('%[^0 ]%', [TelephoneNumber] + ' '), len([TelephoneNumber]))
    when left(ltrim(rtrim([TelephoneNumber])),1) = '0' and len(ltrim(rtrim([TelephoneNumber]))) = 10 then '+353'+substring([TelephoneNumber], Patindex('%[^0 ]%', [TelephoneNumber] + ' '), len([TelephoneNumber]))
    when left(ltrim(rtrim([TelephoneNumber])),1) = '0' and len(ltrim(rtrim([TelephoneNumber]))) = 9 then '+353'+substring([TelephoneNumber], Patindex('%[^0 ]%', [TelephoneNumber] + ' '), len([TelephoneNumber]))
    when left(ltrim(rtrim([TelephoneNumber])),1) like '[^a-zA-Z0-9]%' then ''
    when left(ltrim(rtrim([TelephoneNumber])),4)='+353' then ltrim([TelephoneNumber])
    when left(ltrim(rtrim([TelephoneNumber])),1)!='0' then '+353' + [TelephoneNumber]
    else '' end) as formatedacdphone 
  FROM [DM_ESB_ELECTRICIRELAND].[DWH].[DimAbtranACDCall] where datediff(MONTH, [TerminatedDate], getdate()) <= 13)  acd
on ivr.IVRCallLogID = acd.CallLogID"

call_data <- sqlQuery(connection, call_query)

odbcCloseAll()


# ===============  All Customer web activities for the last 13 months =============== ***/
library(RODBC)
connection <- odbcConnect("BI_Database")

web_query <-   
  "SELECT [ContractAccount] as ContractAccountNumber, ca.[Description] as WebActivity, cast([TimeStamp] as date) as WebDate, 1 as webcount 
FROM [DM_ESB_ELECTRICIRELAND].[ROI].[Events] ev
join [DM_ESB_ELECTRICIRELAND].[ROI].[EventCategory] ca on ev.CategoryId = ca.Id
where datediff(MONTH, [TimeStamp], getdate()) <= 13"

web_data <- sqlQuery(connection, web_query)
web_data <- data.table(web_data)
web_data <- web_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(WebDate), 
                              activity=WebActivity,amount=webcount)]

setkey(web_data, contractaccount, date)
saveRDS(web_data, '../data/web_activities.rds')

odbcCloseAll()

# ===============  Residential Customers only =============== ***/
library(RODBC)
connection <- odbcConnect("BI_DM_081")

res_query <-   
  "SELECT [ContractAccountNumber],[MPRN],[Move_In],[Move_Out],[InstallationNumber],[site_region],[Dunning_Procedure],[MeterConfigCode],[RateCategoryCode]
,[RateCategoryDescription],[CustomerType],[FuelType],[SpecialNeeds],[DuosGroupCode],[FEA],[IrishAccount],[Staff],[Ebiller],[GasNetwork],[MeterLocation],[ValidEmail]
,[ValidTelephone],[ProductID],[ProductDescription],[Age],[PaymentType],[DualFlg],[LoyaltyFlag],[PAYGType],[ValueBand],[AnnualKwh],[Tenure],[BehaviourSegment]
,[DiscountVal],Telephone, GasNetwork FROM [BI].[dbo].[ResStrategy_CVM_CP] where CustomerType = 'Residential'"

res_data <- sqlQuery(connection, res_query)

res_data <- data.table(res_data)
res_data <- res_data[, list(contractaccount=ContractAccountNumber,mprn=MPRN,Move_In=as.IDate(Move_In),Move_Out=as.IDate(Move_Out),
                            InstallationNumber,site_region,Dunning_Procedure,MeterConfigCode,RateCategoryCode,RateCategoryDescription,
                            CustomerType,FuelType,SpecialNeeds,DuosGroupCode,FEA,IrishAccount,Staff,Ebiller,MeterLocation,ValidEmail,
                            ValidTelephone,ProductID,ProductDescription,Age,PaymentType,DualFlg,LoyaltyFlag,PAYGType,ValueBand,
                            AnnualKwh,Tenure,BehaviourSegment,DiscountVal,Telephone, GasNetwork)]

res_data <- unique(res_data)
setkey(res_data, contractaccount)
saveRDS(res_data, '../data/res_customers.rds')

odbcCloseAll()

#====================== Merge PAYG data with customer information ==========================
library(sqldf)

payg_data <- data.table(payg_data)
payg_data <- payg_data[, list(MPRN,InstallDate=as.IDate(InstallDate),InDate, ActivityType)]

total_payg = sqldf("select contractaccount, lib1.InstallDate,lib1.ActivityType,InDate, 1 as payg_installcount 
                    from payg_data as lib1
                    join (select contractaccount, mprn, Move_In, Move_Out from res_data) as cp on cp.MPRN = lib1.MPRN
                    where lib1.InstallDate >= cp.Move_In and lib1.InstallDate < cp.Move_Out")

total_payg <- data.table(total_payg)
total_payg <- total_payg[, list(contractaccount=contractaccount,date=as.IDate(InDate), 
                          activity=lib1.ActivityType,amount=payg_installcount)]

setkey(total_payg, contractaccount, date)
saveRDS(total_payg, '../data/payg.rds')

#====================== Merge all Call data with customer information ==========================

total_calls = sqldf("select calls.ContractAccountNumber, Call_EndTime, ivr_count, acd_count from call_data calls
                  left join res_data m1 on calls.[ContractAccountNumber] = m1.contractaccount
                  where calls.ContractAccountNumber != ''
                  union all
                  select m2.contractaccount, calls2.Call_EndTime, calls2.ivr_count, calls2.acd_count from call_data calls2
                  left join (select distinct c.Telephone, c.contractaccount from res_data c
                       join (select Telephone, max(contractaccount) as CA, max(Move_In) as MI, max(Move_Out) as MO from res_data group by Telephone) c1 
                  on c.contractaccount = c1.CA and c.Move_Out = c1.MO and c.Move_In = c1.MI) m2
                  on calls2.formatedphone = m2.Telephone
                  where calls2.formatedphone != '' and calls2.ContractAccountNumber = '' ")

total_ivr <- data.table(total_calls)
total_ivr <- total_ivr[, list(contractaccount=ContractAccountNumber,date=as.IDate(Call_EndTime), 
                            activity="IVR Call",amount=ivr_count)]

setkey(total_ivr, contractaccount, date)
saveRDS(total_ivr, '../data/ivr_calls.rds')


#====================== Merge ACD data with customer information ==========================

total_acd <- data.table(total_calls)
total_acd <- total_acd[, list(contractaccount=ContractAccountNumber,date=as.IDate(Call_EndTime), 
                              activity="ACD Call",amount=acd_count)]

setkey(total_acd, contractaccount, date)
saveRDS(total_acd, '../data/acd_calls.rds')

#========================== smart PAYG installs =====================================
library(RODBC)
connection <- odbcConnect("BI_Database")

spayg_query <-   
  "
select distinct CP.ContractAccountNumber, start.StartDate as date, 1 as amount FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactProfile_Device] dev
JOIN virtsql203s.[DM_ESB_ELECTRICIRELAND].SPSS.CurrentPosition CP on dev.ProfileDeviceMPRN = CP.MPRN  
join (select ProfileDeviceMPRN, min([ProfileDeviceStartTime]) as StartDate from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactProfile_Device] group by ProfileDeviceMPRN
) start on start.ProfileDeviceMPRN = dev.ProfileDeviceMPRN 
where datediff(MONTH, start.StartDate, getdate()) <= 13 and cp.Move_In >= start.StartDate"

spay_data <- sqlQuery(connection, spayg_query)

spay_data <- data.table(spay_data)
spay_data <- spay_data[, list(contractaccount=ContractAccountNumber,date=as.IDate(date), 
                              activity="SPAYG install",amount=amount)]

spay_data <- unique(spay_data)
setkey(spay_data, contractaccount)
saveRDS(spay_data, '../data/spayinstalls.rds')

odbcCloseAll()

#=========================== Sample Customer set ======================================

library(RODBC)
connection <- odbcConnect("SPSS_Database")

res_sample_query <-   
  "SELECT cast([ContractAccountNumber] as int) as contractaccount
FROM [SPSS].[dbo].[VL_RandomRes]"

res_sampledata <- sqlQuery(connection, res_sample_query)

res_sampledata <- data.table(res_sampledata)
res_sampledata <- res_sampledata[, list(contractaccount=contractaccount)]

res_sampledata <- unique(res_sampledata)
setkey(res_sampledata, contractaccount)
saveRDS(res_sampledata, '../data/res_samplecustomers.rds')

odbcCloseAll()


#=========================== Ex Gratia payments ======================================
# added 25th Sept 17 as per MH meeting

library(RODBC)
connection <- odbcConnect("BI_Database")

res_exgratia <-   
"select [ContractAccountNo], max(d1.DayDate) as MostRecentAdjust, sum([TotalLineAmount]) as TotalAdjustment, count([DocumentNumber]) as NumberAdjustments
FROM [DM_ESB_ELECTRICIRELAND].[DWH].[FactPrintDocumentLineItems] pd
join [DM_ESB_ELECTRICIRELAND].[DWH].DimDate d1 on pd.PostingDateSID = d1.DateSID
join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatBillingLineItemType] st_bl on pd.BillingLineItemTypeSID = st_bl.BillingLineItemTypeSID
where st_bl.[BillingLineItemTypeCode] = 'ACCMNT' and TotalLineAmount = -175 
and datediff(MONTH, d1.DayDate, getdate()) <= 13
group by [ContractAccountNo]"

res_exgratia <- sqlQuery(connection, res_exgratia)

res_exgratia <- data.table(res_exgratia)
res_exgratia <- res_exgratia[, list(contractaccount=ContractAccountNo, date=as.IDate(MostRecentAdjust),
                                    activity="Ex-Gratia Payment",amount=TotalAdjustment)]


res_exgratia <- unique(res_exgratia)
setkey(res_exgratia, contractaccount)
saveRDS(res_exgratia, '../data/res_res_exgratia.rds')

odbcCloseAll()