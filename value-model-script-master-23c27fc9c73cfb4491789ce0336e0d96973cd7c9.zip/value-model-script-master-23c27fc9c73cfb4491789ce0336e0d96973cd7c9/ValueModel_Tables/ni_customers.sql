SELECT * FROM (SELECT r.contractaccountno, COUNT(*) cc FROM storehouse_liberty.ni_liberty_customers c
JOIN `360customer`.attributes_residential r ON c.mprn = r.mprn
WHERE c.meterno LIKE 'K%' AND
r.moveindate <= c.meterinstalldate AND
r.moveoutdate >= c.meterinstalldate AND
c.meterinstalldate >= to_date(date_sub(current_date ,396 ))
GROUP BY r.contractaccountno) a
WHERE cc > 1