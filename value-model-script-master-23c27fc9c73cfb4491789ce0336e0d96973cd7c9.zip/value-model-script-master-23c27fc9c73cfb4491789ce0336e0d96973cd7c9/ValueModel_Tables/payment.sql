
-------------Payments per customer ----------------

SELECT contractaccountno,
SUM(dd_count) dd_count,
SUM(dd_paymentamount) dd_paymentamount,
SUM(po_count) po_count,
SUM(po_paymentamount) po_paymentamount,
SUM(oth_count) other_count,
SUM(oth_paymentamount) other_paymentamount,
SUM(dd_count + po_count + oth_count) total_paymentcount,
SUM(dd_paymentamount + po_paymentamount + oth_paymentamount) total_paymentamount
FROM (SELECT p.contractaccountno,
p.documenttypedescription,
p.paymentdate,
CASE WHEN documenttypedescription LIKE "%V.A.D.D%" OR documenttypedescription LIKE "%Equaliser%" OR documenttypedescription LIKE "%EFT%" THEN 1 ELSE 0 END AS dd_count ,
CASE WHEN documenttypedescription LIKE "%V.A.D.D%" OR documenttypedescription LIKE "%Equaliser%" OR documenttypedescription LIKE "%EFT%" THEN paymentamount ELSE 0.0 END AS dd_paymentamount ,
CASE WHEN documenttypedescription LIKE "%Post%" OR documenttypedescription LIKE "%Cash%" THEN 1 ELSE 0 END AS po_count,
CASE WHEN documenttypedescription LIKE "%Post%" OR documenttypedescription LIKE "%Cash%" THEN paymentamount ELSE 0.0 END AS po_paymentamount,
CASE WHEN documenttypedescription NOT LIKE "%V.A.D.D%" AND documenttypedescription NOT LIKE "%Equaliser%" AND documenttypedescription NOT LIKE "%EFT%" AND documenttypedescription NOT LIKE "%Post%" AND documenttypedescription NOT LIKE "%Cash%" THEN 1 ELSE 0 END AS oth_count,
CASE WHEN documenttypedescription NOT LIKE "%V.A.D.D%" AND documenttypedescription NOT LIKE "%Equaliser%" AND documenttypedescription NOT LIKE "%EFT%" AND documenttypedescription NOT LIKE "%Post%" AND documenttypedescription NOT LIKE "%Cash%" THEN paymentamount ELSE 0.0 END AS oth_paymentamount
FROM storehouse_cmdm.payment p
JOIN value_model.residential_customers r ON r.contractaccountno = p.contractaccountno) pp
WHERE paymentdate >= to_date(date_sub(current_date ,396 ))
GROUP BY pp.contractaccountno