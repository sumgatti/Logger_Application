value = costs$Value
CTA =  costs$CTA
CTS = costs$CTS
billed = costs$billed
cost_total = costs$total_costs
percentiled = customer_info$percentile

plot(value, costs, xlab="value", ylab="total_costs")
#abline(lm(value ~ total_costs))
setwd("P:/Documents/R_Code/ValueModel/data")
data_residential <- readRDS('../data/res_customers.rds')
costs <- readRDS('../data/customer_costs.rds')
customer_info <-merge(x= data_residential,y = costs, by = "contractaccount")
fea <-customer_info %>% 
  filter(PAYGType == 'SmartPAYG')


ivrcalls <-customer_info %>% 
  filter(ivr > 150)
res <- res_data %>% filter(contractaccount == '950196468')

accfilter <- customer_info %>%
  filter(contractaccount == '950196468')

callfilter <- total_acd %>%
      filter(ContractAccountNumber == '950196468')


calls <- total_acd %>% 
        group_by(ContractAccountNumber) %>% 
        summarise(sumivr=sum(ivr_count), sumacd= sum(acd_count))

ebillers <- customer_info %>% 
  #filter(Ebiller == "Yes") %>% 
  group_by(percentile, Ebiller) %>% 
  summarise(number = n()) 

with(ebillers, table(percentile, Ebiller))
with(customer_info, table(percentile, Ebiller)/sum(table(percentile, Ebiller))*100)

ebill <- table(customer_info$Ebiller, customer_info$percentile)

selection <- customer_info %>% select("Ebiller", "percentile")
prop.table(table(selection), 2)*100


exgratia <- customer_costs %>% 
  group_by(contractaccount) %>% 
  summarise(sumivr=sum(ex_gratia_pay.x), sumacd= sum(ex_gratia_pay.y))


p<-ggplot(customer_info, aes(x=billed, y=Value, color = percentile)) +
  geom_point() +
  lims(x=c(-8000,8000),y=c(-8000,8000)) +
  theme_minimal() +
  coord_fixed() +  
  geom_vline(xintercept = 5, color = "darkblue", size = 2) + geom_hline(yintercept = 5, color = "darkblue", size = 2) 
p


hist(value, main="Binning of Customer Value", xlab = "Frequency", border = "grey", col= "light blue", breaks = 10)
lines(density(value))
dens <- density(value)
plot(dens, frame = FALSE, col = "steelblue", main = "Density Plot of Value")
polygon(dens, col = "steelblue")


p<- ggplot(customer_costs, aes(x=Value, y=exgratia)) +
  geom_point(shape=1)  


p<- ggplot(ivrcalls, aes(x=acd, y=ivr)) +
  geom_point() +
  #geom_text(data=calls, aes(label=ContractAccountNumber)) +
  theme_classic() 

p+scale_color_brewer(palette="PuRd")

acdcalls <-customer_info %>% 
  filter(acd > 150)
p<- ggplot(acdcalls, aes(x=ivr, y=acd)) +
  geom_point() +
  #geom_text(data=acdcalls, aes(label=contractaccount)) +
  theme_classic() 

p+scale_color_brewer(palette="PuRd")

ggplot(costs, aes(x=ex_gratia_pay.y, y=Value)) + 
  geom_point(shape=1, color="blue", size=5) +
  #geom_text(label=contractaccount) +
  geom_smooth(method=lm, se=FALSE, linetype="dashed",
              color="darkred", fill="blue")
  
  
  ggplot(customer_costs, aes(x=CTS, y=value)) +
    geom_point() + 
    geom_text(label=rownames(customer_costs))
  
  
  sp <- ggplot(customer_costs, aes(x=Value, y=exgratia)) +
    geom_point()
  sp + geom_density_2d()
  
  sp + stat_density_2d(aes(fill = ..level..), geom="polygon")
  
  sp + stat_density_2d(aes(fill = ..level..), geom="polygon")+
    scale_fill_gradient(low="blue", high="red")
 
  
  p <- ggplot(customer_costs, aes(costs, value, color = value > 12000 ))+
    geom_point()
  p + stat_ellipse(type = "norm")
  
  
  p <- ggplot(customer_costs, aes(CTS, value))
  p + geom_bin2d()
  
valuescore <- value < 200
new_valuedf <-  data.frame(customer_costs, valuescore)
  

scatterPlot <- ggplot(new_valuedf,aes(value, total_costs, color=valuescore)) + 
  geom_point() + 
  scale_color_manual(values = c('#999999','#E69F00')) + 
  theme(legend.position=c(0,1), legend.justification=c(0,1))
scatterPlot

xdensity <- ggplot(new_valuedf, aes(value, fill=valuescore)) + 
  geom_density(alpha=.5) + 
  scale_fill_manual(values = c('#999999','#E69F00')) + 
  theme(legend.position = "none")
xdensity


ydensity <- ggplot(new_valuedf, aes(total_costs, fill=valuescore)) + 
  geom_density(alpha=.5) + 
  scale_fill_manual(values = c('#999999','#E69F00')) + 
  theme(legend.position = "none")
ydensity

blankPlot <- ggplot()+geom_blank(aes(1,1))+
  theme(plot.background = element_blank(), 
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), 
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(), 
        axis.text.y = element_blank(),
        axis.ticks = element_blank()
  )

install.packages("gridExtra")
library("gridExtra")
grid.arrange(xdensity, blankPlot, scatterPlot, ydensity, 
             ncol=2, nrow=2, widths=c(4, 1.4), heights=c(1.4, 4))


customer_info <- data_residential %>% select(contractaccount, DualFlg, Move_In, GasNetwork, LoyaltyFlag, PAYGType, 
                                              Tenure, Age, ProductID,
                                              Ebiller, Staff, FuelType, site_region, DuosGroupCode, FEA, PaymentType)

customer_info$mi_year <- as.numeric(format(customer_info$Move_In,'%Y'))
cost_info <- customer_costs %>% select(contractaccount, billed,CTA, CTS, Value)
customer_info <-merge(x= customer_info,y = cost_info, by = "contractaccount")


ggplot(customer_info, aes(x=CTS, y=Value, color = dual)) + 
  geom_point(data=subset(customer_info,Staff=='Yes'),shape=17)  

ggplot(subset(customer_info,cond =="Yes")) + 
  geom_point(aes(Value, CTS, group=cond, colour=cond)) 

customer_info[is.na(customer_info$DualFlg)] <- 'Unk'
dual <- customer_info$Staff == 'Yes'

customer_info[is.na(customer_info$GasNetwork)] <- 'Unk'
cond <- customer_info$DuosGroupCode
customer_info$cond <- paste(customer_info$DualFlg, customer_info$GasNetwork)

ggplot(customer_info, aes(x=exgratia, y=Value, color = cond)) + geom_point(shape=9, size=3)

ggplot(customer_info, aes(x=exgratia, y=Value)) + geom_point(shape=2, size=4)  

ggplot(customer_info, aes(x=exgratia, y=Value)) + 
  geom_point(shape=1, color="blue", size=5) +
  #geom_text(label=contractaccount) +
  geom_smooth(method=lm, se=FALSE, linetype="dashed",
              color="darkred", fill="blue")

customer_info$percentile <- with(temp, customer_info(value, 
                                breaks=quantile(value, probs=seq(0,1, by=0.25), na.rm=TRUE), 
                                include.lowest=TRUE))

customer_info$percentile <- ntile(customer_info$Value, 10)

customer_info[order(customer_info$Value),]
val <- customer_info[,Value]
x<- cut(val, 10, include.lowest=TRUE, labels=c("Low", "Med", "High"))
table(x)

ggplot(customer_info, aes(x=CTS, y=Value, color = percentile)) + geom_point(shape=17) 

ggplot(customer_info, aes(Value, percentile)) +
  geom_jitter(aes(color = percentile), size = 0.5)


p <- ggplot(low_value, aes(x=percentile, y=Value))
p <- p + geom_point(aes(color = dual))
p + scale_color_manual(values=c("#999999", "#E69F00", "#56B4E9"))
p + scale_color_brewer(palette="PuRd")

customer_info[percentile == 1]

customer_info[, sum(Value), by = mi_year]

df <- customer_info %>% 
  group_by(DualFlg, percentile) %>%
  summarise(tot = sum(Value), count = length(Value)) %>%
  arrange(desc(tot))

low_value <- filter(customer_info, percentile < 4)

low_value %>% 
  group_by(DualFlg, percentile) %>%
  summarise(tot = sum(Value), count = length(Value)) %>%
  arrange((tot))
  


customer <- data_residential %>% select(contractaccount, DualFlg, Move_In, GasNetwork, 
                                             LoyaltyFlag, PAYGType, 
                                             Tenure, Age, ProductID,
                                             Ebiller, Staff, FuelType, site_region, 
                                             DuosGroupCode, FEA, PaymentType)

customer$mi_year <- as.numeric(format(customer$Move_In,'%Y'))
cost_info <- customer_costs %>% select(contractaccount, billed,CTA, CTS, Value, total_costs, percentile, exgratia)
customer <-merge(x= customer,y = cost_info, by = "contractaccount")



library(dplyr)
set.seed(1234)
customer_norm <- customer %>% mutate_at(funs(scale(.) %>% as.vector), 
                                                vars=c("Value","exgratia"))
#customer_norm

customer_norm %>%
 # filter(PaymentType == 'Direct Debit') %>%
  ggplot(aes(x = normalized, y = total_costs, colour = percentile)) +
  geom_point(alpha = 0.3,  position = position_jitter()) + stat_smooth(method = "lm") 

customer$normalized = (customer$Value-min(customer$Value))/(max(customer$Value)-min(customer$Value))
par(mfrow=c(1,2))
hist(customer$Value, breaks=20, xlab="Data", col="lightblue", main="")
hist(customer$normalized, breaks=20, xlab="Normalized Data", col="lightblue", main="")

customer_norm %>% 
 # filter(Tenure > 4) %>%
  group_by(PaymentType) %>%
  summarise(tot = sum(normalized), count = length(normalized)) %>%
  arrange((tot))

customer_info %>% 
  filter(PAYGType != 'CreditMeter') %>%
  group_by(PAYGType) %>%
  summarise(tot = sum(value), sum(acd_calls)) %>%
  arrange((tot))

customer_trans %>% 
  filter(RateCategoryCode == 'ED_PPLC') %>%
  group_by(PAYGType) %>%
  summarise(tot = sum(ivr_calls), sum(acd_calls)) %>%
  arrange((tot))


customer_trans %>% 
  filter(acd_calls > 0 & spayg_installs >0 & RateCategoryCode == 'ED_PPLC') %>%
  group_by(PAYGType) %>%
  summarise(tot = sum(acd_calls), sum(spayg_installs), length(contractaccount)) %>%
  arrange((tot))
