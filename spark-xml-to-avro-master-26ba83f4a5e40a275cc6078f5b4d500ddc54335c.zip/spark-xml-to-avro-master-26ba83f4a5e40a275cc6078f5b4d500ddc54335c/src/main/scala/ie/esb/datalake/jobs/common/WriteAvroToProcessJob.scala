package ie.esb.datalake.jobs.common

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.SaveMode
import com.databricks.spark.avro._
import ie.esb.datalake.ingestion._
import org.apache.avro.generic.GenericData.StringType
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.types.{DataTypes, DecimalType, DoubleType, IntegerType}
import org.joda.time.format.DateTimeFormat



/**
  * Created by Sabater_A on 13/10/2017.
  */
class WriteAvroToProcessJob(datasource: String, basePath: String) extends MapJob[FileTransfer]{

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    for ((k: String, v: RddOrDf) <- pl.map) yield {
      val outPath = s"${basePath}/${datasource}/${k}/output"

      val newDF: RddOrDf = datasource match {
        case "abtran-acd_call_details" => v.withColumn("CallId", v.col("CallId").cast(DataTypes.StringType))
        case "siemens" => v.withColumn("DateTime", ExtractDateFromFilenameJob.udfBigIntStringFormat(col("DateTime"), lit("YYYYMMddHHmmss"), lit("YYYY-MM-dd HH:mm:ss")))
        case "snipp" if v.columns.contains("createdate") =>  v.withColumn("createdate", v.col("createdate").cast(DataTypes.StringType))

        case "abtran" if (k.equalsIgnoreCase("ivr_call_log")) =>
            v.withColumn("DATE_CREATED", v.col("DATE_CREATED").cast(DataTypes.StringType))
              .withColumn("ANSWER_DATETIME", v.col("ANSWER_DATETIME").cast(DataTypes.StringType))
              .withColumn ("END_DATETIME", v.col ("END_DATETIME").cast (DataTypes.StringType) )
              .withColumn ("START_DATETIME", v.col ("START_DATETIME").cast (DataTypes.StringType) )

        case "abtran" if (k.equalsIgnoreCase("ivr_option_log")) =>
            v.withColumn ("STAGE_STARTTIME", v.col ("STAGE_STARTTIME").cast (DataTypes.StringType) )
              .withColumn ("DATE_CREATED", v.col ("DATE_CREATED").cast (DataTypes.StringType) )

        case "sapds/irp" if (k.equalsIgnoreCase("easts")) =>
          v.withColumn("bis", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("bis"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ab", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ab"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeasts")) =>
          v.withColumn("bis", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("bis"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ab", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ab"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eabl")) =>
          v.withColumn("adat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("adatsoll", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatsoll"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatmax",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatmax"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adattats", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adattats"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adaterz", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adaterz"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatprog", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatprog"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("zuorddat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("zuorddat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("thgdatum", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("thgdatum"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("e_zvbl_bezdat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("e_zvbl_bezdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatreal", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatreal"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("s_adatsoll", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("s_adatsoll"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeabl")) =>
          v.withColumn("adat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("adatsoll", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatsoll"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatmax",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatmax"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adattats", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adattats"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adaterz", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adaterz"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatprog", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatprog"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("zuorddat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("zuorddat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("thgdatum", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("thgdatum"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("e_zvbl_bezdat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("e_zvbl_bezdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("adatreal", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("adatreal"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("s_adatsoll", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("s_adatsoll"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eastl")) =>
          v.withColumn("bis", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("bis"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ab", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ab"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeastl")) =>
          v.withColumn("bis", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("bis"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ab", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ab"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("erdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("erdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("aedat", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("aedat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("but050")) =>
          v.withColumn("date_to", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_to"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("date_from", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_from"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("crdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("crtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("chdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        //.withColumn ("chtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("but050")) =>
             v.withColumn("date_to", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_to"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("date_from", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_from"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("crdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("crtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("chdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("chtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpbut050")) =>
             v.withColumn("date_to", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_to"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("date_from", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("date_from"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("crdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("crtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("crtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("chdat",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chdat"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("chtim", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("chtim"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eideswtmsgdata")) =>
          v.withColumn("MSGDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MSGDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MOVEOUTDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZEFFECTFROMDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZEFFECTFROMDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCALCDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCALCDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZISU_OBJECTION", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZISU_OBJECTION"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREAD_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREAD_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZMICSTRTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZMICSTRTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        
        case "sapds/srp" if (k.equalsIgnoreCase("srpeideswtmsgdata")) =>
          v.withColumn("MSGDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MSGDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MOVEOUTDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZEFFECTFROMDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZEFFECTFROMDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCALCDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCALCDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("euitrans")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeuitrans")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("euiinstln")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeuiinstln")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eideswtdoc")) =>
          v.withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEINDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZPRICEREQ", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZPRICEREQ"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeideswtdoc")) =>
          v.withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEINDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZG_READDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZG_READDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eablg")) =>
          v.withColumn("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeablg")) =>
          v.withColumn("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("crpbut000")) =>
            v.withColumn("FOUND_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FOUND_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("LIQUID_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LIQUID_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BIRTHDT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIRTHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("DEATHDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DEATHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CRDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CHDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("crpmktperm")) =>
            v.withColumn("VALID_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALID_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eprofass")) =>
            v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eprofhead")) =>
            v.withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeprofhead")) =>
            v.withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("erdk")) =>
            v.withColumn("DRUCKDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DRUCKDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STO_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STO_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EDISENDDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EDISENDDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("TAXDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TAXDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCRDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCRDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SELECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SELECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srperdk")) =>
            v.withColumn("DRUCKDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DRUCKDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STO_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STO_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EDISENDDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EDISENDDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("TAXDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TAXDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCRDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCRDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SELECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SELECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("erch")) =>
            v.withColumn("BEGABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ENDABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ENDABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PTERMTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PTERMTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BELEGDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BELEGDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STORNODAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STORNODAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BEGNACH", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGNACH"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATSU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATSU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BEGEND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGEND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAA", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAA"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MEM_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MEM_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CORRECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CORRECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srperch")) =>
            v.withColumn("BEGABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ENDABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ENDABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PTERMTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PTERMTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BELEGDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BELEGDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STORNODAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STORNODAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BEGNACH", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGNACH"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATSU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATSU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BEGEND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGEND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAA", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAA"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MEM_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MEM_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CORRECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CORRECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case _ => v
      }
      newDF.write.mode(SaveMode.Overwrite).avro(outPath)
    }
    pl.map
  }
}