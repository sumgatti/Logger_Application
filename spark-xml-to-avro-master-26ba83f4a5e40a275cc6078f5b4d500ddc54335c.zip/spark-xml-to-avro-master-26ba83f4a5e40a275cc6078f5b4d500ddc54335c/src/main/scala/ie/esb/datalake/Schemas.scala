package ie.esb.datalake

import org.apache.spark.sql.types._


/**
  * Created by Sabater_A on 25/10/2017.
  */
object Schemas {

  val abtranacdcalls = StructType(Seq(
    StructField("CallId", StringType, true),
    StructField("CallType", StringType, true),
    StructField("CallDirection", StringType, true),
    StructField("LineId", StringType, true),
    StructField("LocalUserId", StringType, true),
    StructField("AssignedWorkGroup", StringType, true),
    StructField("RemoteNumberFmt", IntegerType, true),
    StructField("InitiatedDate", StringType, true),
    StructField("InitiatedDateTimeGMT", StringType, true),
    StructField("ConnectedDate", StringType, true),
    StructField("ConnectedDateTimeGMT", StringType, true),
    StructField("TerminatedDate", StringType, true),
    StructField("TerminatedDateTimeGMT", StringType, true),
    StructField("CallDurationSeconds", IntegerType, true),
    StructField("HoldDurationSeconds", IntegerType, true),
    StructField("LineDurationSeconds", IntegerType, true),
    StructField("DNIS", IntegerType, true),
    StructField("CallEventLog", StringType, true),
    StructField("I3TimeStampGMT", StringType, true),
    StructField("WrapUpCode", StringType, true),
    StructField("tDialing", IntegerType, true),
    StructField("tIVRWait", IntegerType, true),
    StructField("tQueueWait", IntegerType, true),
    StructField("tAlert", IntegerType, true),
    StructField("tSuspend", IntegerType, true),
    StructField("tConference", IntegerType, true),
    StructField("tExternal", IntegerType, true),
    StructField("tACW", IntegerType, true),
    StructField("nIVR", IntegerType, true),
    StructField("nQueueWait", IntegerType, true),
    StructField("nTalk", IntegerType, true),
    StructField("nConference", IntegerType, true),
    StructField("nHeld", IntegerType, true),
    StructField("nTransfer", IntegerType, true),
    StructField("nExternal", IntegerType, true)
  ))

}

