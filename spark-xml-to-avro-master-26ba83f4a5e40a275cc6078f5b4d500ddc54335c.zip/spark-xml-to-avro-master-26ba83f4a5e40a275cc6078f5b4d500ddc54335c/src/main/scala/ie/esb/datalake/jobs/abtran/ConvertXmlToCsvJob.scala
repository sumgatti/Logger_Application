package ie.esb.datalake.jobs.abtran

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import ie.esb.datalake.jobs.abtran.ConvertAcdToCsvJob._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.AccumulatorParam
import org.apache.spark.sql.{DataFrame, Row}
import com.databricks.spark.xml._

/**
  *
  * @param io
  * Job that reads the multiple CSV files using configurations files provided by pipeline.conf and application.conf
  * Returns a map of dataframes in the form of:
  * Map(interface1 -> DataFrame,
  * interface2 -> DataFrame,
  * interfaceN -> DataFrame)
  */
class ConvertXmlToCsvJob(io: IO) extends MapJob[FileTransfer] {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    val sqlCtx = Contexts.sqlCtx

    val df = sqlCtx.read.format("com.databricks.spark.xml").option("rowTag", "book").load("/data/landing/ABTRAN/profile-reading/books.xml")

    val selectedData = df.select("author", "_id")

    selectedData.write
      .option("rootTag", "books")
      .option("rowTag", "book")
      .xml("newbooks.xml")
  }

}


