package ie.esb.datalake.jobs.abtran

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.mockito.Mockito.{mock, when}
import org.scalatest.{FlatSpec, Matchers}

import scala.util.Random

/**
  * Created by Sabater_A on 17/10/2017.
  */
class ConvertXmlToCsvJobTest  extends FlatSpec with Matchers {

  "acd_call_details" should "converted to a real .csv file" in {
    val files = List("acd_call_details")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ABTRAN/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources
    val job = new ConvertXmlToCsvJob(new IO)

    val result = job.runMapped(plMock)
  }

}
