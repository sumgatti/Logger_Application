package ie.esb.datalake.jobs.common

import com.databricks.spark.avro._
import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import ie.esb.datalake.ingestion.{RddOrDf, _}
import ie.esb.datalake.jobs.WriteAvroJob
import org.mockito.Mockito._
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 11/09/2017.
  */
class WriteAvroJobTest extends FlatSpec with Matchers {

  val dfAbtran = Contexts.sqlCtx.createDataFrame(Seq(
    (1, 1, "2017-01-10", "20160101"),
    (1, 1, "2017-01-11", "20160102"),
    (1, 1, "2017-01-11", "20160103")
  )).toDF("col1", "col2", "processedDate", "createdDate")
  val df: RddOrDf = dfAbtran
  val dfMap = Map("int1#2017-01-01" -> df, "int2#2017-01-02" -> df, "int1#2017-01-03" -> df, "" -> df, "int3#2017-01-04" -> df)

  "run" should "run the desired Job" in {
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])
    when(plMock.in) thenReturn List("/landing/ABTRAN/int1")
    when(plMock.out) thenReturn List(getClass.getResource("/data/landing/ABTRAN/persistence/int1").getPath)
    when(plMock.map) thenReturn dfMap

    val job = new WriteAvroJob
    val result: Seq[RddOrDf] = job.run(plMock)

    val dfResult = Contexts.sqlCtx.read.avro(getClass.getResource("/data/landing/ABTRAN/persistence/int1/2017-01-01").getPath)
    dfResult.columns shouldEqual dfMap.get("int1#2017-01-01").columns
  }

  "filterDfMap" should "filter interfaces correctly" in {
    val result = WriteAvroJob.filterDfMap("int1", dfMap)
    result.size shouldEqual 2
  }


}
