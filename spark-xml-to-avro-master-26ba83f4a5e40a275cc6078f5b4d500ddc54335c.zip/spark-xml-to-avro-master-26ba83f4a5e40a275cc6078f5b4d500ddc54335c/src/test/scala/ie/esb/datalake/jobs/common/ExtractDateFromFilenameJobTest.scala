package ie.esb.datalake.jobs.common

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.{RddOrDf, _}
import ie.esb.datalake.ingestion.mocking.PipelineMock
import ie.esb.datalake.ingestion.pipeline.FileTransfer
import org.apache.spark.sql.functions._
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 11/09/2017.
  */
class ExtractDateFromFilenameJobTest extends FlatSpec with Matchers{

  val dfAbtran = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-10_ivr_call_log_20160101"),
    (1,1,"2017-01-11_ivr_call_log_20160102"),
    (1,1,"2017-01-11_ivr_call_log_20160103")
  )).toDF("col1","col2","filename")

  "runMapped" should "run the desired Job" in {
    val (plMock, _) = PipelineMock.pipeline[FileTransfer](Seq(Right(dfAbtran),Right(dfAbtran),Right(dfAbtran)), "ABTRAN", Seq("int_1","int_2","int_3"))
    val job = new ExtractDateFromFilenameJob
    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result.forall(e => e._2.columns.contains("ProcessedDate") && e._2.columns.contains("CreatedDate")) shouldEqual true
    result.head._2.right.get.select("ProcessedDate").collect()(0).getString(0) shouldEqual "2017-01-10"
    result.head._2.right.get.select("CreatedDate").collect()(0).getString(0) shouldEqual "2016-01-01 00:00:00"

  }

  "getRegex" should "get a pattern out of a string or return null" in {
    val str = "2017-01-10_ivr_call_log_20160101"
    val datasource = "ivr_call_log"
    val regex1 = "^([0-9]{4}-[0-9]{2}-[0-9]{2}).*"
    val regex2 = s"^[0-9]{4}-[0-9]{2}-[0-9]{2}_.*_([0-9]{8}).*"
    val result1 = ExtractDateFromFilenameJob.getRegex(str,regex1)
    val result2 = ExtractDateFromFilenameJob.getRegex(str,regex2)
    result1.get shouldEqual "2017-01-10"
    result2.get shouldEqual "20160101"
  }

  "udfGetRegex" should "get a pattern out of a string or return null" in {
    val df = Contexts.sqlCtx.createDataFrame(Seq(
      (1,1,Some("20171015")),
      (1,1,Some("20171015")),
      (1,1,Some("20171016"))
    )).toDF("cola","colb","colc")

    val result = df.withColumn("new-d",ExtractDateFromFilenameJob.udfColumnFromRegex(col("colc"), lit("")))
    result.collect()(0).getString(3) shouldEqual null
  }

  "dateStringFormat" should "format a string date into the desired format" in {
    val input = "20170914"
    val inFormat = "YYYYMMdd"
    val outFormat = "YYYY-MM-dd HH:mm:ss"

    val result = ExtractDateFromFilenameJob.dateStringFormat(input, inFormat, outFormat)
    val result1 = ExtractDateFromFilenameJob.dateStringFormat(null, inFormat, outFormat)

    result.get shouldEqual "2017-09-14 00:00:00"
  }

  "udfDateStringFormat" should "format a a date column" in {

    val df = Contexts.sqlCtx.createDataFrame(Seq(
      (1,1,Some("20171015")),
      (1,1,Some("20171015")),
      (1,1,None)
    )).toDF("col1","col2","dateCol")

    val inFormat = "YYYYMMdd"
    val outFormat = "YYYY-MM-dd HH:mm:ss"

    val result = df.withColumn("new-col", ExtractDateFromFilenameJob.udfDateStringFormat(col("dateCol"), lit(inFormat), lit(outFormat)))

    result.collect()(2).getString(2) shouldEqual null
  }

  "getRegex" should "get a pattern out of a string" in {
    val str = "EIRL_ALARMS_07122017001210.csv"
    val datasource = "smart profile device"
    val regex = "^.*_([0-9]{2}[0-9]{2}[0-9]{4}[0-9]{2}[0-9]{2}[0-9]{2}).*"
    val result = ExtractDateFromFilenameJob.getRegex(str,regex)
    result.get shouldEqual "07122017001210"
  }

  "dateBigIntStringFormat" should "format a string date into the desired format" in {
    val input = "20131231170819"
    val inFormat = "YYYYMMddHHmmss"
    val outFormat = "YYYY-MM-dd HH:mm:ss"

    val result = ExtractDateFromFilenameJob.dateBigIntStringFormat(input, inFormat, outFormat)

    result.get shouldEqual "2013-12-31 17:08:19"
  }

}
