package ie.esb.datalake.jobs.common

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.{RddOrDf, _}
import ie.esb.datalake.ingestion.mocking.PipelineMock
import ie.esb.datalake.ingestion.pipeline.FileTransfer
import org.apache.spark.sql.functions._
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 11/09/2017.
  */
class ExtractDateFromFilenameJobTest extends FlatSpec with Matchers{

  val dfAbtran = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-10_ivr_call_log_20160101"),
    (1,1,"2017-01-11_ivr_call_log_20160102"),
    (1,1,"2017-01-11_ivr_call_log_20160103")
  )).toDF("col1","col2","filename")

  "runMapped" should "run the desired Job" in {
    val (plMock, _) = PipelineMock.pipeline[FileTransfer](Seq(Right(dfAbtran),Right(dfAbtran),Right(dfAbtran)), "EMAILS", Seq("int_1","int_2","int_3"))
    val job = new ExtractDateFromFilenameJob
    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result.forall(e => e._2.columns.contains("ProcessedDate") && e._2.columns.contains("CreatedDate")) shouldEqual true
    result.head._2.right.get.select("ProcessedDate").collect()(0).getString(0) shouldEqual "2017-01-10"
    result.head._2.right.get.select("CreatedDate").collect()(0).getString(0) shouldEqual "2016-01-01 00:00:00"

  }
}
