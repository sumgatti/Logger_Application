package ie.esb.datalake.jobs.common

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import org.mockito.Mockito.{mock, _}
import org.scalatest.{FlatSpec, Matchers}
/**
  * Created by Sabater_A on 14/09/2017.
  */
class ReadCsvJobTest extends FlatSpec with Matchers{

  "runMapped" should "return a map of DataFrames" in {
    val files = List("interface_1")
    val sources = files.map(str => getClass.getResource(s"/data/landing/EMAILS/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result("interface_1").right.get.count() shouldEqual  2
    result.size shouldEqual 2
  }
}
