package ie.esb.datalake.jobs.common

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.mocking.PipelineMock
import ie.esb.datalake.ingestion.pipeline.FileTransfer
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 14/09/2017.
  */
class SplitByProcessedDateJobTest extends FlatSpec with Matchers {

  val dfAbtran = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-12", "20160103"),
    (1,1,"2017-01-12", "20160103")
  )).toDF("col1","col2","ProcessedDate", "CreatedDate")

  val dfAbtran1 = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160102"),
    (1,1,"2017-01-08", "20160102"),
    (1,1,"2017-01-07", "20160103"),
    (1,1,"2017-01-06", "20160103")
  )).toDF("col1","col2","ProcessedDate", "CreatedDate")

  "runMapped" should "split each dataFrame based on the processed Date" in {
    val (plMock, _) = PipelineMock.pipeline[FileTransfer](Seq(Right(dfAbtran),Right(dfAbtran1)), "EMAILS", Seq("int_1","int_2"))
    val job = new SplitByProcessedDateJob
    val result = job.runMapped(plMock)

    result shouldBe an[Map[String, RddOrDf]]
  }

}
