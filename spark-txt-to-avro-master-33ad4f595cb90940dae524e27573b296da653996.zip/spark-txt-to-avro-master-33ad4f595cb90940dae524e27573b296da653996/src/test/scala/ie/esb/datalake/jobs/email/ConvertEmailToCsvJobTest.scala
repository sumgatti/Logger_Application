package ie.esb.datalake.jobs.email

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import ie.esb.datalake.jobs.email.{ConvertEmailToCsvJob, StringAccumulatorParam}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.mockito.Mockito.{mock, when}
import org.scalatest.{FlatSpec, Matchers}

import scala.util.Random

/**
  * Created by Sabater_A on 17/10/2017.
  */
class ConvertEmailToCsvJobTest  extends FlatSpec with Matchers {

  "acd_call_details" should "converted to a real .csv file" in {
    val files = List("crm_emails")
    val sources = files.map(str => getClass.getResource(s"/data/landing/EMAILS/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources
    val job = new ConvertEmailToCsvJob(new IO)

    val result = job.runMapped(plMock)
  }

}
