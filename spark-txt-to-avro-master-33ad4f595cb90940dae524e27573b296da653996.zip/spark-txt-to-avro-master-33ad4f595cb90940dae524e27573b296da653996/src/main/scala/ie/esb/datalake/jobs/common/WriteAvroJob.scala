package ie.esb.datalake.jobs

import com.databricks.spark.avro._
import ie.esb.datalake.ingestion.{RddOrDf, _}
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Job, Pipeline}
import ie.esb.datalake.jobs.WriteAvroJob._
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.SaveMode

/**
  * Created by Sabater_A on 11/09/2017.
  */
class WriteAvroJob extends Job[FileTransfer] {
  @transient lazy val log: Logger = LogManager.getLogger(getClass)
  override def run(pl: Pipeline[FileTransfer]): Seq[RddOrDf] = {
    for (path <- pl.in) {
      val interface = path.split("/").last
      val basePath: String = pl.out.filter(str => str.contains(interface)).head
      val mapFiltered = filterDfMap(interface, pl.map)
      for ((k: String, v: RddOrDf) <- mapFiltered) {
        val keys = k.split("#")
        val outPath = s"${basePath}/${keys(1)}"
        v.write.mode(SaveMode.Overwrite).avro(outPath)
      }
    }
    Seq()
  }
}

object WriteAvroJob {

  def filterDfMap(interface: String, dfMap: Map[String, RddOrDf]): Map[String, RddOrDf]  = {
    dfMap.filter(kv => kv._1.contains(interface))
  }
}
