package ie.esb.datalake

import com.typesafe.config.Config
import ie.esb.datalake.commons.LoadedProperties
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Job, Pipeline}
import ie.esb.datalake.jobs._
import ie.esb.datalake.jobs.common._
import ie.esb.datalake.jobs.email.ConvertEmailToCsvJob
import org.apache.log4j.{LogManager, Logger}

/**
  * Created by Sabater_A on 11/09/2017.
  */
object MainCsvToAvro {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  def main(args: Array[String]): Unit = {
    execute(new IO, args(0))
  }

  def execute(io: IO, datasource: String, processPath: String = "/process/landing", conf: Config = LoadedProperties.conf): Unit = {

    log.info("TXT to AVRO job for file transfers")
    log.info(s"Datasource: ${datasource}")
    log.info(s"Process base path: ${processPath}")

    val jobList: List[Job[FileTransfer]] =
      datasource match {

        case "email-jobs" => List(
          new ConvertEmailToCsvJob(io),
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
      }
    val pipeline = new Pipeline[FileTransfer](datasource, jobList)
    pipeline.run()
  }
}
