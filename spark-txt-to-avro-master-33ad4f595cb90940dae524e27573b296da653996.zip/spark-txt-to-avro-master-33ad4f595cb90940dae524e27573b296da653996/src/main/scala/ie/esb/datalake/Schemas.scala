package ie.esb.datalake

import org.apache.spark.sql.types._


/**
  * Created by Sabater_A on 25/10/2017.
  */
object Schemas {

  val libertyVends = StructType(Seq(
    StructField("PremiseNo", StringType, true),
    StructField("Title", StringType, true),
    StructField("FirstName", StringType, true),
    StructField("LastName", StringType, true),
    StructField("mprn", StringType, true),
    StructField("IssueDate", StringType, true),
    StructField("Meterno", StringType, true),
    StructField("TransactionAmount", DoubleType, true),
    StructField("MeterCreditAmount", DoubleType, true),
    StructField("PreviousChargesDeduction", DoubleType, true),
    StructField("PreviousChargesLeft", DoubleType, true),
    StructField("WrittenoffPreviousCharges", DoubleType, true),
    StructField("VatOnEnergyAmount", DoubleType, true),
    StructField("VatonPreviousCharges", DoubleType, true),
    StructField("TotalVat", DoubleType, true),
    StructField("VatRate", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true),
    StructField("PaymentMode", StringType, true),
    StructField("VendCode", StringType, true),
    StructField("TarrifCategory", IntegerType, true),
    StructField("TarrifName", StringType, true),
    StructField("TarrifId", IntegerType, true),
    StructField("CallCentre", StringType, true),
    StructField("Operator", StringType, true),
    StructField("AgentId", StringType, true),
    StructField("TerminalId", StringType, true),
    StructField("InvalidRequestDate", StringType, true),
    StructField("ConfirmedInvalidRequestDate", StringType, true),
    StructField("InvalidRequestConfirmedUser", StringType, true),
    StructField("TransactionType", StringType, true),
    StructField("TransactionStatus", IntegerType, true),
    StructField("CurrentDate", StringType, true),
    StructField("RspCode", StringType, true),
    StructField("ComServerNo", IntegerType, true),
    StructField("Terminal/ComServerTransRequestDate", StringType, true),
    StructField("EncryptionServerTransNo", StringType, true),
    StructField("Terminal/ComServerTransNo", StringType, true),
    StructField("BusinessPercentage", DoubleType, true),
    StructField("TokenType", StringType, true),
    StructField("CreditAccount", DoubleType, true),
    StructField("FreeVendAmount", DoubleType, true),
    StructField("ReasonCode", StringType, true),
    StructField("ReasonCodeDetails", StringType, true),
    StructField("PostCode", StringType, true)
  ))

  val libertyCustomer = StructType(Seq(
    StructField("PremiseNo", StringType, true),
    StructField("FirstName", StringType, true),
    StructField("LastName", StringType, true),
    StructField("HouseName", StringType, true),
    StructField("Street1", StringType, true),
    StructField("Street2", StringType, true),
    StructField("Town/County", StringType, true),
    StructField("Phone1", StringType, true),
    StructField("Mprn", StringType, true),
    StructField("MeterNo", StringType, true),
    StructField("TariffCategory", IntegerType, true),
    StructField("TariffName", StringType, true),
    StructField("MeterInstallDate", StringType, true),
    StructField("CustomerEntryDate", StringType, true),
    StructField("PreviousChargeLeft", DoubleType, true),
    StructField("MeterRemovalDate", StringType, true),
    StructField("LastRecordModifiedDate", StringType, true),
    StructField("InitialPreviousCharge", DoubleType, true),
    StructField("CreditAccount", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true)
  ))

  val siemens = StructType(Seq(
    StructField("ShipperID", StringType, true),
    StructField("GPRN", StringType, true),
    StructField("MeterNumber", StringType, true),
    StructField("GasCardNumber", StringType, true),
    StructField("Outlet", StringType, true),
    StructField("ShipperTransactionRef", StringType, true),
    StructField("DateTime", StringType, true),
    StructField("GasDebtIndicator" , StringType, true),
    StructField("Amount", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true),
    StructField("GasDebtWeeklyMin", DoubleType, true),
    StructField("GasDebtWeeklyMax", DoubleType, true),
    StructField("EmegencyCreditLimit", DoubleType, true),
    StructField("EmergencyCreditDebt", DoubleType, true),
    StructField("CreditAdjustmentLog1Indicator", StringType, true),
    StructField("CreditAdjustmentLog1Amount", DoubleType, true),
    StructField("CreditAdjustmentLog2Indicator", StringType, true),
    StructField("CreditAdjustmentLog2Amount", DoubleType, true),
    StructField("CreditAdjustmentLog3Indicator", StringType, true),
    StructField("CreditAdjustmentLog3Amount", DoubleType, true),
    StructField("GasDebtLog1Indicator", StringType, true),
    StructField("GasDebtLog1Amount", DoubleType, true),
    StructField("GasDebtLog2Indicator", StringType, true),
    StructField("GasDebtLog2Amount", DoubleType, true),
    StructField("GasDebtLog3Indicator", StringType, true),
    StructField("GasDebtLog3Amount", DoubleType, true)
  ))

  val arvatoDials = StructType(Seq(
    StructField("JobName", StringType, true),
    StructField("JobDate", StringType, true),
    StructField("CallTime", StringType, true),
    StructField("WaitTime", IntegerType, true),
    StructField("ContractAccountNumber", LongType, true),
    StructField("CallCode", IntegerType, true),
    StructField("Telephone", StringType, true),
    StructField("Agent", StringType, true),
    StructField("TalkTime", IntegerType, true),
    StructField("WrapTime", IntegerType, true),
    StructField("CallDirection", StringType, true)
  ))

  val abtranacdcalls = StructType(Seq(
    StructField("CallId", StringType, true),
    StructField("CallType", StringType, true),
    StructField("CallDirection", StringType, true),
    StructField("LineId", StringType, true),
    StructField("LocalUserId", StringType, true),
    StructField("AssignedWorkGroup", StringType, true),
    StructField("RemoteNumberFmt", IntegerType, true),
    StructField("InitiatedDate", StringType, true),
    StructField("InitiatedDateTimeGMT", StringType, true),
    StructField("ConnectedDate", StringType, true),
    StructField("ConnectedDateTimeGMT", StringType, true),
    StructField("TerminatedDate", StringType, true),
    StructField("TerminatedDateTimeGMT", StringType, true),
    StructField("CallDurationSeconds", IntegerType, true),
    StructField("HoldDurationSeconds", IntegerType, true),
    StructField("LineDurationSeconds", IntegerType, true),
    StructField("DNIS", IntegerType, true),
    StructField("CallEventLog", StringType, true),
    StructField("I3TimeStampGMT", StringType, true),
    StructField("WrapUpCode", StringType, true),
    StructField("tDialing", IntegerType, true),
    StructField("tIVRWait", IntegerType, true),
    StructField("tQueueWait", IntegerType, true),
    StructField("tAlert", IntegerType, true),
    StructField("tSuspend", IntegerType, true),
    StructField("tConference", IntegerType, true),
    StructField("tExternal", IntegerType, true),
    StructField("tACW", IntegerType, true),
    StructField("nIVR", IntegerType, true),
    StructField("nQueueWait", IntegerType, true),
    StructField("nTalk", IntegerType, true),
    StructField("nConference", IntegerType, true),
    StructField("nHeld", IntegerType, true),
    StructField("nTransfer", IntegerType, true),
    StructField("nExternal", IntegerType, true)
  ))


}

