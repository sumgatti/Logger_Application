package ie.esb.datalake.jobs.common

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.SaveMode
import com.databricks.spark.avro._
import ie.esb.datalake.ingestion._
import org.apache.avro.generic.GenericData.StringType
import org.apache.spark.sql.types.{DataTypes, DecimalType, DoubleType, IntegerType}

/**
  * Created by Sabater_A on 13/10/2017.
  */
class WriteAvroToProcessJob(datasource: String, basePath: String) extends MapJob[FileTransfer]{

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    for ((k: String, v: RddOrDf) <- pl.map) yield {
      val outPath = s"${basePath}/${datasource}/${k}/output"

      val newDF: RddOrDf = datasource match {
        case "abtran-acd_call_details" => v.withColumn("CallId", v.col("CallId").cast(DataTypes.StringType))
        case _ => v
      }
      newDF.write.mode(SaveMode.Overwrite).avro(outPath)
    }
    pl.map
  }
}


