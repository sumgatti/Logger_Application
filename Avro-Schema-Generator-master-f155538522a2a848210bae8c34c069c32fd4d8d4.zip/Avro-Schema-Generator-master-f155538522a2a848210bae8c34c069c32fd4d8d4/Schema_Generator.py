import sys
import json
import pandas as pd
from pandas.io.json import json_normalize



DATASOURCE = sys.argv[1]
INTERFACE = sys.argv[2]

filename1 = '/home/cld1.tld.int/hadoop_deploy/'+DATASOURCE+'/'+INTERFACE +'/'+'schema-process.avsc'
filename2 = '/home/cld1.tld.int/hadoop_deploy/'+DATASOURCE+'/'+INTERFACE +'/'+'schema-storehouse.avsc'
filename3 = '/home/cld1.tld.int/hadoop_deploy/'+DATASOURCE+'/'+INTERFACE +'/'+'schema-out.json'
filename4 = '/home/cld1.tld.int/hadoop_deploy/'+DATASOURCE+'/'+INTERFACE +'/'+'schema.avsc'


'''
filename1 = 'P:\\ESB_Projects\\Networks_Avro_issue\\Testing\\schema-process.avsc'
filename2 = 'P:\\ESB_Projects\\Networks_Avro_issue\\Testing\\schema-storehouse.avsc'
filename3 = 'P:\\ESB_Projects\\Networks_Avro_issue\\Testing\\schema-out.json'
filename4 = 'P:\\ESB_Projects\\Networks_Avro_issue\\Testing\\schema.avsc'

'''

with open(filename1) as fo:
    data1 = json.load(fo)

result1 = json_normalize(data1,'fields')



with open(filename2) as fo:
    data2 = json.load(fo)

result2 = json_normalize(data2,'fields')



result1.type = result1.type.apply(tuple)
result2.type = result2.type.apply(tuple)

out = pd.merge(result1,result2,on='name',how='outer')




null_columns=pd.isnull(out["type_y"])
print(out[null_columns])

Newaddcolumns = pd.DataFrame(out[null_columns])




in_file = open(filename1, 'r')
out_file = open(filename3,'w')

data_file = in_file.read()
json_dict = json.loads(data_file)


for item in json_dict['fields']:
    for index, row in Newaddcolumns.iterrows():
           if item['name'] == row['name']:
               if item['type'] == [ "string", "null" ] :
                   item['default'] = ""
               elif item['type'] == [ "int", "null" ] :
                   item['default'] = 0
               elif item['type'] == [ "long", "null" ] :
                   item['default'] = 0
               elif item['type'] == [ "float", "null" ] :
                   item['default'] = 0.0
               elif item['type'] == ["double", "null"]:
                   item['default'] = 0.0
               elif item['type'] == ["boolean", "null"]:
                   item['default'] = False




if "default" in out.columns:
    print("Default key is present")
    Non_null_columns=pd.notnull(out["default"])
    print(out[Non_null_columns])
    Defaultaddcolumnsdf = pd.DataFrame(out[Non_null_columns])
	# Check if Dataframe is empty using empty attribute
    if Defaultaddcolumnsdf.empty == True:
         print('DataFrame is empty')
    else:
         print('DataFrame is not empty')
         for item in json_dict['fields']:
            for index, row in Defaultaddcolumnsdf.iterrows():
                if item['name'] == row['name']:
                    item['default'] = row['default']
else:
   print("No Default key is present")

out_file.write(json.dumps(json_dict))
out_file.close()


datatypechangedcolumns = out.loc[~(out['type_x'] == out['type_y'])]

filtered_df = datatypechangedcolumns[datatypechangedcolumns['type_y'].notnull()]

print(filtered_df)


in_file2 = open(filename2, 'r')
data_file2 = in_file2.read()
json_dict2 = json.loads(data_file2)



in_file1 = open(filename3, 'r')
out_file1 = open(filename4,'w')

data_file1 = in_file1.read()
json_dict1 = json.loads(data_file1)


for item1 in json_dict1['fields']:
    for index1, row1 in filtered_df.iterrows():
       if item1['name'] ==  row1['name']:
           print("process",item1['name'],item1['type'])
           for item2 in json_dict2['fields']:
               if item2['name'] == row1['name']:
                  print("storehouse", item2['name'],item2['type'])
                  item1['type'] = item2['type']
                  print(item1['type'],item2['type'])


#json_string = json.dumps(json_dict)

out_file1.write(json.dumps(json_dict1))
out_file1.close()