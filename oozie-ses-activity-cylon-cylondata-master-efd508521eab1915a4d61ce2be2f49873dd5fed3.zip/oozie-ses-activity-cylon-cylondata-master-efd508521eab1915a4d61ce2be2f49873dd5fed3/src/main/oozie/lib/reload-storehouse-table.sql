DROP TABLE storehouse_ses_cylon.${TABLE_NAME};
CREATE EXTERNAL TABLE storehouse_ses_cylon.${TABLE_NAME}
STORED AS AVROFILE
LOCATION '${TABLE_LOCATION}'
TBLPROPERTIES ('avro.schema.url'='${SCHEMA_DIR}/schema.avsc');