SET hive.execution.engine = mr;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.max.dynamic.partitions.pernode=2000;

INSERT INTO TABLE  storehouse_ses_cylon.${TABLE_NAME}
SELECT *
FROM process_ses_cylon.${TABLE_NAME};

