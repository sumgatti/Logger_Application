#==================== TRIAL CODE TO CONNECT H2O CLUSTER TO SPARKLYR (not RUNNING)====================================


Sys.setenv(SPARK_HOME = "/var/opt/cloudera/parcels/SPARK2-2.2.0.cloudera2-1.cdh5.12.0.p0.232957/lib/spark2")
HADOOP_CONF_DIR = "/etc/hadoop/conf"
options(rsparkling.sparklingwater.version = "2.2.34")
options(rsparkling.sparklingwater.location = "/home/cdsw/sparkling-water-2.2.34/assembly/build/libs/sparkling-water-assembly_2.11-2.2.34-all.jar")

library(dplyr)
library(sparklyr)
library(h2o)
library(rsparkling)

config <- spark_config()
conf <- c(config,list(
  "sparklyr.shell.driver-memory"= "4g",
  "sparklyr.shell.num-executors" = 3,
  "sparklyr.shell.executor-memory" = "5g",
  "sparklyr.shell.executor-cores" = 2,
  "spark.dynamicAllocation.enabled" = "false",
  "spark.ext.h2o.node.port.base"="55555",
  "spark.ext.h2o.client.port.base"="44444"
))

# connecting to spark
 sc <- spark_connect(master="yarn-client",
                    version = "2.2", 
                    spark_home = '/var/opt/cloudera/parcels/SPARK2-2.2.0.cloudera2-1.cdh5.12.0.p0.232957/lib/spark2',
                    config = conf,
                    app_name = "churn_automl")


h2o.init()


h2o_context(sc, strict_version_check = FALSE)
h2o.shutdown()
h2o.init(ip = "localhost", nthreads = 4, max_mem_size = "12G",
         strict_version_check = FALSE)
# clean slate - just in case the cluster was already running
h2o.removeAll()



# connecting to sparkling water
h2o_flow(sc)

# View the status of h2o cloud
h2o.clusterInfo()
h2o.clusterStatus()

spark_disconnect_all()



#xgboost/AUTOml TRY

library('rsparkling')
library('h2o')
library('here')
library('glue')
library('rJava')

cp <- c(   
		   "/var/opt/cloudera/parcels/CDH/jars/commons-codec-1.3.jar",
       "/var/opt/cloudera/parcels/CDH/jars/commons-logging-1.1.3.jar",
       "/var/opt/cloudera/parcels/CDH/jars/httpclient-4.3.jar",
       "/var/opt/cloudera/parcels/CDH/jars/httpcore-4.2.5.jar",
       "/var/opt/cloudera/parcels/CDH/jars/log4j-1.2.17.jar",
       "/var/opt/cloudera/parcels/CDH/jars/slf4j-api-1.7.25.jar",
       "/var/opt/cloudera/parcels/CDH/jars/slf4j-log4j12-1.7.5.jar",
       "/var/opt/cloudera/parcels/CDH/lib/hadoop/hadoop-common-2.6.0-cdh5.15.1.jar",
		   "/var/opt/cloudera/parcels/CDH/lib/hadoop/hadoop-auth-2.6.0-cdh5.15.1.jar"
		   )
.jinit(classpath<-cp,parameters="-Djavax.security.auth.useSubjectCredsOnly=false")

# Just in case you are already connected
spark_disconnect_all()
# Define a directory where to save model outputs and logs
spark_dir <- here("res_churn_model/spark_dir/")
# Set driver and executor memory allocations **depending on your machine**
config <- spark_config()
config$`sparklyr.shell.driver-memory` <- "8G"
config$`sparklyr.shell.executor-memory` <- "8G"
config$spark.yarn.executor.memoryOverhead <- "4g"
config$jobTracker <- "yarnrm"
config$spark.master <- "yarn-client"
config$spark.yarn.am.extraLibraryPath <- "/var/opt/cloudera/parcels/CDH-5.15.1-1.cdh5.15.1.p0.4/lib/hadoop/lib/native"
config$spark.yarn.config.gatewayPath <- "/var/opt/cloudera/parcels"
config$spark.executor.extraLibraryPath <- "/var/opt/cloudera/parcels/CDH-5.15.1-1.cdh5.15.1.p0.4/lib/hadoop/lib/native "
config$`sparklyr.shell.driver-java-options` <-
  glue("-Djava.io.tmpdir={spark_dir}")


sc <- spark_connect(master = "yarn-client", version = "2.2", config = config)


h2o_context(sc, strict_version_check = FALSE)
h2o.shutdown()
h2o.init(ip = "localhost", nthreads = 4, max_mem_size = "12G",
         strict_version_check = FALSE)
# clean slate - just in case the cluster was already running
h2o.removeAll()

h2o_context(sc)

#spark_write_csv(training_set,path = "/home/cdsw/res_churn_model", header = TRUE, delimiter = ",")
#my_tbl <- sdf_copy_to(sc, df, "my_tbl")

as_h2o_frame(sc, training_set, name = training, strict_version_check = FALSE)





training <- as_h2o_frame(sc, training_set)
test <- as_h2o_frame(sc, testing_set, strict_version_check = FALSE)

y <- "churnflag"
x <- setdiff(colnames(training_set),y)

training_set <- training_set %>%
  mutate(as.factor(training_set[,y])
testing_set[,y] <- as.factor(testing_set[,y])

aml <- h2o.automl(x = x, y = y,
                  training_frame = training_set,
                  max_models = 20,
                  seed = 1)


