#====================Visualization - Model performance and Feature Importance ==========================


ml_models <- list(
#  NaivesBayes = churn_nb_model,
  DecisionTree = churn_dt_model,
  LogisticRegression = churn_logit_model,
  SupportVectorMachine = churn_svm_model,
  RandomForest = churn_randomforest_model,
  GradientBoost = churn_gbt_model
#  ANN =churn_mlp_model
)

# Create a function for scoring
score_test_data <- function(model, data = testing_set){
  pred <- ml_predict(model, data)
  select(pred, churnflag, prediction)
}

# Score all the models

#for(i in names(ml_models)){
#  ml_score <- score_test_data(ml_models[[i]])
#}

ml_score <- map(ml_models, score_test_data)


# MODEL COMPARISON AND SELECTION - VISUALIZATION

# Lift function
calculate_lift <- function(scored_data) {
  scored_data %>%
    mutate(bin = ntile(desc(prediction), 10)) %>% 
    group_by(bin) %>% 
    summarize(count = sum(churnflag)) %>% 
    mutate(prop = count / sum(count)) %>% 
    arrange(bin) %>% 
    mutate(prop = cumsum(prop)) %>% 
    select(-count) %>% 
    collect() %>% 
    as.data.frame()
}

# Initialize results
ml_gains <- tibble(
  bin = seq(from = 1, to = 10),
  prop = seq(0, 1, len = 10),
  model = "Base"
)


# Calculate lift
for(i in names(ml_models)){
   ml_gains <- ml_score[[i]] %>%
    calculate_lift %>%
    mutate(model = i) %>%
    bind_rows(ml_gains, .)
}

# Plot results
ggplot(ml_gains, aes(x = bin, y = prop, color = model)) +
  geom_point() +
  geom_line() +
  scale_color_brewer(type = "qual") +
  labs(title = "Lift Chart for Predicting Churn",
       subtitle = "Residential",
       x = NULL,
       y = NULL)

# Function for calculating accuracy
calc_accuracy <- function(data, cutpoint = 0.5){
  data %>% 
    mutate(prediction = if_else(prediction > cutpoint, 1.0, 0.0)) %>%
    ml_multiclass_classification_evaluator("prediction", "churnflag", "accuracy")
}

# Calculate AUC and accuracy
perf_metrics <- tibble(
  model = names(ml_score),
  AUC = 100 * map_dbl(ml_score, ml_binary_classification_evaluator, "churnflag", "prediction"),
  Accuracy = 100 * map_dbl(ml_score, calc_accuracy)
  )
perf_metrics


# Plot results
gather(perf_metrics, metric, value, AUC, Accuracy) %>%
  ggplot(aes(reorder(model, value), value, fill = metric)) + 
  geom_bar(stat = "identity", position = "dodge") + 
  coord_flip() +
  labs(title = "Performance metrics",
       x = NULL,
       y = "Percent")

ml_models <- list(
  DecisionTree = churn_dt_model,
  RandomForest = churn_randomforest_model,
  GradientBoost = churn_gbt_model
)

# Initialize results
feature_importance <- tibble()

# Calculate feature importance
for(i in names(ml_models)){
  feature_importance <- ml_tree_feature_importance(ml_models[[i]]) %>%
    mutate(Model = i) %>%
    rbind(feature_importance, .)
}

# Plot results
feature_importance %>%
  ggplot(aes(reorder(feature, importance), importance, fill = Model)) + 
  facet_wrap(~Model) +
  geom_bar(stat = "identity") + 
  coord_flip() +
  labs(title = "Feature importance",
       x = NULL) +
  theme(legend.position = "none")


#====================Visualization - Model =================================

#PLOT RANDOMFOREST TREE

detach("package:tidyr", unload=TRUE)

ml_stage(churn_randomforest_model$pipeline, "random_forest") %>% 
  ml_save("/res_churn_model/model2")

rf_spec <- spark_read_parquet(sc, "rf", "/res_churn_model/model2/data/")

rf_spec %>% 
  spark_dataframe() %>% 
  invoke("schema") %>% invoke("treeString") %>% 
  cat(sep = "\n")

churn_predictions <- churn_randomforest_model$pipeline_model %>%
  ml_transform(data_churn_partitions$testing)

meta <- churn_predictions %>% 
    select(features) %>% 
    spark_dataframe() %>% 
    invoke("schema") %>% invoke("apply", 0L) %>% 
    invoke("metadata") %>% 
    invoke("getMetadata", "ml_attr") %>% 
    invoke("getMetadata", "attrs") %>% 
    invoke("json") %>%
    jsonlite::fromJSON() %>% 
    dplyr::bind_rows() %>%
    rename(featureIndex = idx) %>%
    select(-vals) %>%
    copy_to(sc, .)
 
meta


labels <- tibble(prediction = seq_along(feature_colnames) - 1, label = feature_colnames) %>%
  copy_to(sc, .)


full_rf_spec <- rf_spec %>% 
  spark_dataframe() %>% 
  invoke("selectExpr", list("treeID", "nodeData.*", "nodeData.split.*")) %>% 
  sdf_register() %>% 
  select(-split, -impurityStats) %>% 
  left_join(meta, by = "featureIndex",copy = TRUE) %>% 
  left_join(labels, by = "prediction",copy = TRUE)

full_rf_spec


library(igraph)

gframe <- full_rf_spec %>% 
  filter(treeID == 0) %>%   # Take the first tree
  mutate(
    leftCategoriesOrThreshold = ifelse(
      size(leftCategoriesOrThreshold) == 1,
      # Continuous variable case
      concat("<= ", round(concat_ws("", leftCategoriesOrThreshold), 3)),
      # Categorical variable case. Decoding variables might be involved
      # but can be achieved if needed, using column metadata or indexer labels
      concat("in {", concat_ws(",", leftCategoriesOrThreshold), "}")
    ),
    name = coalesce(name, label)) %>% 
 select(
   id, label, impurity, gain, 
   leftChild, rightChild, leftCategoriesOrThreshold, name) %>%
 collect()

vertices <- gframe %>% rename(label = name, name = id)

edges <- gframe %>%
  transmute(from = id, to = leftChild, label = leftCategoriesOrThreshold) %>% 
  union_all(gframe %>% select(from = id, to = rightChild)) %>% 
  filter(to != -1)

g <- igraph::graph_from_data_frame(edges, vertices = vertices)

plot(
  g, layout = layout_as_tree(g, root = c(1)),
  vertex.shape = "rectangle",  vertex.size = 20)