package ie.esb.datalake.jobs.arvato

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import ie.esb.datalake.jobs.common.ReadCsvJob.trimColumns
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.DataFrame
import ie.esb.datalake.ingestion._
import ie.esb.datalake.ingestion.jobs.io.IO
import org.apache.spark.storage.StorageLevel

/**
  * Created by Sabater_A on 20/10/2017.
  */
class ReadExcelFileJob(io: IO) extends MapJob[FileTransfer]{

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {

    // For all the input paths found in the pipeline.conf file in the property file-transfer.files
    // each path is in the form of /landing/[DATASOURCE]/[INTERFACE]. e.g: /landing/ABTRAN/ivr_call_log
    val dfMap: Map[String, DataFrame] =
    (for { path <- pl.in } yield {
      val interface = path.split("/").last
      log.info(s"The path to be read is: ${path}")
      log.info(s"The interface is: ${interface}")
      val int = io.readMultipleExcelFiles(path, filenameIncluded = true)
        .repartition(10)
        .persist(StorageLevel.MEMORY_AND_DISK)

      interface -> trimColumns(int)
    }
      ).toMap.filter(kv => kv._2.count() != 0)

    //dfMap.head._2.dropColumns("myColumns")
    log.info(s"The number of loaded interfaces is: ${dfMap.size}");
    dfMap.map(kv => kv._1 -> Right(kv._2))
  }

}
