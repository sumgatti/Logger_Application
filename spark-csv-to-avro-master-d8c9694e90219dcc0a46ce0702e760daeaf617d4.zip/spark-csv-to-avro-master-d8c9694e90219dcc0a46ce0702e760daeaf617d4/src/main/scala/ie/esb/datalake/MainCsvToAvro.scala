package ie.esb.datalake

import com.typesafe.config.Config
import ie.esb.datalake.commons.LoadedProperties
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Job, Pipeline}
import ie.esb.datalake.jobs._
import ie.esb.datalake.jobs.abtran.ConvertAcdToCsvJob
import ie.esb.datalake.jobs.arvato.ReadExcelFileJob
import ie.esb.datalake.jobs.common._
import org.apache.log4j.{LogManager, Logger}

/**
  * Created by Sabater_A on 11/09/2017.
  */
object MainCsvToAvro {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  def main(args: Array[String]): Unit = {
    execute(new IO, args(0))
  }

  def execute(io: IO, datasource: String, processPath: String = "/process/landing", conf: Config = LoadedProperties.conf): Unit = {

    log.info("CSV to AVRO job for file transfers")
    log.info(s"Datasource: ${datasource}")
    log.info(s"Process base path: ${processPath}")

    val jobList: List[Job[FileTransfer]] =
      datasource match {
        case "abtran" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "abtran-acd_call_details" => List(
          new ConvertAcdToCsvJob(io),
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "snipp" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "capita-inbound" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/inbound", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
          )

        case "capita-outbound" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/outbound", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
           )


        case "loyalty-entries" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/entries", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
           )

        case "networks" => List(
          new ReadCsvJob(io,delimeter = "|"),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "gttrading-zalgnbishrdprices" => List(
          new ReadCsvJob(io,delimeter = ";"),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/zalgnbishrdprices", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        
        case "gttrading-zalgnbiesbetrdta" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/zalgnbiesbetrdta", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "gttrading-zalgnbitrmohedgeft" => List(
          new ReadCsvJob(io,delimeter = ";"),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/zalgnbitrmohedgeft", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        
       
        case "liberty" => List(
          new ReadCsvJob(io),
          //new ConvertDataTypeJob(conf),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "arvato" => List(
          new ReadExcelFileJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "arvato-dialler" => List(
          new ReadCsvJob(io, fileExtension = ".xls", delimeter = "\\t"),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "siemens" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "smartpayg" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "sapds-irp" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/irp", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "sapds-crp" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/crp", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "sapds-srp" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/srp", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "smart-profiles" => List(
          new ReadCsvJob(io),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "broker-irp" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/irp", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "broker" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        case "salesleads" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource, processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "ses-enacto" => List(
          new ReadCsvJob1(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/enacto", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        //*case "ses-enacto-enactometa" => List(
        //  new ReadCsvJob1(io),
        //  new ExtractDateFromFilenameJob(conf),
        // new WriteAvroToProcessJob1(datasource.split("-").head+"/enacto", processPath),
        //  new SplitByProcessedDateJob,
        //  new WriteAvroJob
        //

        case "ses-cylon" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/cylon", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "weatherdata-minutedata" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/minutedata", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "weatherdata-dailydata" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/dailydata", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )


        case "weatherdata-ukdailydata" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/ukdailydata", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )


        case "newstrategy-markettrails" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/markettrails", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )


        case "newstrategy-dfsarchive" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob1(datasource.split("-").head+"/dfsarchive", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )


        case "ndd-nddhybris" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/nddhybris", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
        )


        case "bitztalk-marketmessages_341" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/marketmessages_341", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
        )
        
        case "bitztalk-marketmessages_342" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/marketmessages_342", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
        )
        
        case "bitztalk-marketmessagesni_inbound_342" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/marketmessagesni_inbound_342", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
        )

        case "bitztalk-marketmessages_ni341" => List(
           new ReadCsvJob(io),
           new ExtractDateFromFilenameJob(conf),
           new WriteAvroToProcessJob1(datasource.split("-").head+"/marketmessages_ni341", processPath),
           new SplitByProcessedDateJob,
           new WriteAvroJob
        )

       
        case "frontoffice-tpcat_prx_ni" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_prx_ni", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )


        case "frontoffice-tpcat_prx_coeff_ni" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_prx_coeff_ni", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_fcast_ni" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_fcast_ni", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_mtm_ni" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_mtm_ni", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )

        case "frontoffice-tpcat_mthly_brk_ni" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_mthly_brk_ni", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_prx_coeff_roi" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_prx_coeff_roi", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_prx_roi" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_prx_roi", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_fcast_roi" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_fcast_roi", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_mtm_roi" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_mtm_roi", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )
        
        case "frontoffice-tpcat_mthly_brk_roi" => List(
          new ReadCsvJob(io),
          new ExtractDateFromFilenameJob(conf),
          new WriteAvroToProcessJob(datasource.split("-").head+"/tpcat_mthly_brk_roi", processPath),
          new SplitByProcessedDateJob,
          new WriteAvroJob
        )    
        
      }
    val pipeline = new Pipeline[FileTransfer](datasource, jobList)
    pipeline.run()
  }
}
