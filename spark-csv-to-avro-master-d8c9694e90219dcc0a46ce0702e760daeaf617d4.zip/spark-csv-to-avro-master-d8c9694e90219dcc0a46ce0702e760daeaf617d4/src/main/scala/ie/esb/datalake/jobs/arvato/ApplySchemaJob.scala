package ie.esb.datalake.jobs.arvato

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}

/**
  * Created by Sabater_A on 27/10/2017.
  */
class ApplySchemaJob extends MapJob[FileTransfer]{
  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = ???
}
