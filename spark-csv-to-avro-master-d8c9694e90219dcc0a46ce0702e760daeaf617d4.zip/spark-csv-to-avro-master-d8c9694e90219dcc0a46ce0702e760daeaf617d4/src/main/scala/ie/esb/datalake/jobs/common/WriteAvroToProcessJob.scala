package ie.esb.datalake.jobs.common

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.SaveMode
import com.databricks.spark.avro._
import ie.esb.datalake.ingestion._
import org.apache.avro.generic.GenericData.StringType
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.types.{DataTypes, DecimalType, DoubleType, IntegerType, LongType}
import org.joda.time.format.DateTimeFormat

/**
  * Created by Sabater_A on 13/10/2017.
  */
class WriteAvroToProcessJob(datasource: String, basePath: String) extends MapJob[FileTransfer]{

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    for ((k: String, v: RddOrDf) <- pl.map) yield {
      val outPath = s"${basePath}/${datasource}/${k}/output"

      val newDF: RddOrDf = datasource match {
        /*case "abtran-acd_call_details" => v.withColumn("CallId", v.col("CallId").cast(DataTypes.StringType))
        case "siemens" => v.withColumn("DateTime", ExtractDateFromFilenameJob.udfBigIntStringFormat(col("DateTime"), lit("YYYYMMddHHmmss"), lit("YYYY-MM-dd HH:mm:ss")))
        case "snipp" if v.columns.contains("createdate") =>  v.withColumn("createdate", v.col("createdate").cast(DataTypes.StringType))

        case "abtran" if (k.equalsIgnoreCase("ivr_call_log")) =>
            v.withColumn("DATE_CREATED", v.col("DATE_CREATED").cast(DataTypes.StringType))
              .withColumn("ANSWER_DATETIME", v.col("ANSWER_DATETIME").cast(DataTypes.StringType))
              .withColumn ("END_DATETIME", v.col ("END_DATETIME").cast (DataTypes.StringType) )
              .withColumn ("START_DATETIME", v.col ("START_DATETIME").cast (DataTypes.StringType) )

        case "abtran" if (k.equalsIgnoreCase("ivr_option_log")) =>
            v.withColumn ("STAGE_STARTTIME", v.col ("STAGE_STARTTIME").cast (DataTypes.StringType) )
              .withColumn ("DATE_CREATED", v.col ("DATE_CREATED").cast (DataTypes.StringType) )*/

        case "sapds/irp" if (k.equalsIgnoreCase("easts")) =>
          v.withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeasts")) =>
          v.withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eabl")) =>
          v.withColumn("ADAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATMAX",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATMAX"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATTATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATTATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATERZ", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATERZ"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATPROG", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATPROG"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("THGDATUM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("THGDATUM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("E_ZVBL_BEZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("E_ZVBL_BEZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATREAL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATREAL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("S_ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("S_ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeabl")) =>
          v.withColumn("ADAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATMAX",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATMAX"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATTATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATTATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATERZ", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATERZ"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATPROG", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATPROG"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("THGDATUM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("THGDATUM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("E_ZVBL_BEZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("E_ZVBL_BEZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATREAL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATREAL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("S_ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("S_ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eastl")) =>
          v.withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeastl")) =>
          v.withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("but050")) =>
          v.withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CRDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("CRTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CHDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        //.withColumn ("CHTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("but050")) =>
          v.withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CRDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("CRTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CHDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        //.withColumn ("CHTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpbut050")) =>
          v.withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CRDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn ("CRTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CHDAT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        //.withColumn ("CHTIM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHTIM"), lit("HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("eideswtmsgdata")) =>
          v.withColumn("MSGDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MSGDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MOVEOUTDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZEFFECTFROMDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZEFFECTFROMDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCALCDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCALCDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZISU_OBJECTION", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZISU_OBJECTION"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREAD_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREAD_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZMICSTRTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZMICSTRTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           // .withColumn ("procstatustimest", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("procstatustimest"), lit("YYYYMMddHHmmss"), lit("YYYY-MM-dd HH:mm:ss")))
        
        case "sapds/srp" if (k.equalsIgnoreCase("srpeideswtmsgdata")) =>
          v.withColumn("MSGDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MSGDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MOVEOUTDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZEFFECTFROMDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZEFFECTFROMDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCALCDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCALCDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           // .withColumn ("procstatustimest", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("procstatustimest"), lit("YYYYMMddHHmmss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("euitrans")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EXT_UI", v.col ("EXT_UI").cast (DataTypes.StringType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpeuitrans")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EXT_UI", v.col ("EXT_UI").cast (DataTypes.StringType) )


        case "sapds/irp" if (k.equalsIgnoreCase("euiinstln")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ANLAGE", v.col ("ANLAGE").cast (DataTypes.IntegerType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpeuiinstln")) =>
          v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("eideswtdoc")) =>
          v.withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEINDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZPRICEREQ", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZPRICEREQ"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           .withColumn ("SWITCHNUM", v.col ("SWITCHNUM").cast (DataTypes.StringType) )
            .withColumn ("TIMESTAMP", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TIMESTAMP"), lit("YYYYMMddHHmmss.sss"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("STATUSTIME", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STATUSTIME"), lit("YYYYMMddHHmmss.sss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeideswtdoc")) =>
          v.withColumn("MOVEINDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEINDATE",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEINDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("REALMOVEOUTDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("REALMOVEOUTDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZREGRECPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZREGRECPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZG_READDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZG_READDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SWITCHNUM", v.col ("SWITCHNUM").cast (DataTypes.StringType) )
           // .withColumn ("TIMESTAMP", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TIMESTAMP"), lit("YYYYMMddHHmmss.sss"), lit("YYYY-MM-dd HH:mm:ss")))
           // .withColumn ("STATUSTIME", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STATUSTIME"), lit("YYYYMMddHHmmss.sss"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("eablg")) =>
          v.withColumn("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/srp" if (k.equalsIgnoreCase("srpeablg")) =>
          v.withColumn("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/crp" if (k.equalsIgnoreCase("crpbut000")) =>
            v.withColumn("FOUND_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FOUND_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("LIQUID_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LIQUID_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BIRTHDT",ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIRTHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("DEATHDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DEATHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CRDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CHDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/crp" if (k.equalsIgnoreCase("crpmktperm")) =>
            v.withColumn("VALID_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALID_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("eprofass")) =>
            v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("eprofhead")) =>
            v.withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeprofhead")) =>
            v.withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ARCH_DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ARCH_DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("erdk")) =>
            v.withColumn("DRUCKDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DRUCKDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STO_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STO_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EDISENDDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EDISENDDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("TAXDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TAXDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCRDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCRDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SELECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SELECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srperdk")) =>
            v.withColumn("DRUCKDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DRUCKDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STO_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STO_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EDISENDDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EDISENDDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("TAXDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TAXDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZZCRDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZCRDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SELECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SELECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("erch")) =>
            v.withColumn("BEGABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ENDABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ENDABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PTERMTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PTERMTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BELEGDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BELEGDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STORNODAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STORNODAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BEGNACH", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGNACH"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATSU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATSU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BEGEND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGEND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAA", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAA"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MEM_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MEM_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CORRECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CORRECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srperch")) =>
            v.withColumn("BEGABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ENDABRPE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ENDABRPE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PTERMTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PTERMTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BELEGDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BELEGDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STORNODAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STORNODAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BEGNACH", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGNACH"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABRDATSU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRDATSU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("BEGEND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEGEND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ZUORDDAA", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZUORDDAA"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MEM_BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("MEM_BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CORRECTION_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CORRECTION_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("ever")) =>
          v.withColumn("VBEGINN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VBEGINN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("EINZDAT_ALT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EINZDAT_ALT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VENDE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VENDE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("KUENDDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("KUENDDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VBISDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VBISDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VABSCHLEVU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VABSCHLEVU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("VABSCHLKND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VABSCHLKND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PS_STARTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PS_STARTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EINZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EINZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AUSZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABSSTOPDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABSSTOPDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("KFRIST", v.col ("KFRIST").cast (DataTypes.IntegerType) )
            .withColumn ("VERLAENG", v.col ("VERLAENG").cast (DataTypes.IntegerType) )
            .withColumn ("PERSNR", v.col ("PERSNR").cast (DataTypes.IntegerType) )
            .withColumn ("PS_PSP_PNR", v.col ("PS_PSP_PNR").cast (DataTypes.IntegerType) )
            .withColumn ("OUTCOUNT", v.col ("OUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn ("PYPLS", v.col ("PYPLS").cast (DataTypes.IntegerType) )
            .withColumn ("PYPLA", v.col ("PYPLA").cast (DataTypes.IntegerType) )
            .withColumn ("SALESEMPLOYEE", v.col ("SALESEMPLOYEE").cast (DataTypes.IntegerType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpever")) =>
          v.withColumn("VBEGINN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VBEGINN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("EINZDAT_ALT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EINZDAT_ALT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VENDE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VENDE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("KUENDDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("KUENDDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VBISDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VBISDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("VABSCHLEVU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VABSCHLEVU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("VABSCHLKND", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VABSCHLKND"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PS_STARTDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PS_STARTDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("EINZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("EINZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("AUSZDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSZDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABSSTOPDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABSSTOPDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("KFRIST", v.col ("KFRIST").cast (DataTypes.IntegerType) )
            .withColumn ("VERLAENG", v.col ("VERLAENG").cast (DataTypes.IntegerType) )
            .withColumn ("PERSNR", v.col ("PERSNR").cast (DataTypes.IntegerType) )
            .withColumn ("PS_PSP_PNR", v.col ("PS_PSP_PNR").cast (DataTypes.IntegerType) )
            .withColumn ("OUTCOUNT", v.col ("OUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn ("PYPLS", v.col ("PYPLS").cast (DataTypes.IntegerType) )
            .withColumn ("PYPLA", v.col ("PYPLA").cast (DataTypes.IntegerType) )
            .withColumn ("SALESEMPLOYEE", v.col ("SALESEMPLOYEE").cast (DataTypes.IntegerType) )

        case "sapds/irp" if (k.equalsIgnoreCase("ettifn")) =>
          v.withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ALTBIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ALTBIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABLFDNR", v.col ("ABLFDNR").cast (DataTypes.IntegerType) )
            .withColumn ("WERT1", v.col ("WERT1").cast (DataTypes.DoubleType) )
            .withColumn ("WERT2", v.col ("WERT2").cast (DataTypes.DoubleType) )
            .withColumn ("BETRAG", v.col ("BETRAG").cast (DataTypes.DoubleType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpettifn")) =>
          v.withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ALTBIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ALTBIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ABLFDNR", v.col ("ABLFDNR").cast (DataTypes.IntegerType) )
            .withColumn ("WERT1", v.col ("WERT1").cast (DataTypes.DoubleType) )
            .withColumn ("WERT2", v.col ("WERT2").cast (DataTypes.DoubleType) )
            .withColumn ("BETRAG", v.col ("BETRAG").cast (DataTypes.DoubleType) )
        case "sapds/irp" if (k.equalsIgnoreCase("eanlh")) =>
          v.withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpeanlh")) =>
          v.withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("adrc")) =>
          v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/srp" if (k.equalsIgnoreCase("srpadrc")) =>
          v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
        case "sapds/irp" if (k.equalsIgnoreCase("dfkklocks")) =>
          v.withColumn("FDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("TDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("ADATUM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATUM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          .withColumn("LAUFD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LAUFD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpdfkklocks")) =>
          v.withColumn("FDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("TDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ADATUM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATUM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("LAUFD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LAUFD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("but000")) =>
          v.withColumn("FOUND_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FOUND_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("LIQUID_DAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LIQUID_DAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BIRTHDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIRTHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DEATHDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DEATHDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CRDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CRDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CHDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CHDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("VRDAT_FIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VRDAT_FIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("MEM_HOUSE", v.col ("MEM_HOUSE").cast (DataTypes.DoubleType) )
            .withColumn("VALID_FROM", v.col ("VALID_FROM").cast (DataTypes.DoubleType) )
            .withColumn("VALID_TO", v.col ("VALID_TO").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("fkkvkp")) =>
          v.withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDATP", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDATP"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STOPD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STOPD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("QSZDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("QSZDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("INV_CYCLE_START", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("INV_CYCLE_START"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BPL_FDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BPL_FDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BPL_TDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BPL_TDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_FROM_ACC", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM_ACC"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ZZLHPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZLHPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ZZLWPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZLWPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FDZTG", v.col ("FDZTG").cast (DataTypes.IntegerType) )
            .withColumn ("DDLNM", v.col ("DDLNM").cast (DataTypes.IntegerType) )
            .withColumn ("ABSANFAB", v.col ("ABSANFAB").cast (DataTypes.IntegerType) )
            .withColumn ("ABSANFBZ", v.col ("ABSANFBZ").cast (DataTypes.IntegerType) )
            .withColumn ("EINZUGSZ", v.col ("EINZUGSZ").cast (DataTypes.IntegerType) )
            .withColumn ("RUECKLZ", v.col ("RUECKLZ").cast (DataTypes.IntegerType) )
            .withColumn ("OUTCOUNT", v.col ("OUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn ("JVLTE", v.col ("JVLTE").cast (DataTypes.IntegerType) )
            .withColumn ("ZZOUTCOUNT", v.col ("ZZOUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn("DDLAM", v.col ("DDLAM").cast (DataTypes.DoubleType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpfkkvkp")) =>
          v.withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDATP", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDATP"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STOPD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STOPD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("QSZDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("QSZDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("INV_CYCLE_START", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("INV_CYCLE_START"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BPL_FDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BPL_FDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BPL_TDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BPL_TDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_FROM_ACC", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM_ACC"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ZZLHPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZLHPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ZZLWPDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZLWPDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("FDZTG", v.col ("FDZTG").cast (DataTypes.IntegerType) )
            .withColumn ("DDLNM", v.col ("DDLNM").cast (DataTypes.IntegerType) )
            .withColumn ("ABSANFAB", v.col ("ABSANFAB").cast (DataTypes.IntegerType) )
            .withColumn ("ABSANFBZ", v.col ("ABSANFBZ").cast (DataTypes.IntegerType) )
            .withColumn ("EINZUGSZ", v.col ("EINZUGSZ").cast (DataTypes.IntegerType) )
            .withColumn ("RUECKLZ", v.col ("RUECKLZ").cast (DataTypes.IntegerType) )
            .withColumn ("OUTCOUNT", v.col ("OUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn ("JVLTE", v.col ("JVLTE").cast (DataTypes.IntegerType) )
            .withColumn ("ZZOUTCOUNT", v.col ("ZZOUTCOUNT").cast (DataTypes.IntegerType) )
            .withColumn("DDLAM", v.col ("DDLAM").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("eprofval15")) =>
          v.withColumn("VALUEDAY", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALUEDAY"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PROFILE", v.col ("PROFILE").cast (DataTypes.IntegerType) )

        case "sapds/irp" if (k.equalsIgnoreCase("eprofval30")) =>
          v.withColumn("VALUEDAY", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALUEDAY"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PROFILE", v.col ("PROFILE").cast (DataTypes.IntegerType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpeprofval15")) =>
          v.withColumn("VALUEDAY", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALUEDAY"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PROFILE", v.col ("PROFILE").cast (DataTypes.IntegerType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpeprofval30")) =>
          v.withColumn("VALUEDAY", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("VALUEDAY"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PROFILE", v.col ("PROFILE").cast (DataTypes.IntegerType) )

        case "sapds/irp" if (k.equalsIgnoreCase("qmel")) =>
          v.withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("QMDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("QMDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STRMN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STRMN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("LTRMN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("LTRMN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("QMDAB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("QMDAB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BEZDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BEZDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BSTDK", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BSTDK"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("RKDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("RKDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("PRODDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PRODDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("MGEIG", v.col ("MGEIG").cast (DataTypes.DoubleType) )
            .withColumn ("MGFRD", v.col ("MGFRD").cast (DataTypes.DoubleType) )
            .withColumn ("BZMNG", v.col ("BZMNG").cast (DataTypes.DoubleType) )
            .withColumn ("RKMNG", v.col ("RKMNG").cast (DataTypes.DoubleType) )
            .withColumn ("RGMNG", v.col ("RGMNG").cast (DataTypes.DoubleType) )
            .withColumn ("ESTIMATED_COSTS", v.col ("ESTIMATED_COSTS").cast (DataTypes.DoubleType) )
            .withColumn ("CLAIMED_COSTS", v.col ("CLAIMED_COSTS").cast (DataTypes.DoubleType) )
            .withColumn ("RESULT_COSTS", v.col ("RESULT_COSTS").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("dfkkop")) =>
          v.withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGBD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGBD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGVD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGVD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CPUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CPUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUSDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SKTPZ", v.col ("SKTPZ").cast (DataTypes.DoubleType) )
            .withColumn ("BETRH", v.col ("BETRH").cast (DataTypes.DoubleType) )
            .withColumn ("BETRW", v.col ("BETRW").cast (DataTypes.DoubleType) )
            .withColumn ("SKFBT", v.col ("SKFBT").cast (DataTypes.DoubleType) )
            .withColumn ("SBETH", v.col ("SBETH").cast (DataTypes.DoubleType) )
            .withColumn ("SBETW", v.col ("SBETW").cast (DataTypes.DoubleType) )
            .withColumn ("AUGBT", v.col ("AUGBT").cast (DataTypes.DoubleType) )
            .withColumn ("AUGBS", v.col ("AUGBS").cast (DataTypes.DoubleType) )
            .withColumn ("AUGSK", v.col ("AUGSK").cast (DataTypes.DoubleType) )
            .withColumn ("SCTAX", v.col ("SCTAX").cast (DataTypes.DoubleType) )
            .withColumn ("STTAX", v.col ("STTAX").cast (DataTypes.DoubleType) )
            .withColumn ("ODQ_ENTITYCNTR", v.col ("ODQ_ENTITYCNTR").cast (DataTypes.DoubleType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpdfkkop")) =>
          v.withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGBD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGBD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGVD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGVD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CPUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CPUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUSDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("SKTPZ", v.col ("SKTPZ").cast (DataTypes.DoubleType) )
            .withColumn ("BETRH", v.col ("BETRH").cast (DataTypes.DoubleType) )
            .withColumn ("BETRW", v.col ("BETRW").cast (DataTypes.DoubleType) )
            .withColumn ("SKFBT", v.col ("SKFBT").cast (DataTypes.DoubleType) )
            .withColumn ("SBETH", v.col ("SBETH").cast (DataTypes.DoubleType) )
            .withColumn ("SBETW", v.col ("SBETW").cast (DataTypes.DoubleType) )
            .withColumn ("AUGBT", v.col ("AUGBT").cast (DataTypes.DoubleType) )
            .withColumn ("AUGBS", v.col ("AUGBS").cast (DataTypes.DoubleType) )
            .withColumn ("AUGSK", v.col ("AUGSK").cast (DataTypes.DoubleType) )
            .withColumn ("SCTAX", v.col ("SCTAX").cast (DataTypes.DoubleType) )
            .withColumn ("STTAX", v.col ("STTAX").cast (DataTypes.DoubleType) )
            .withColumn ("ODQ_ENTITYCNTR", v.col ("ODQ_ENTITYCNTR").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("sales_stats")) =>
          v.withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           .withColumn ("ANZVERTR", v.col ("ANZVERTR").cast (DataTypes.DoubleType) )
           .withColumn ("ANZTAGE", v.col ("ANZTAGE").cast (DataTypes.DoubleType) )
           .withColumn ("BETRAG", v.col ("BETRAG").cast (DataTypes.DoubleType) )
           .withColumn ("MENGE", v.col ("MENGE").cast (DataTypes.DoubleType) )

        case "sapds/srp" if (k.equalsIgnoreCase("srpsales_stats")) =>
          v.withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ANZVERTR", v.col ("ANZVERTR").cast (DataTypes.DoubleType) )
            .withColumn ("ANZTAGE", v.col ("ANZTAGE").cast (DataTypes.DoubleType) )
            .withColumn ("BETRAG", v.col ("BETRAG").cast (DataTypes.DoubleType) )
            .withColumn ("MENGE", v.col ("MENGE").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("bp_items")) =>
          v.withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGBD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGBD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGVD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGVD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CPUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CPUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUSDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/srp" if (k.equalsIgnoreCase("srpbp_items")) =>
          v.withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDN", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDN"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("FAEDS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("FAEDS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("STUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGBD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGBD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUGVD", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUGVD"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZU", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZU"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("ABRZO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ABRZO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CPUDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CPUDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBLDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("CLBUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("CLBUDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("AUSDT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AUSDT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/irp" if (k.equalsIgnoreCase("but020")) =>
          v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADDR_VALID_FROM", v.col ("ADDR_VALID_FROM").cast (DataTypes.DoubleType) )
            .withColumn ("ADDR_VALID_TO", v.col ("ADDR_VALID_TO").cast (DataTypes.DoubleType) )
            .withColumn ("ADDR_MOVE_DATE", v.col ("ADDR_MOVE_DATE").cast (DataTypes.DoubleType) )

        case "sapds/crp" if (k.equalsIgnoreCase("crpbut020")) =>
          v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("ADDR_VALID_FROM", v.col ("ADDR_VALID_FROM").cast (DataTypes.DoubleType) )
            .withColumn ("ADDR_VALID_TO", v.col ("ADDR_VALID_TO").cast (DataTypes.DoubleType) )
            .withColumn ("ADDR_MOVE_DATE", v.col ("ADDR_MOVE_DATE").cast (DataTypes.DoubleType) )

        case "sapds/irp" if (k.equalsIgnoreCase("but021_fs")) =>
            v.withColumn ("VALID_TO", v.col ("VALID_TO").cast (DataTypes.DoubleType) )
            .withColumn ("VALID_FROM", v.col ("VALID_FROM").cast (DataTypes.DoubleType) )
            .withColumn ("CLIENT", v.col ("CLIENT").cast (DataTypes.StringType) )
            .withColumn ("PARTNER", v.col ("PARTNER").cast (DataTypes.StringType) )
            .withColumn ("ADDRNUMBER", v.col ("ADDRNUMBER").cast (DataTypes.StringType) )

        case "sapds/crp" if (k.equalsIgnoreCase("crpbut021_fs")) =>
          v.withColumn ("VALID_TO", v.col ("VALID_TO").cast (DataTypes.DoubleType) )
            .withColumn ("VALID_FROM", v.col ("VALID_FROM").cast (DataTypes.DoubleType) )
            .withColumn ("CLIENT", v.col ("CLIENT").cast (DataTypes.StringType) )
            .withColumn ("PARTNER", v.col ("PARTNER").cast (DataTypes.StringType) )
            .withColumn ("ADDRNUMBER", v.col ("ADDRNUMBER").cast (DataTypes.StringType) )

        //case "broker/irp" if (k.equalsIgnoreCase("ni")) =>
          //v.withColumn("DateID", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DateID"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          //  v.withColumn("BrokerFromDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerFromDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BrokerToDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerToDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BillFrom", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillFrom"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BillTo", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillTo"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

       // case "broker/irp" if (k.equalsIgnoreCase("ri")) =>
         // v.withColumn("DateID", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DateID"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
         //   v.withColumn("BrokerFromDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerFromDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          //  .withColumn("BrokerToDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerToDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           // .withColumn("BillFrom", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillFrom"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
           // .withColumn("BillTo", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillTo"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        //case "broker" if (k.equalsIgnoreCase("srp")) =>
          //withColumn("DateID", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DateID"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
          //  v.withColumn("BrokerFromDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerFromDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BrokerToDate", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BrokerToDate"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BillFrom", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillFrom"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            //.withColumn("BillTo", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BillTo"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("crpadr2")) =>
            v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CONSNUMBER", v.col ("CONSNUMBER").cast (DataTypes.DoubleType))

        case "sapds/irp" if (k.equalsIgnoreCase("adr2")) =>
          v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CONSNUMBER", v.col ("CONSNUMBER").cast (DataTypes.DoubleType))

        case "sapds/crp" if (k.equalsIgnoreCase("crpcrmd_orderadm_h")) =>
          v.withColumn("POSTING_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("POSTING_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("CREATED_AT", v.col ("CREATED_AT").cast (DataTypes.DoubleType))
            .withColumn ("CHANGED_AT", v.col ("CHANGED_AT").cast (DataTypes.DoubleType))
            .withColumn ("HEAD_CHANGED_AT", v.col ("HEAD_CHANGED_AT").cast (DataTypes.DoubleType))
            .withColumn ("VERIFY_DATE", v.col ("VERIFY_DATE").cast (DataTypes.DoubleType))
            .withColumn ("CRM_CHANGED_AT", v.col ("CRM_CHANGED_AT").cast (DataTypes.DoubleType))
            .withColumn ("POSTPROCESS_AT", v.col ("POSTPROCESS_AT").cast (DataTypes.DoubleType))

        case "sapds/crp" if (k.equalsIgnoreCase("crpscapptseg")) =>
      v.withColumn ("TST_FROM", v.col ("TST_FROM").cast (DataTypes.StringType))
      .withColumn ("TST_TO", v.col ("TST_TO").cast (DataTypes.StringType))
      .withColumn ("ENTRY_TST", v.col ("ENTRY_TST").cast (DataTypes.StringType))
      .withColumn ("CHANGE_TST", v.col ("CHANGE_TST").cast (DataTypes.StringType))

        case "sapds/crp" if (k.equalsIgnoreCase("crpadrc")) =>
           v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATE_TO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_TO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

         case "sapds/irp" if (k.equalsIgnoreCase("eprofvalstat")) =>
           v.withColumn("DATETO", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATETO"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATEFROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATEFROM"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("PROFILE", v.col ("PROFILE").cast (DataTypes.IntegerType))
            .withColumn ("CHGNR", v.col ("CHGNR").cast (DataTypes.IntegerType))

         case "sapds/irp" if (k.equalsIgnoreCase("dberchz1")) =>
           v.withColumn("AB", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AB"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("BIS", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BIS"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATUM1", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATUM1"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn("DATUM2", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATUM2"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("TCNUMTOR", v.col ("TCNUMTOR").cast (DataTypes.DoubleType))
            .withColumn ("TCDENOMTOR", v.col ("TCDENOMTOR").cast (DataTypes.DoubleType))
            .withColumn ("V_ABRMENGE", v.col ("V_ABRMENGE").cast (DataTypes.DoubleType))
            .withColumn ("N_ABRMENGE", v.col ("N_ABRMENGE").cast (DataTypes.DoubleType))
            .withColumn ("V_ZAHL1", v.col ("V_ZAHL1").cast (DataTypes.DoubleType))
            .withColumn ("N_ZAHL1", v.col ("N_ZAHL1").cast (DataTypes.DoubleType))
            .withColumn ("V_ZAHL2", v.col ("V_ZAHL2").cast (DataTypes.DoubleType))
            .withColumn ("N_ZAHL2", v.col ("N_ZAHL2").cast (DataTypes.DoubleType))
            .withColumn ("V_ZAHL3", v.col ("V_ZAHL3").cast (DataTypes.DoubleType))
            .withColumn ("N_ZAHL3", v.col ("N_ZAHL3").cast (DataTypes.DoubleType))
            .withColumn ("V_ZAHL4", v.col ("V_ZAHL4").cast (DataTypes.DoubleType))
            .withColumn ("N_ZAHL4", v.col ("N_ZAHL4").cast (DataTypes.DoubleType))
            .withColumn ("V_ZEITANT", v.col ("V_ZEITANT").cast (DataTypes.DoubleType))
            .withColumn ("N_ZEITANT", v.col ("N_ZEITANT").cast (DataTypes.DoubleType))
            .withColumn ("BELZEILE", v.col ("BELZEILE").cast (DataTypes.IntegerType))
            .withColumn ("CSNO", v.col ("CSNO").cast (DataTypes.IntegerType))
            .withColumn ("SNO", v.col ("SNO").cast (DataTypes.IntegerType))
            .withColumn ("BACKDOCLINE", v.col ("BACKDOCLINE").cast (DataTypes.IntegerType))
            .withColumn ("LRATESTEP", v.col ("LRATESTEP").cast (DataTypes.IntegerType))
            .withColumn ("OPLFDNR", v.col ("OPLFDNR").cast (DataTypes.IntegerType))

        case "sapds/irp" if (k.equalsIgnoreCase("dberchz3")) =>
           v.withColumn("TXDAT_KK", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("TXDAT_KK"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
            .withColumn ("NETTOBTR", v.col ("NETTOBTR").cast (DataTypes.DoubleType))
            .withColumn ("PREISBTR", v.col ("PREISBTR").cast (DataTypes.DoubleType))
            .withColumn ("MNGBASIS", v.col ("MNGBASIS").cast (DataTypes.DoubleType))
            .withColumn ("URPREIS", v.col ("URPREIS").cast (DataTypes.DoubleType))
            .withColumn ("PREIADD", v.col ("PREIADD").cast (DataTypes.DoubleType))
            .withColumn ("PREIFAKT", v.col ("PREIFAKT").cast (DataTypes.DoubleType))
            .withColumn ("V_NETTOBTR_L", v.col ("V_NETTOBTR_L").cast (DataTypes.DoubleType))
            .withColumn ("N_NETTOBTR_L", v.col ("N_NETTOBTR_L").cast (DataTypes.DoubleType))
            .withColumn ("BELZEILE", v.col ("BELZEILE").cast (DataTypes.IntegerType))
            .withColumn ("VONZONE", v.col ("VONZONE").cast (DataTypes.IntegerType))
            .withColumn ("BISZONE", v.col ("BISZONE").cast (DataTypes.IntegerType))
            .withColumn ("ZONENNR", v.col ("ZONENNR").cast (DataTypes.IntegerType))
            .withColumn ("PS_PSP_PNR", v.col ("PS_PSP_PNR").cast (DataTypes.IntegerType))
            .withColumn ("PAOBJNR", v.col ("PAOBJNR").cast (DataTypes.IntegerType))
            .withColumn ("PAOBJNR_S", v.col ("PAOBJNR_S").cast (DataTypes.IntegerType))

        case "sapds/irp" if (k.equalsIgnoreCase("aufk")) =>
           v.withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("STDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT1", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT1"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT2", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT2"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT3", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT3"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT1", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT1"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT2", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT2"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT3", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT3"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("SDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER5", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER5"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER7", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER7"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER8", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER8"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("ZZAPPT_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZAPPT_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn ("ZZTOTAL_DEBIT", v.col ("ZZTOTAL_DEBIT").cast (DataTypes.DoubleType))
             .withColumn ("ZZWKLY_INST", v.col ("ZZWKLY_INST").cast (DataTypes.DoubleType))
             .withColumn ("ZZEMG_CRD_SET", v.col ("ZZEMG_CRD_SET").cast (DataTypes.DoubleType))
             .withColumn ("AUTYP", v.col ("AUTYP").cast (DataTypes.IntegerType))
             .withColumn ("ASTNR", v.col ("ASTNR").cast (DataTypes.IntegerType))
             .withColumn ("ESTNR", v.col ("ESTNR").cast (DataTypes.IntegerType))
             .withColumn ("SEQNR", v.col ("SEQNR").cast (DataTypes.IntegerType))
             .withColumn ("USER4", v.col ("USER4").cast (DataTypes.IntegerType))
             .withColumn ("PSPEL", v.col ("PSPEL").cast (DataTypes.IntegerType))
             .withColumn ("KDPOS", v.col ("KDPOS").cast (DataTypes.IntegerType))
             .withColumn ("PROCNR", v.col ("PROCNR").cast (DataTypes.IntegerType))
             .withColumn ("COSTESTNR", v.col ("COSTESTNR").cast (DataTypes.IntegerType))

          case "sapds/srp" if (k.equalsIgnoreCase("srpaufk")) =>
            v.withColumn("ERDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ERDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("AEDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("AEDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("STDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("STDAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT1", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT1"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT2", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT2"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("PDAT3", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("PDAT3"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT1", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT1"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT2", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT2"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("IDAT3", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("IDAT3"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("SDATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("SDATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER5", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER5"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER7", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER7"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("USER8", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("USER8"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("ZZAPPT_DATE", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ZZAPPT_DATE"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn ("ZZTOTAL_DEBIT", v.col ("ZZTOTAL_DEBIT").cast (DataTypes.DoubleType))
             .withColumn ("ZZWKLY_INST", v.col ("ZZWKLY_INST").cast (DataTypes.DoubleType))
             .withColumn ("ZZEMG_CRD_SET", v.col ("ZZEMG_CRD_SET").cast (DataTypes.DoubleType))
             .withColumn ("ZZINVOICEAMT", v.col ("ZZINVOICEAMT").cast (DataTypes.DoubleType))
             .withColumn ("ZZVOLUMEINDEX", v.col ("ZZVOLUMEINDEX").cast (DataTypes.DoubleType))
             .withColumn ("AUTYP", v.col ("AUTYP").cast (DataTypes.IntegerType))
             .withColumn ("ASTNR", v.col ("ASTNR").cast (DataTypes.IntegerType))
             .withColumn ("ESTNR", v.col ("ESTNR").cast (DataTypes.IntegerType))
             .withColumn ("ABKRS", v.col ("ABKRS").cast (DataTypes.IntegerType))
             .withColumn ("SEQNR", v.col ("SEQNR").cast (DataTypes.IntegerType))
             .withColumn ("USER4", v.col ("USER4").cast (DataTypes.IntegerType))
             .withColumn ("PSPEL", v.col ("PSPEL").cast (DataTypes.IntegerType))
             .withColumn ("KDPOS", v.col ("KDPOS").cast (DataTypes.IntegerType))
             .withColumn ("PROCNR", v.col ("PROCNR").cast (DataTypes.IntegerType))
             .withColumn ("COSTESTNR", v.col ("COSTESTNR").cast (DataTypes.IntegerType))

          case "sapds/srp" if (k.equalsIgnoreCase("srpmtr_doc")) =>
            v.withColumn("ADAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADAT"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))
             .withColumn ("MRESULT", v.col ("MRESULT").cast (DataTypes.DoubleType))
             .withColumn ("MR_BILL", v.col ("MR_BILL").cast (DataTypes.DoubleType))
             .withColumn ("ZWNUMMER", v.col ("ZWNUMMER").cast (DataTypes.IntegerType))

          case "sapds/srp" if (k.equalsIgnoreCase("srpmtr_docr")) =>
            v.withColumn("ADATSOLL", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("ADATSOLL"), lit("YYYY.MM.dd"), lit("YYYY-MM-dd HH:mm:ss")))

          case "sapds/srp" if (k.equalsIgnoreCase("srpadr6")) =>
            v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

         case "sapds/irp" if (k.equalsIgnoreCase("dfkkzk")) =>
             v.withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
              .withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

         case "sapds/irp" if (k.equalsIgnoreCase("dfkkzp")) =>
             v.withColumn("BUDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BUDAT"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))
              .withColumn("BLDAT", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("BLDAT"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))


          case "sapds/irp" if (k.equalsIgnoreCase("adr6")) =>
            v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

        case "sapds/crp" if (k.equalsIgnoreCase("crpadr6")) =>
            v.withColumn("DATE_FROM", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("DATE_FROM"), lit("YYYY-MM-dd HH:mm:ss"), lit("YYYY-MM-dd HH:mm:ss")))

       /*case "ses/cylon" if (k.equalsIgnoreCase("cylondata")) =>
          v.withColumn("timestamp",  v.col ("timestamp").cast (DataTypes.StringType))
            .withColumn("node_id",  v.col ("node_id").cast (DataTypes.StringType))*/


        /*case "ses/enacto" if (k.equalsIgnoreCase("enactodata")) =>
            v.withColumn("SOURCE", lit("Honeywell"))
              .withColumn("timestamp", ExtractDateFromFilenameJob.udfSAPDSDateFormat(col("timestamp"), lit("YYYY/MM/dd HH:mm"), lit("YYYY-MM-dd HH:mm:ss")))*/

        case _ => v
      }
      newDF.write.mode(SaveMode.Overwrite).avro(outPath)
    }
    pl.map
  }
}