package ie.esb.datalake.jobs.common

import ie.esb.datalake.ingestion.{RddOrDf, _}
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Created by Sabater_A on 14/09/2017.
  */
class SplitByProcessedDateJob extends MapJob[FileTransfer] {
  @transient lazy val log: Logger = LogManager.getLogger(getClass)
  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    val splitByColumn = "ProcessedDate"
    val arrayOfMaps = for ((k: String, v: RddOrDf) <- pl.map) yield {
      val df: DataFrame = v
      val dates: Array[String] = df.select(splitByColumn).distinct.collect().map(r => r.getString(0))
      dates.map(date => (s"${k}#${date}" -> Right(df.where(col(splitByColumn) === date))))
    }
    val dfMap = arrayOfMaps.flatten.toMap
    dfMap
  }
}


