package ie.esb.datalake

import org.apache.spark.sql.types._


/**
  * Created by Sabater_A on 25/10/2017.
  */
object Schemas {

  val libertyVends = StructType(Seq(
    StructField("PremiseNo", StringType, true),
    StructField("Title", StringType, true),
    StructField("FirstName", StringType, true),
    StructField("LastName", StringType, true),
    StructField("mprn", StringType, true),
    StructField("IssueDate", StringType, true),
    StructField("Meterno", StringType, true),
    StructField("TransactionAmount", DoubleType, true),
    StructField("MeterCreditAmount", DoubleType, true),
    StructField("PreviousChargesDeduction", DoubleType, true),
    StructField("PreviousChargesLeft", DoubleType, true),
    StructField("WrittenoffPreviousCharges", DoubleType, true),
    StructField("VatOnEnergyAmount", DoubleType, true),
    StructField("VatonPreviousCharges", DoubleType, true),
    StructField("TotalVat", DoubleType, true),
    StructField("VatRate", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true),
    StructField("PaymentMode", StringType, true),
    StructField("VendCode", StringType, true),
    StructField("TarrifCategory", IntegerType, true),
    StructField("TarrifName", StringType, true),
    StructField("TarrifId", IntegerType, true),
    StructField("CallCentre", StringType, true),
    StructField("Operator", StringType, true),
    StructField("AgentId", StringType, true),
    StructField("TerminalId", StringType, true),
    StructField("InvalidRequestDate", StringType, true),
    StructField("ConfirmedInvalidRequestDate", StringType, true),
    StructField("InvalidRequestConfirmedUser", StringType, true),
    StructField("TransactionType", StringType, true),
    StructField("TransactionStatus", IntegerType, true),
    StructField("CurrentDate", StringType, true),
    StructField("RspCode", StringType, true),
    StructField("ComServerNo", IntegerType, true),
    StructField("Terminal/ComServerTransRequestDate", StringType, true),
    StructField("EncryptionServerTransNo", StringType, true),
    StructField("Terminal/ComServerTransNo", StringType, true),
    StructField("BusinessPercentage", DoubleType, true),
    StructField("TokenType", StringType, true),
    StructField("CreditAccount", DoubleType, true),
    StructField("FreeVendAmount", DoubleType, true),
    StructField("ReasonCode", StringType, true),
    StructField("ReasonCodeDetails", StringType, true),
    StructField("PostCode", StringType, true)
  ))

  val libertyCustomer = StructType(Seq(
    StructField("PremiseNo", StringType, true),
    StructField("FirstName", StringType, true),
    StructField("LastName", StringType, true),
    StructField("HouseName", StringType, true),
    StructField("Street1", StringType, true),
    StructField("Street2", StringType, true),
    StructField("Town/County", StringType, true),
    StructField("Phone1", StringType, true),
    StructField("Mprn", StringType, true),
    StructField("MeterNo", StringType, true),
    StructField("TariffCategory", IntegerType, true),
    StructField("TariffName", StringType, true),
    StructField("MeterInstallDate", StringType, true),
    StructField("CustomerEntryDate", StringType, true),
    StructField("PreviousChargeLeft", DoubleType, true),
    StructField("MeterRemovalDate", StringType, true),
    StructField("LastRecordModifiedDate", StringType, true),
    StructField("InitialPreviousCharge", DoubleType, true),
    StructField("CreditAccount", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true)
  ))

  val siemens = StructType(Seq(
    StructField("ShipperID", StringType, true),
    StructField("GPRN", StringType, true),
    StructField("MeterNumber", StringType, true),
    StructField("GasCardNumber", StringType, true),
    StructField("Outlet", StringType, true),
    StructField("ShipperTransactionRef", StringType, true),
    StructField("DateTime", StringType, true),
    StructField("GasDebtIndicator" , StringType, true),
    StructField("Amount", DoubleType, true),
    StructField("RecoveryRate", DoubleType, true),
    StructField("GasDebtWeeklyMin", DoubleType, true),
    StructField("GasDebtWeeklyMax", DoubleType, true),
    StructField("EmegencyCreditLimit", DoubleType, true),
    StructField("EmergencyCreditDebt", DoubleType, true),
    StructField("CreditAdjustmentLog1Indicator", StringType, true),
    StructField("CreditAdjustmentLog1Amount", DoubleType, true),
    StructField("CreditAdjustmentLog2Indicator", StringType, true),
    StructField("CreditAdjustmentLog2Amount", DoubleType, true),
    StructField("CreditAdjustmentLog3Indicator", StringType, true),
    StructField("CreditAdjustmentLog3Amount", DoubleType, true),
    StructField("GasDebtLog1Indicator", StringType, true),
    StructField("GasDebtLog1Amount", DoubleType, true),
    StructField("GasDebtLog2Indicator", StringType, true),
    StructField("GasDebtLog2Amount", DoubleType, true),
    StructField("GasDebtLog3Indicator", StringType, true),
    StructField("GasDebtLog3Amount", DoubleType, true)
  ))

  val arvatoDials = StructType(Seq(
    StructField("JobName", StringType, true),
    StructField("JobDate", StringType, true),
    StructField("CallTime", StringType, true),
    StructField("WaitTime", IntegerType, true),
    StructField("ContractAccountNumber", LongType, true),
    StructField("CallCode", IntegerType, true),
    StructField("Telephone", StringType, true),
    StructField("Agent", StringType, true),
    StructField("TalkTime", IntegerType, true),
    StructField("WrapTime", IntegerType, true),
    StructField("CallDirection", StringType, true)
  ))

  val abtranacdcalls = StructType(Seq(
    StructField("CallId", StringType, true),
    StructField("CallType", StringType, true),
    StructField("CallDirection", StringType, true),
    StructField("LineId", StringType, true),
    StructField("LocalUserId", StringType, true),
    StructField("AssignedWorkGroup", StringType, true),
    StructField("RemoteNumberFmt", StringType, true),
    StructField("InitiatedDate", StringType, true),
    StructField("InitiatedDateTimeGMT", StringType, true),
    StructField("ConnectedDate", StringType, true),
    StructField("ConnectedDateTimeGMT", StringType, true),
    StructField("TerminatedDate", StringType, true),
    StructField("TerminatedDateTimeGMT", StringType, true),
    StructField("CallDurationSeconds", StringType, true),
    StructField("HoldDurationSeconds", StringType, true),
    StructField("LineDurationSeconds", StringType, true),
    StructField("DNIS", StringType, true),
    StructField("CallEventLog", StringType, true),
    StructField("I3TimeStampGMT", StringType, true),
    StructField("WrapUpCode", StringType, true),
    StructField("tDialing", StringType, true),
    StructField("tIVRWait", StringType, true),
    StructField("tQueueWait", StringType, true),
    StructField("tAlert", StringType, true),
    StructField("tSuspend", StringType, true),
    StructField("tConference", StringType, true),
    StructField("tExternal", StringType, true),
    StructField("tACW", StringType, true),
    StructField("nIVR", StringType, true),
    StructField("nQueueWait", StringType, true),
    StructField("nTalk", StringType, true),
    StructField("nConference", StringType, true),
    StructField("nHeld", StringType, true),
    StructField("nTransfer", StringType, true),
    StructField("nExternal", StringType, true)
  ))

 val ivr_call_log = StructType(Seq(
    StructField("CALL_LOG_ID", StringType, true),
    StructField("CAMPAIGN_ID", IntegerType, true),
    StructField("START_DATETIME", StringType, true),
    StructField("ANSWER_DATETIME", StringType, true),
    StructField("CLI", StringType, true),
    StructField("DROPOUT_REASON_ID", IntegerType, true),
    StructField("CONTRACT_ACCOUNT_NUMBER", IntegerType, true),
    StructField("END_DATETIME", StringType, true),
    StructField("DATE_CREATED", StringType, true),
    StructField("INBOUND_CHANNEL", StringType, true)
))
 
  
  val enactodata = StructType(Seq(
    StructField("node_id", StringType, true),
    StructField("timestamp", StringType, true),
    StructField("const1", StringType, true),
    StructField("value", IntegerType, true),
    StructField("const2", StringType, true)

  ))

  val enactometa = StructType(Seq(
    StructField("node_id", StringType, true),
    StructField("node_path", StringType, true),
    StructField("unit_label", StringType, true),
    StructField("utility", StringType, true),
    StructField("source", StringType, true),
    StructField("site_name", StringType, true),
    StructField("site_number", IntegerType, true),
    StructField("meter_name", StringType, true),
    StructField("channel_name", StringType, true),
    StructField("metering_purpose", StringType, true),
    StructField("metering_subpurpose", StringType, true),
    StructField("meter_multiplier", StringType, true)

  ))
  
  
  }
