package ie.esb.datalake.jobs.abtran

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import ie.esb.datalake.jobs.abtran.ConvertAcdToCsvJob._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.AccumulatorParam
import org.apache.spark.sql.{DataFrame, Row}

/**
  *
  * @param io
  * Job that reads the multiple CSV files using configurations files provided by pipeline.conf and application.conf
  * Returns a map of dataframes in the form of:
  * Map(interface1 -> DataFrame,
  * interface2 -> DataFrame,
  * interfaceN -> DataFrame)
  */
class ConvertAcdToCsvJob(io: IO) extends MapJob[FileTransfer] {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    val sqlCtx = Contexts.sqlCtx
    val dfMap: Map[String, RDD[String]] = readAllTextFiles(pl.in)
    val mapRddCsv = dfMap.map(
      kv => kv._1 + ".NEW" -> formatToCsv(kv._2)
    )
    val paths = mapRddCsv.keys.toList
    writeTextFiles(mapRddCsv)
    deleteAndRenameFiles(paths)
    pl.map
  }
}

object ConvertAcdToCsvJob {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  def readAllTextFiles(paths: List[String]): Map[String, RDD[String]] = {
    val fs = FileSystem.get(Contexts.sc.hadoopConfiguration)
    (for (
      path <- paths;
      file <- fs.listStatus(new Path(path)).toList
    ) yield
      file.getPath.toString -> Contexts.sc.textFile(s"${path}/${file.getPath.getName}").coalesce(1)
      ).toMap
  }

  def writeTextFiles(mapRdd: Map[String, RDD[String]]): Unit = {
    mapRdd.foreach(pathRdd => pathRdd._2.saveAsTextFile(pathRdd._1))
  }

  def deleteAndRenameFiles(paths: List[String]): Unit = {
    // Instantiate HDFS Filesystem
    val fs = FileSystem.get(Contexts.sc.hadoopConfiguration)

    // Rename Spark output part-00000 to filename
    paths.foreach(
      path => fs.rename(
        new Path(s"${path}/part-00000"),
        new Path(s"${path}/${path.split("/").last.replaceAll(".NEW", "")}"))
    )

    // Create tmp Directory with old files
    val tmpDir = s"${paths(0).split("/").dropRight(1).mkString("/")}/OLD".replaceAll("landing", "archive")
    if(paths.nonEmpty) fs.mkdirs(new Path(s"${tmpDir}"))

    // Move files to tmp directory
    paths.foreach(
      path => {
        val fileName = path.split("/").last.replaceAll(".NEW", ".OLD")
        fs.rename(
        new Path(path.replaceAll(".NEW", "")),
        new Path(s"${tmpDir}/${fileName}"))}
    )

    // Move CSV files to directory
    paths.foreach(
      path => {
        val fileName = path.split("/").last.replaceAll(".NEW", "")
        val destDir = s"${paths(0).split("/").dropRight(1).mkString("/")}"
        fs.rename(
          new Path(s"${path}/${fileName}"),
          new Path(s"${destDir}/${fileName}"))}
    )

    // Delete .crc files and staging directory
    paths.foreach(
      path => {
        val destDir = s"${paths(0).split("/").dropRight(1).mkString("/")}"
        val fileName = "." + path.split("/").last.replaceAll(".NEW", ".crc")
        fs.delete(new Path(path), true)
        fs.delete(new Path(s"${destDir}/${fileName}"), true)
      }
    )
  }

  def formatToCsv(rdd: RDD[String]): RDD[String] = {
    val idPattern =  "^(.+?),".r
    val first: RDD[String] = Contexts.sc.parallelize(List(rdd.first))
    val rddNoHeader = filterHeader(rdd)
    val rddWithIds = broadcastCallId(rddNoHeader)
    val rddByKey = rddWithIds.keyBy(str => idPattern.findFirstMatchIn(str) match {
      case Some(s) => s.group(1)
      case None => "NoKey"
    }).groupByKey()

    val rddAsCsv = rddByKey.map(
      kv => kv._2
        .foldLeft(s"${kv._1},")(
          (acc, ele) => acc + ele.replaceAll(s"${kv._1},", "")
        ))

    (first union rddAsCsv).coalesce(1)
  }

  def broadcastCallId(rdd: RDD[String]): RDD[String] = {
    val noIdPattern = ("^(\\d{2}:\\d{2}:\\d{2}:).*").r
    val idPattern = "^(.+?),".r
    val acc = Contexts.sc.accumulator("")(StringAccumulatorParam)
    val result = rdd.map((row: String) => {
      (idPattern.findFirstMatchIn(row), noIdPattern.findFirstMatchIn(row)) match {
        case (Some(a), None) => {
          acc += (a.group(1))
          row
        }
        case (None, Some(b)) => s"${acc}, -> ${row}"
        case (Some(a), Some(b)) => s"${acc}, -> ${row}"
        case _ => row
      }
    })
    result.coalesce(1)
  }

  def filterHeader(rdd: RDD[String]): RDD[String] = {
    val first = rdd.first()
    val rddNoHeader = rdd.filter(str => !str.equals(first))
    rddNoHeader.coalesce(1)
  }


}

object StringAccumulatorParam extends AccumulatorParam[String] {

  override def zero(initialValue: String): String = {
    ""
  }

  override def addInPlace(s1: String, s2: String): String = {
    s2
  }
}


