package ie.esb.datalake.jobs.common

import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql._
import com.databricks.spark.avro._
import ie.esb.datalake.ingestion._
import org.apache.avro.generic.GenericData.StringType
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, DecimalType, DoubleType, IntegerType, LongType}
import org.joda.time.format.DateTimeFormat

/**
  * Created by Sabater_A on 13/10/2017.
  */
class WriteAvroToProcessJob1(datasource: String, basePath: String) extends MapJob[FileTransfer]{

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    for ((k: String, v: RddOrDf) <- pl.map) yield {
      val outPath = s"${basePath}/${datasource}/${k}/output"

      val newDF: RddOrDf = datasource match {
        case "abtran-acd_call_details" =>
          v.withColumn("CallId", v.col("CallId").cast(DataTypes.StringType))
            .withColumn("CallType", v.col("CallType").cast(DataTypes.StringType))
            .withColumn("CallDirection", v.col("CallDirection").cast(DataTypes.StringType))
            .withColumn("LineId", v.col("LineId").cast(DataTypes.StringType))
            .withColumn("LocalUserId", v.col("LocalUserId").cast(DataTypes.StringType))
            .withColumn("AssignedWorkGroup", v.col("AssignedWorkGroup").cast(DataTypes.StringType))
            .withColumn("RemoteNumberFmt", v.col("RemoteNumberFmt").cast(DataTypes.StringType))
            .withColumn("InitiatedDate", v.col("InitiatedDate").cast(DataTypes.StringType))
            .withColumn("InitiatedDateTimeGMT", v.col("InitiatedDateTimeGMT").cast(DataTypes.StringType))
            .withColumn("ConnectedDate", v.col("ConnectedDate").cast(DataTypes.StringType))
            .withColumn("ConnectedDateTimeGMT", v.col("ConnectedDateTimeGMT").cast(DataTypes.StringType))
            .withColumn("TerminatedDate", v.col("TerminatedDate").cast(DataTypes.StringType))
            .withColumn("TerminatedDateTimeGMT", v.col("TerminatedDateTimeGMT").cast(DataTypes.StringType))
            .withColumn("CallDurationSeconds", v.col("CallDurationSeconds").cast(DataTypes.StringType))
            .withColumn("HoldDurationSeconds", v.col("HoldDurationSeconds").cast(DataTypes.StringType))
            .withColumn("LineDurationSeconds", v.col("LineDurationSeconds").cast(DataTypes.StringType))
            .withColumn("DNIS", v.col("DNIS").cast(DataTypes.StringType))
            .withColumn("CallEventLog", v.col("CallEventLog").cast(DataTypes.StringType))
            .withColumn("I3TimeStampGMT", v.col("I3TimeStampGMT").cast(DataTypes.StringType))
            .withColumn("WrapUpCode", v.col("WrapUpCode").cast(DataTypes.StringType))
            .withColumn("tDialing", v.col("tDialing").cast(DataTypes.StringType))
            .withColumn("tIVRWait", v.col("tIVRWait").cast(DataTypes.StringType))
            .withColumn("tQueueWait", v.col("tQueueWait").cast(DataTypes.StringType))
            .withColumn("tAlert", v.col("tAlert").cast(DataTypes.StringType))
            .withColumn("tSuspend", v.col("tSuspend").cast(DataTypes.StringType))
            .withColumn("tConference", v.col("tConference").cast(DataTypes.StringType))
            .withColumn("tExternal", v.col("tExternal").cast(DataTypes.StringType))
            .withColumn("tACW", v.col("tACW").cast(DataTypes.StringType))
            .withColumn("nIVR", v.col("nIVR").cast(DataTypes.StringType))
            .withColumn("nQueueWait", v.col("nQueueWait").cast(DataTypes.StringType))
            .withColumn("nTalk", v.col("nTalk").cast(DataTypes.StringType))
            .withColumn("nConference", v.col("nConference").cast(DataTypes.StringType))
            .withColumn("nHeld", v.col("nHeld").cast(DataTypes.StringType))
            .withColumn("nTransfer", v.col("nTransfer").cast(DataTypes.StringType))
            .withColumn("nExternal", v.col("nExternal").cast(DataTypes.StringType))

        
        case "siemens" => v.withColumn("DateTime", ExtractDateFromFilenameJob.udfBigIntStringFormat(col("DateTime"), lit("YYYYMMddHHmmsss"), lit("YYYY-MM-dd HH:mm:ss")))
        case "snipp" if v.columns.contains("createdate") =>  v.withColumn("createdate", v.col("createdate").cast(DataTypes.StringType))

        case "abtran" if (k.equalsIgnoreCase("ivr_call_log")) =>
            v.withColumn("DATE_CREATED", v.col("DATE_CREATED").cast(DataTypes.StringType)) 
              .withColumn("ANSWER_DATETIME", v.col("ANSWER_DATETIME").cast(DataTypes.StringType))
              .withColumn ("END_DATETIME", v.col ("END_DATETIME").cast (DataTypes.StringType) )
              .withColumn ("START_DATETIME", v.col ("START_DATETIME").cast (DataTypes.StringType))
            // .withColumn("CALL_LOG_ID", expr("substring(CALL_LOG_ID, 2, length(CALL_LOG_ID) - 2)"))

        case "abtran" if (k.equalsIgnoreCase("ivr_option_log")) =>
                    v.withColumn ("STAGE_STARTTIME", v.col ("STAGE_STARTTIME").cast (DataTypes.StringType) )
                      .withColumn ("DATE_CREATED", v.col ("DATE_CREATED").cast (DataTypes.StringType) )


        case "ses/cylon" if (k.equalsIgnoreCase("cylondata")) =>
          v.withColumn("timestamp",  v.col ("timestamp").cast (DataTypes.StringType))
            .withColumn("node_id",  v.col ("node_id").cast (DataTypes.StringType))

        case "ses/cylon" if (k.equalsIgnoreCase("cylonmeta")) =>
          v.withColumn("node_id",  v.col ("node_id").cast (DataTypes.StringType))

        case "ses/enacto" if (k.equalsIgnoreCase("enactodata")) =>
            v.withColumn("SOURCE", lit("Honeywell"))
              .withColumn("timestamp", ExtractDateFromFilenameJob.udfSESDateFormat(col("timestamp"), lit("YYYY/MM/dd HH:mm"), lit("YYYY-MM-dd HH:mm:ss")))

        case "ses/enacto" if (k.equalsIgnoreCase("enactometa")) =>
            v.withColumn("meter_multiplier", v.col ("meter_multiplier").cast (DataTypes.createDecimalType(18,9)))


        case "ndd/nddhybris" if (k.equalsIgnoreCase("data")) =>
            v.withColumn("area_code", v.col ("area_code").cast (DataTypes.StringType))
            v.withColumn("phone_number", v.col ("phone_number").cast (DataTypes.StringType))
        case _ => v
      }
      newDF.write.mode(SaveMode.Overwrite).avro(outPath)
    }
    pl.map
  }
}