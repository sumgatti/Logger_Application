package ie.esb.datalake.jobs.common

import ie.esb.datalake.Schemas
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.DataFrame
import org.apache.spark.storage.StorageLevel
import ie.esb.datalake.jobs.common.ReadCsvJob._
import org.apache.spark.sql.types.StructType
//import ie.esb.datalake.spark.udfs.ImplicitConversions._

/**
  *
  * @param io
  * @param delimeter
  * @param enclosing
  * @param filenameIncluded
  * Job that reads the multiple CSV files using configurations files provided by pipeline.conf and application.conf
  * Returns a map of dataframes in the form of:
  * Map(interface1 -> DataFrame,
  * interface2 -> DataFrame,
  * interfaceN -> DataFrame)
  */
class ReadCsvJob(io: IO, delimeter: String = ",", enclosing: String = "\"", filenameIncluded: Boolean = true, fileExtension: String = ".csv") extends MapJob[FileTransfer] {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    val dfMap: Map[String, DataFrame] = (for {
    // For all the input paths found in the pipeline.conf file in the property file-transfer.files
    // each path is in the form of /landing/[DATASOURCE]/[INTERFACE]. e.g: /landing/ABTRAN/ivr_call_log
      path <- pl.in
    } yield {
      val interface = path.split("/").last
      log.info(s"The path to be read is: ${path}")
      log.info(s"The interface is: ${interface}")
      val schema = SelectSchema(interface)
      val int = io.readMultipleCsvToDf(path, delimeter, filenameIncluded, mode = "DROPMALFORMED", schema = schema, fileExtension = fileExtension)
        .repartition(10)
        .persist(StorageLevel.MEMORY_AND_DISK)


      interface -> trimColumns(int)
    }
      ).toMap.filter(kv => kv._2.count() != 0)

    //dfMap.head._2.dropColumns("myColumns")
    log.info(s"The number of loaded interfaces is: ${dfMap.size}");
    dfMap.map(kv => kv._1 -> Right(kv._2))
  }


  
}

object ReadCsvJob {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  def trimColumns(df: DataFrame): DataFrame = {
    val l = List("\\s", "/", "\\.", "\\(", "\\)","-")
    val trimDF = df.columns.foldLeft(df)((acc, elem) => acc.withColumnRenamed(elem, l.foldLeft(elem)((a, e) => a.replaceAll(e, ""))));
    trimDF

  }

  def SelectSchema(interface: String): Option[StructType] = {

    val libertyCustomers = List("industry_liberty_customers", "lifestyle_liberty_customers", "ni_liberty_customers")
    val libertyVends = List("industry_vends", "lifestyle_vends", "ni_vends")
    val siemens = List("gas_payg")
    val dialler = List("dialler")
    val abtranacdcalls = List("acd_call_details")
    val enactodata = List("enactodata")
    //val sapirpsrpeasts = List("easts")
    //val sapirpeabl = List("eabl")
    //val sapirpeastl = List("eastl")
    //val sapirpcrpbut050 = List("but050")
    //val sapcrpbut000 = List("crpbut000")
    //val sapirpsrpeideswtmsgdata = List("eideswtmsgdata")
    //val sapirpeideswtmsgdata = List("eideswtmsgdata")
    //val sapirpeideswtdoc = List("eideswtdoc")
   // val sapsrpeideswtdoc = List("srpeideswtdoc")
    //val sapirpeablg = List("eablg")
    log.info(s"Searching for schema for interface: ${interface}")
    interface match {
      case x if (libertyCustomers.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is LibertyCustomer"); Some(Schemas.libertyCustomer)}
      case x if (libertyVends.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is LibertyVends"); Some(Schemas.libertyVends)}
      case x if (dialler.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is ArvatoDialler"); Some(Schemas.arvatoDials)}
      case x if (siemens.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SIEMENS"); Some(Schemas.siemens)}
      case x if (abtranacdcalls.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is Abtran Acd Calls"); Some(Schemas.abtranacdcalls)}
      case x if (enactodata.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is Enacto Data"); Some(Schemas.enactodata)}
      //case x if (sapirpsrpeasts.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP/SRP - EASTS"); Some(Schemas.sarpsrpeasts)}
      //case x if (sapirpeabl.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP - EABL"); Some(Schemas.sapirpeabl)}
      //case x if (sapirpeastl.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP - EASTL"); Some(Schemas.sapirpeastl)}
      //case x if (sapirpcrpbut050.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP / CRP - BUT050"); Some(Schemas.sapirpcrpbut050)}
      //case x if (sapcrpbut000.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP CRP - BUT000"); Some(Schemas.sapcrpbut000)}
      //case x if (sapirpsrpeideswtmsgdata.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP SRP - EIDESWTMSGDATA"); Some(Schemas.sapirpsrpeideswtmsgdata)}
      //case x if (sapirpeideswtmsgdata.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP - EIDESWTMSGDATA"); Some(Schemas.sapirpeideswtmsgdata)}
      //case x if (sapirpeideswtdoc.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP - EIDESWTDOC"); Some(Schemas.sapirpeideswtdoc)}
      //case x if (sapirpeablg.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP IRP - EABLG"); Some(Schemas.sapirpeablg)}
      //case x if (sapsrpeideswtdoc.contains(x)) => {log.info(s"Schema found for ${interface}, The schema is SAP SRP - EIDESWTDOC"); Some(Schemas.sapsrpeideswtdoc)}
      case _ => {log.info("No Schema found, proceding without schema"); None}
    }
  }
}

