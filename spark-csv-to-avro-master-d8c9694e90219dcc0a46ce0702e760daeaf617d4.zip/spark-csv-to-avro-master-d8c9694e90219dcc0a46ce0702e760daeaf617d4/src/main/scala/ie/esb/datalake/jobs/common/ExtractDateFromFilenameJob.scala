package ie.esb.datalake.jobs.common

import com.typesafe.config.Config
import ie.esb.datalake.commons.LoadedProperties
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, MapJob, Pipeline}
import ie.esb.datalake.ingestion.{RddOrDf, _}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.joda.time.format.DateTimeFormat
import ie.esb.datalake.jobs.common.ExtractDateFromFilenameJob._

import scala.util.matching.Regex
import scala.util.{Failure, Success, Try}

/**
  * Created by Sabater_A on 11/09/2017.
  */
class ExtractDateFromFilenameJob(conf: Config = LoadedProperties.conf) extends MapJob[FileTransfer] {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  /**
    *
    * @param pl
    * @return
    * Job that Extracts the date from the filename column and creates ProcessedDate and CreatedDate
    */
  override def runMapped(pl: Pipeline[FileTransfer]): Map[String, RddOrDf] = {
    assert(pl.map.nonEmpty)
    //pl.jobs.head.
    val regexConf = "application.regex"
    val dateConf = "application.date-formats"
    val processedPattern = conf.getString(s"${regexConf}.processed-date")
    val createdPattern = conf.getString(s"${regexConf}.created-date")
    val processedDateInFormat = conf.getString(s"${dateConf}.processed-date-in")
    val processedDateOutFormat = conf.getString(s"${dateConf}.processed-date-out")
    val createDateInFormat = conf.getString(s"${dateConf}.created-date-in")
    val createDateOutFormat = conf.getString(s"${dateConf}.created-date-out")

    // Loop over the map of key value: (interface -> DataFrame)
    for ((k: String, v: RddOrDf) <- pl.map) yield {
      log.info(s"Adding ProcessedDate and CreatedDate to interface: ${k}")
      val df: DataFrame = v
      val dfResult = df
        .withColumn("ProcessedDateNoFormat", udfColumnFromRegex(col("filename"), lit(processedPattern)))
        .withColumn("CreatedDateNoFormat", udfColumnFromRegex(col("filename"), lit(createdPattern)))
        .withColumn("ProcessedDate", udfDateStringFormat(col("ProcessedDateNoFormat"), lit(processedDateInFormat), lit(processedDateOutFormat)))
        .withColumn("CreatedDate", udfDateStringFormat(col("CreatedDateNoFormat"), lit(createDateInFormat), lit(createDateOutFormat)))
        .drop("filename")
        .drop("ProcessedDateNoFormat")
        .drop("CreatedDateNoFormat")
      k -> Right(dfResult)
    }
  }
}

object ExtractDateFromFilenameJob {

  @transient lazy val log: Logger = LogManager.getLogger(getClass)

  val udfColumnFromRegex = udf[Option[String], String, String]((col: String, regex: String) => getRegex(col, regex))

  def getRegex(col: String, regex: String): Option[String] = {
    log.info(s"Searching for pattern: ${regex} in column: ${col}")
    regex match {
      case "" => None
      case _ => {
        val r: Regex = regex.r
        r.findFirstMatchIn(col) match {
          case Some(m) => {
            log.info(s"Successful match found: ${m.group(1)}")
            Some(m.group(1))
          }
          case _ => {
            log.info(s"No match found pattern: ${regex} in column: ${col}")
            None
          }
        }
      }
    }
  }

  val udfDateStringFormat = udf[Option[String], String, String, String]((col: String, inFormat: String, outFormat: String) => dateStringFormat(col, inFormat, outFormat))

  def dateStringFormat(col: String, inFormat: String, outFormat: String): Option[String] = {
    val defaultOutFormatter = DateTimeFormat.forPattern("YYYY-MM-dd HH:mm:ss")
    val defaultInFormatter = DateTimeFormat.forPattern("YYYYMMdd")
    val inFormatter = Try(DateTimeFormat.forPattern(inFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultInFormatter
    }
    val outFormatter = Try(DateTimeFormat.forPattern(outFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultOutFormatter
    }
    val dt = Try(inFormatter.parseLocalDateTime(col)) match {
      case Success(s) => Some(s)
      case Failure(f) => None
    }

    dt match {
      case Some(s) => Try(s.toString(outFormatter)) match {
        case Success(s) => Some(s)
        case Failure(f) => None
      }
      case None => None
    }
  }

  val udfBigIntStringFormat = udf[Option[String], String, String, String]((col: String, inFormat: String, outFormat: String) => dateStringFormat(col, inFormat, outFormat))

  def dateBigIntStringFormat(col: String, inFormat: String, outFormat: String): Option[String] = {
    val defaultOutFormatter = DateTimeFormat.forPattern("YYYY-MM-dd HH:mm:ss")
    val defaultInFormatter = DateTimeFormat.forPattern("YYYYMMddHHmmss")
    val inFormatter = Try(DateTimeFormat.forPattern(inFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultInFormatter
    }
    val outFormatter = Try(DateTimeFormat.forPattern(outFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultOutFormatter
    }
    val dt = Try(inFormatter.parseLocalDateTime(col)) match {
      case Success(s) => Some(s)
      case Failure(f) => None
    }

    dt match {
      case Some(s) => Try(s.toString(outFormatter)) match {
        case Success(s) => Some(s)
        case Failure(f) => None
      }
      case None => None
    }
  }

  val udfSAPDSDateFormat = udf[Option[String], String, String, String]((col: String, inFormat: String, outFormat: String) => dateStringFormat(col, inFormat, outFormat))

  def udfSAPDSDateFormat(col: String, inFormat: String, outFormat: String): Option[String] = {
    val defaultOutFormatter = DateTimeFormat.forPattern("YYYY-MM-dd HH:mm:ss")
    val defaultInFormatter = DateTimeFormat.forPattern("YYYY.MM.dd")
    val inFormatter = Try(DateTimeFormat.forPattern(inFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultInFormatter
    }
    val outFormatter = Try(DateTimeFormat.forPattern(outFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultOutFormatter
    }
    val dt = Try(inFormatter.parseLocalDateTime(col)) match {
      case Success(s) => Some(s)
      case Failure(f) => None
    }

    dt match {
      case Some(s) => Try(s.toString(outFormatter)) match {
        case Success(s) => Some(s)
        case Failure(f) => None
      }
      case None => None
    }
  }


  val udfSESDateFormat = udf[Option[String], String, String, String]((col: String, inFormat: String, outFormat: String) => dateStringFormat(col, inFormat, outFormat))

  def udfSESDateFormat(col: String, inFormat: String, outFormat: String): Option[String] = {
    val defaultOutFormatter = DateTimeFormat.forPattern("YYYY-MM-dd HH:mm:ss")
    val defaultInFormatter = DateTimeFormat.forPattern("YYYY/MM/dd HH:mm")
    val inFormatter = Try(DateTimeFormat.forPattern(inFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultInFormatter
    }
    val outFormatter = Try(DateTimeFormat.forPattern(outFormat)) match {
      case Success(s) => s
      case Failure(f) => defaultOutFormatter
    }
    val dt = Try(inFormatter.parseLocalDateTime(col)) match {
      case Success(s) => Some(s)
      case Failure(f) => None
    }

    dt match {
      case Some(s) => Try(s.toString(outFormatter)) match {
        case Success(s) => Some(s)
        case Failure(f) => None
      }
      case None => None
    }
  }
}
