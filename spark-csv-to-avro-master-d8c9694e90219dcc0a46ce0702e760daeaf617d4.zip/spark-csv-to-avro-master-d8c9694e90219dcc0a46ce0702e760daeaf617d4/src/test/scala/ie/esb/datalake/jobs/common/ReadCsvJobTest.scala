package ie.esb.datalake.jobs.common

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import ie.esb.datalake.jobs.arvato.ReadExcelFileJob
import org.mockito.Mockito.{mock, _}
import org.scalatest.{FlatSpec, Matchers}
/**
  * Created by Sabater_A on 14/09/2017.
  */
class ReadCsvJobTest extends FlatSpec with Matchers{

  "runMapped" should "return a map of DataFrames" in {
    val files = List("interface_1","interface_2","interface_3","interface_4","interface_5")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ABTRAN/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result("interface_1").right.get.count() shouldEqual  12
    result.size shouldEqual 4
  }

  "runMapped" should "return a map dataframes when schema provided (acd_call_details)" in {
    val files = List("acd_call_details")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ABTRAN/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    //val df = result.get("acd_call_details").get.right.get
    //df.count shouldEqual 7298

  }


  "runMapped" should "return a map dataframes when schema provided (LibertyCustomer)" in {
    val files = List("industry_liberty_customers")
    val sources = files.map(str => getClass.getResource(s"/data/landing/LIBERTY/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("industry_liberty_customers").get.right.get
    df.count shouldEqual 2000

  }

  "runMapped" should "return a map dataframes when schema provided (LibertyVends)" in {
    val files = List("lifestyle_vends")
    val sources = files.map(str => getClass.getResource(s"/data/landing/LIBERTY/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("lifestyle_vends").get.right.get
    df.count shouldEqual 2000
  }
/*
  "runMapped" should "return a map dataframes when schema provided (SIEMENS)" in {
    val files = List("gas_payg")
    val sources = files.map(str => getClass.getResource(s"/data/landing/SIEMENS/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("gas_payg").get.right.get
    df.count shouldEqual 1020
  }
*/
  "runMapped" should "return a map dataframes for a .xls file" in {
    val files = List("dialler")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ARVATO/${str}").getPath)
      val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO, fileExtension = ".xls", delimeter = "\\t")

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result("dialler").right.get
    df.show
    df.count shouldEqual 1192
  }

  "ReadCsvJob" should "read data when empty directories" in {
    val files = List("interface_6")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ABTRAN/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)

    result.size shouldEqual 0
  }

  "trimColumns" should "trim the columns out of the column names" in {
    val df = Contexts.sqlCtx.createDataFrame(Seq((1,2,3), (1, 2, 3)))
      .toDF("Columns With Spaces 1", "ColumnWithNoSpaces", "(foo/bar.)")
    val dfResult = ReadCsvJob.trimColumns(df)
    dfResult.columns shouldEqual Array("ColumnsWithSpaces1","ColumnWithNoSpaces","foobar")
  }

  "runMapped" should "return a map of DataFrames for smart Payg" in {
    val files = List("interface_1")
    val sources = files.map(str => getClass.getResource(s"/data/landing/SMARTPAYG/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result("interface_1").right.get.count() shouldEqual  20956
    result.size shouldEqual 1
  }

 /* "runMapped" should "return a map dataframes when schema provided (easts)" in {
    val files = List("easts")
    val sources = files.map(str => getClass.getResource(s"/data/landing/SAP/IRP/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("easts").get.right.get
    df.count shouldEqual 1
  } */
/*
  "runMapped" should "return a map dataframes when schema provided (but050)" in {
    val files = List("but050")
    val sources = files.map(str => getClass.getResource(s"/data/landing/SAP/IRP/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("but050").get.right.get
    df.count shouldEqual 161224
  }
*/
/*
  "runMapped" should "return a map dataframes when schema provided (srpeideswtmsgdata)" in {
    val files = List("srpeideswtmsgdata")
    val sources = files.map(str => getClass.getResource(s"/data/landing/SAP/SRP/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadCsvJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    val df = result.get("srpeideswtmsgdata").get.right.get
    df.count shouldEqual 2000
  }
*/
}
