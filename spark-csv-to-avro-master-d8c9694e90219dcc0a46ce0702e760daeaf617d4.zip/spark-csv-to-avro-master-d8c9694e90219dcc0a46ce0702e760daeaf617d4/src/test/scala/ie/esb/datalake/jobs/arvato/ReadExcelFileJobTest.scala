package ie.esb.datalake.jobs.arvato

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import ie.esb.datalake.jobs.common.ReadCsvJob
import org.mockito.Mockito.{mock, when}
import org.scalatest.{FlatSpec, Matchers}


/**
  * Created by Sabater_A on 23/10/2017.
  */
class ReadExcelFileJobTest extends FlatSpec with Matchers {

  "ReadExcelFileJob" should "read a excel sheet" in {

    val files = List("avt_closed")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ARVATO/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources

    val job = new ReadExcelFileJob(new IO)

    val result: Map[String, RddOrDf] = job.runMapped(plMock)
    result("avt_closed").right.get.count() shouldEqual 2343
    result.size shouldEqual 1
  }

}
