package ie.esb.datalake.jobs.abtran

import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.RddOrDf
import ie.esb.datalake.ingestion.jobs.io.IO
import ie.esb.datalake.ingestion.pipeline.{FileTransfer, Pipeline}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.mockito.Mockito.{mock, when}
import org.scalatest.{FlatSpec, Matchers}

import scala.util.Random

/**
  * Created by Sabater_A on 17/10/2017.
  */
class ConvertAcdToCsvJobTest  extends FlatSpec with Matchers {

  "acd_call_details" should "converted to a real .csv file" in {
    val files = List("acd_call_details")
    val sources = files.map(str => getClass.getResource(s"/data/landing/ABTRAN/${str}").getPath)
    val plMock: Pipeline[FileTransfer] = mock(classOf[Pipeline[FileTransfer]])

    when(plMock.in) thenReturn sources
    val job = new ConvertAcdToCsvJob(new IO)

    val result = job.runMapped(plMock)
  }

  "filterHeader" should "Filter the header of an RDD[String]" in {
    val rdd: RDD[String] = Contexts.sc.parallelize(List("headers", "othersContent"))
    val rddResult = ConvertAcdToCsvJob.filterHeader(rdd)
    rddResult.collect()(0) shouldEqual "othersContent"
  }

  "broadcastCallId" should "broadcast Call Id in the rdd" in {
    val file = getClass.getResource(s"/data/landing/ABTRAN/acd_call_details/2018-01-08_acd_call_details_20180106.csv").getPath
    val rdd = Contexts.sc.textFile(file)

    val rddResult: RDD[String] = ConvertAcdToCsvJob.broadcastCallId(rdd)
    val rddNoHeader = ConvertAcdToCsvJob.filterHeader(rddResult)


    val idPattern = "^(\\d{10}.{1}\\d{7}),".r
    rddNoHeader.map(str => idPattern.findFirstMatchIn(str) match {
      case Some(s) => true
      case None => false
    }).collect().forall(bool => bool) shouldEqual true
  }

  "moveAndRename" should "move old CSV files to archive folder and rename and move new csv files" in {
    val files = List("2017-10-16_acd_call_details_20171015.csv.NEW", "2017-10-17_acd_call_details_20171016.csv.NEW", "2017-10-18_acd_call_details_20171017.csv.NEW")
    val paths = files.map(str => getClass.getResource("/data/move-rename/landing/interface").getPath + "/" + str)
    val fs = FileSystem.get(Contexts.sc.hadoopConfiguration)

    ConvertAcdToCsvJob.deleteAndRenameFiles(paths)

    val newFiles = fs.listStatus(new Path(getClass.getResource("/data/move-rename/landing/interface").getPath)).toList
    val oldFiles = fs.listStatus(new Path(getClass.getResource("/data/move-rename/archive/interface/OLD").getPath)).toList

    newFiles.size shouldEqual 3
    oldFiles.size shouldEqual 3
  }

  "getDataFrame" should "get dataframe with Ids" in {
    val file1 = getClass.getResource(s"/data/landing/ABTRAN/acd_call_details/2018-01-08_acd_call_details_20180106.csv").getPath
    val file2 = getClass.getResource(s"/data/landing/ABTRAN/acd_call_details/2018-01-08_acd_call_details_20180106.csv").getPath
    val file3 = getClass.getResource(s"/data/landing/ABTRAN/acd_call_details/2018-01-08_acd_call_details_20180106.csv").getPath
    val rdd1 = Contexts.sc.textFile(file1)
    val rdd2 = Contexts.sc.textFile(file2)
    val rdd3 = Contexts.sc.textFile(file3)

    val rddResult1 = ConvertAcdToCsvJob.formatToCsv(rdd1)
    val rddResult2 = ConvertAcdToCsvJob.formatToCsv(rdd2)
    val rddResult3 = ConvertAcdToCsvJob.formatToCsv(rdd3)

    rddResult1.count shouldEqual 1975
    rddResult2.count shouldEqual 1975
    rddResult3.count shouldEqual 1975
  }


  "AccumulatorTest" should "Replace the value of the accumulator" in {
    val stringAccum = Contexts.sc.accumulator("myValue")(StringAccumulatorParam)
    val expectedResult = "other"
    val rdd = Contexts.sc.parallelize("foo" :: "bar" :: "other" :: Nil)
    rdd.foreach(s => stringAccum+=(s))
    stringAccum.toString() shouldEqual expectedResult
  }

}
