package ie.esb.datalake.jobs.common

import com.databricks.spark.avro._
import ie.esb.datalake.commons.Contexts
import ie.esb.datalake.ingestion.mocking.PipelineMock
import ie.esb.datalake.ingestion.pipeline.FileTransfer
import org.scalatest.{FlatSpec, Matchers}

/**
  * Created by Sabater_A on 13/10/2017.
  */
class WriteAvroToProcessJobTest extends FlatSpec with Matchers {
/*
  val dfAbtran = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-12", "20160103"),
    (1,1,"2017-01-12", "20160103")
  )).toDF("CallId","col2","ProcessedDate", "CreatedDate")

  val dfAbtran1 = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160102"),
    (1,1,"2017-01-08", "20160102"),
    (1,1,"2017-01-07", "20160103"),
    (1,1,"2017-01-06", "20160103")
  )).toDF("CallId","col2","ProcessedDate", "CreatedDate")

  "runMapped" should "write dataframes into process area" in {
    val (plMock, _) = PipelineMock.pipeline[FileTransfer](Seq(Right(dfAbtran),Right(dfAbtran1)), "ABTRAN", Seq("int_1","int_2"))
    val job = new WriteAvroToProcessJob("abtran", getClass.getResource("/data/landing/ABTRAN/process").getPath)

    job.runMapped(plMock)

    val expectedResult = Contexts.sqlCtx.read.avro(getClass.getResource("/data/landing/ABTRAN/process/abtran-acd_call_details/int_1/output").getPath)
    val expectedResult1 = Contexts.sqlCtx.read.avro(getClass.getResource("/data/landing/ABTRAN/process/abtran-acd_call_details/int_2/output").getPath)
    dfAbtran.columns shouldEqual expectedResult.columns
    dfAbtran1.columns shouldEqual expectedResult1.columns
  }
*/
  val dfSiemens = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-10", "20160101"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-11", "20160102"),
    (1,1,"2017-01-12", "20160103"),
    (1,1,"2017-01-12", "20160103")
  )).toDF("CallId","col2","ProcessedDate", "DateTime")

  val dfSiemens1 = Contexts.sqlCtx.createDataFrame(Seq(
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160101"),
    (1,1,"2017-01-09", "20160102"),
    (1,1,"2017-01-08", "20160102"),
    (1,1,"2017-01-07", "20160103"),
    (1,1,"2017-01-06", "20160103")
  )).toDF("CallId","col2","ProcessedDate", "DateTime")

  "runMapped" should "write dataframes into process area for siemens" in {
    val (plMock, _) = PipelineMock.pipeline[FileTransfer](Seq(Right(dfSiemens),Right(dfSiemens)), "SIEMENS", Seq("int_1","int_2"))
    val job = new WriteAvroToProcessJob("siemens", getClass.getResource("/data/landing/SIEMENS/process").getPath)

    job.runMapped(plMock)

    val expectedResult = Contexts.sqlCtx.read.avro(getClass.getResource("/data/landing/SIEMENS/process/siemens/int_1/output").getPath)
    val expectedResult1 = Contexts.sqlCtx.read.avro(getClass.getResource("/data/landing/SIEMENS/process/siemens/int_2/output").getPath)
    dfSiemens.columns shouldEqual expectedResult.columns
    dfSiemens1.columns shouldEqual expectedResult1.columns
  }
}
