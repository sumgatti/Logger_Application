package ie.esb.datalake

import java.sql.{Connection, DriverManager, ResultSet}

import ie.esb.datalake.commons.{Contexts, LoadedProperties}
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.types._

import scala.collection.mutable.ListBuffer

case class JdbcConnector(username: String, password: String, url: String) {

  val conf = LoadedProperties.conf
  var connection: Connection = _
  val driver = conf.getString("application.cmdm.driver")

  def getConnection(): Connection = {
    try {
      Class.forName(driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
      connection
    }
    catch {
      case e: Exception => {
        e.printStackTrace;
        connection
      }
    }
  }

  def getCountDataFrame(query: String, column: String, lowerBound: String, upperBound: String): DataFrame = {
    val connection = getConnection()
    val resultQuery = StringOperations.finalQuery(query, column, upperBound, lowerBound)
    val resultList: List[Row] = try {
      val statement = connection.createStatement()
      val resultSet: ResultSet = statement.executeQuery(resultQuery)
      parseCountResults(resultSet)
    }
    catch {
      case e => e.printStackTrace
        List[Row]()
    }
    createDataFrameFromList(resultList)
  }

  def createDataFrameFromList(l: List[Row]): DataFrame = {
    val schema = StructType(Array(
      StructField("year", IntegerType, true),
      StructField("month", IntegerType, true),
      StructField("day", IntegerType, true),
      StructField("count", IntegerType, true)
    ))
    Contexts.sqlCtx.createDataFrame(Contexts.sc.parallelize(l), schema)
  }

  def parseCountResults(result: ResultSet): List[Row] = {
    var counts = new ListBuffer[Row]()
    while (result.next) {
      val year = result.getInt("year")
      val month = result.getInt("month")
      val day = result.getInt("day")
      val count = result.getInt("count")
      counts += Row(year, month, day, count)
    }
    counts.toList
  }
}

object Helper {

  case class countJDBC(year: Int, month: Int, day: Int, count: Int)

}
