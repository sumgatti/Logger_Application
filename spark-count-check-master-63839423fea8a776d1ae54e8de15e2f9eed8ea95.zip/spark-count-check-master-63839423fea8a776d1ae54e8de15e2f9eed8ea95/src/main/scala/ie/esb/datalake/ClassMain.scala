package ie.esb.datalake

import ie.esb.datalake.commons.{Contexts, LoadedProperties}
import org.apache.spark.sql.SaveMode

object ClassMain {
  def main(args: Array[String]): Unit = {

    execute(args)
  }

  def execute(args: Array[String]): Unit = {
    val query = args(0)
    val column = args(1)
    val upperBound = args(2)
    val lowerBound = args(3)
    val path = args(4)
    val user = LoadedProperties.conf.getString("application.cmdm.username")
    val pass = LoadedProperties.conf.getString("application.cmdm.password")
    val url = LoadedProperties.conf.getString("application.cmdm.url")

    val jdbcConnection = JdbcConnector(user,pass,url)
    val df = jdbcConnection.getCountDataFrame(query,column,lowerBound,upperBound)
    df.show
    df.coalesce(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("header", "true").save(path)
    df
    // WRITE DATAFRAME
  }
}
