package ie.esb.datalake

import org.apache.spark.sql.SQLContext

object SparkFunctions {

  def groupby_col(tableName: String, Col_name: String, sqlCtx: SQLContext): Unit = {
    sqlCtx.sql(s"SELECT * FROM ${tableName} GROUP BY ${Col_name}").registerTempTable("myNewTable")



  }

}
