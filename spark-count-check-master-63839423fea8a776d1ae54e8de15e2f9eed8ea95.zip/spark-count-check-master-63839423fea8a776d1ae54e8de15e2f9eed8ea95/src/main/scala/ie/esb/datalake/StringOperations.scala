package ie.esb.datalake

object StringOperations {

  def finalQuery(query: String, column: String, upperBound: String, lowerBound: String) : String = {
    val getSelectClause = addSelectClause(query, column)
    val whereClause = s") xyz WHERE xyz.${column} >= '${lowerBound}' AND xyz.${column} < '${upperBound}'"
    val addWhereClause = getSelectClause.concat(whereClause)
    val getGroupByClause1 = getGroupByClause(column)
    val addGroupByClause = addWhereClause.concat(getGroupByClause1)
    val finalQuery = addGroupByClause
    finalQuery
  }

  /*def addWhereClause(query: String, column: String, upperBound: String, lowerBound: String): String = {
    val whereClause = s")xyz WHERE xyz.${column} >= '${lowerBound}' AND xyz.${column} < '${upperBound}'"
    val whereClauseAdded = query.concat(whereClause)
    whereClauseAdded
  }*/

  def addSelectClause(query: String, column: String): String = {
    val selectClause = s"SELECT YEAR(${column}) as year, MONTH(${column}) as month, DAY(${column}) as day, COUNT(*) as count FROM ("
    val selectClauseAdded = selectClause.concat(query)
    selectClauseAdded
  }

  /*def addGroupByClause(query: String, column: String): String = {
    val groupByClause = s" GROUP BY YEAR(${column}), MONTH(${column}), DAY(${column})"
    val groupByAdded = query.concat(groupByClause)
    groupByAdded
    }*/


  def getGroupByClause(filterColumn: String): String = {
    val year = getDesiredDate(filterColumn, "YEAR")
    val month = getDesiredDate(filterColumn, "MONTH")
    val day = getDesiredDate(filterColumn, "DAY")
    val groupClause = s" GROUP BY $year, $month, $day"
    groupClause
  }

  def getSelectClause(filterColumn: String): String = {
    val year = s"${getDesiredDate(filterColumn, "YEAR")} as year"
    val month = s"${getDesiredDate(filterColumn, "MONTH")} as month"
    val day = s"${getDesiredDate(filterColumn, "DAY")} as day"
    val count = s"COUNT(*)"
    s" ${year}, ${month}, ${day}, ${count} as count "
  }

  def getDesiredDate(columnDate: String, desired: String): String = {
    desired match {
      case "YEAR" => s"YEAR(${columnDate})"
      case "MONTH" => s"MONTH(${columnDate})"
      case "DAY" => s"DAY(${columnDate})"
      case _ => ""
    }
  }
}
