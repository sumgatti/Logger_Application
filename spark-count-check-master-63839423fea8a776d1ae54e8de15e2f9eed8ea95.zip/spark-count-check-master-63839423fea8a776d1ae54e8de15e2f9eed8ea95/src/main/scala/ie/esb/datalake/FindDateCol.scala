package ie.esb.datalake

import org.apache.spark.sql.SQLContext

object FindDateCol {
  def Date_col(tableName: String, ColName: String, sqlCtx: SQLContext): Unit = {

   sqlCtx.sql(s"SELECT ${ColName} FROM ${tableName}").registerTempTable("myNewTable1")

    /*sqlCtx.sql(s"SELECT COUNT(${ColName}) FROM ${tableName}").registerTempTable("myNewTable1")*/
  }

}

