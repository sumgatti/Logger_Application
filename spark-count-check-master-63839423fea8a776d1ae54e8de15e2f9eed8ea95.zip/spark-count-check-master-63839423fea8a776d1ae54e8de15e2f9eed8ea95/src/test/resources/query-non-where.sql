SELECT lead.[LeadGUID]
	  ,bp_emp.BusinessPartnerNo as EmployeeBP
      ,lead.[EmployeeResponsibleSID]
	  ,org.OrganizationalUnit as OrgUnitCode
	  ,org.MediumDescription as OrgUnit
	  ,d1.DayDate as CalendarDay
	  ,d2.DayDate as ChangedDate
      ,lead.[ChangedBy]
	  ,d3.DayDate as CreatedDate
      ,lead.[CreatedBy]
      ,lead.[Description]
      ,lead.[LeadDuration]
      ,lead.[ExpectedLeadDuration]
      ,lead.[NumberOfLeadsWon]
      ,lead.[CRMMarketingElement]
      ,lead.[NumberActivities]
      ,lead.[NumberChanges]
	  ,st_tr.Code as TransactionCode
	  ,st_tr.Description as TransactionType
      ,lead.[TransactionNumber]
      ,lead.[Prospect]
	  ,st_dc.[Code] as DistributionCode
      ,st_dc.[Description] as DistributionChannel
      ,lead.[Division]
      ,lead.[SourceSystem]
	  ,st_st.Code as LeadStatusCode
	  ,st_st.Description as LeadStatus
	  ,st_ist.[Code] as IncorrectStatusCode
      ,st_ist.[Description] as IncorrectStatus
	  ,d4.DayDate as LeadStatusSinceDate
	  ,d5.DayDate as Date
	  ,st_us.UserStatus as StatusCode
	  ,st_us.LongDescription as Status
	  ,st_pr.ProductCode
	  ,st_pr.ProductDescription as Product
	  ,st_cs.[Code] as CurrentSupplierCode
      ,st_cs.[Description] as CurrentSupplier FROM [DM_ESB_ELECTRICIRELAND].[DWH].[FactCRMLead] lead
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimBusinessPartner] bp_emp
	on lead.[EmployeeResponsibleSID] = bp_emp.BusinessPartnerSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimOrganization] org
	on lead.ResponsibleOrganisationSID = org.OrganizationSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d1
	on lead.[CalendarDaySID] = d1.DateSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d2
	on lead.[ChangeDateSID] = d2.DateSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d3
	on lead.[CreationDateSID] = d3.DateSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatBusTransType] st_tr
	on lead.TransactionTypeSID = st_tr.BusTransTypeSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatDistributionChannel] st_dc
	on lead.DistributionChannelSID = st_dc.DistributionChannelSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatLeadStatus] st_st
	on lead.StatusSID = st_st.LeadStatusSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatIncorrectStatus] st_ist
	on lead.IncorrectStatusSID = st_ist.IncorrectStatusSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d4
	on lead.[LeadStatusSinceDateSID] = d4.DateSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimDate] d5
	on lead.[LeadStatusSinceDateSID] = d5.DateSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatUserStatus] st_us
	on lead.UserStatusSID = st_us.UserStatusSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatProduct] st_pr
	on lead.ProductSID = st_pr.ProductSID
  join [DM_ESB_ELECTRICIRELAND].[DWH].[DimStatCurrentSupplier] st_cs
	on lead.CurrentSupplierSID = st_cs.CurrentSupplierSID