SELECT distinct
				CP.BusinessPartnerNumber,
				CP.ContractAccountNumber,
				prodev.ProfileDeviceMPRN,
				CP.BP_Name,
				Cp.BP_FirstName,
				cp.BP_LastName,
				cp.Move_In,
				cp.Move_Out,
				cp.RateCategoryCode,
				cp.Dunning_Procedure,
				start.StartDate,
				lastt.EndDate
 FROM virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactProfile_Device] prodev
 JOIN virtsql203s.[DM_ESB_ELECTRICIRELAND].SPSS.CurrentPosition CP
 on prodev.ProfileDeviceMPRN = CP.MPRN
 join virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactEvent_DataDevice] dev
  on prodev.ProfileDeviceServicePointNo = dev.EventDataServicePointNo
 join (select ProfileDeviceMPRN, min([ProfileDeviceStartTime]) as StartDate from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactProfile_Device] group by ProfileDeviceMPRN) start
 on start.ProfileDeviceMPRN = prodev.ProfileDeviceMPRN
 join (select ProfileDeviceMPRN, max([ProfileDeviceStartTime]) as EndDate from virtsql203s.[DM_ESB_ELECTRICIRELAND].[DWH].[FactProfile_Device] group by ProfileDeviceMPRN) lastt
  on lastt.ProfileDeviceMPRN = prodev.ProfileDeviceMPRN
 where CP.Move_Out >= getdate() and  cp.Move_In <=start.StartDate and (lastt.EndDate between DATEdiff(Day, 3, getdate()) and  DATEdiff(Day, 1, getdate()))