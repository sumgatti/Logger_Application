package ie.esb.datalake

import org.scalatest.{FlatSpec, Matchers}

/*import java.sql.ResultSet*/

import scala.io.Source

class StringOperationsTest extends FlatSpec with Matchers {

  val queryWhereClause = Source.fromFile(getClass.getResource("/query-where.sql").getPath).getLines.mkString
  val queryNonWhereClause = Source.fromFile(getClass.getResource("/query-non-where.sql").getPath).getLines.mkString
  val querySelectReplaced = Source.fromFile(getClass.getResource("/query-with-select-replaced.sql").getPath).getLines.mkString
  val queryGroupByAdded = Source.fromFile(getClass.getResource("/query-with-groupby.sql").getPath).getLines.mkString
  val queryWhereModified = Source.fromFile(getClass.getResource("/query-where-modified.sql").getPath).getLines.mkString
  val queryNonWhereModified = Source.fromFile(getClass.getResource("/query-non-where-modified.sql").getPath).getLines.mkString
  val queryNonWhereFinal = Source.fromFile(getClass.getResource("/query-non-where-final.sql").getPath).getLines.mkString
  val column = "myDateColumn"

  "Read Queries" should "be a string" in {
    println(queryWhereClause)
    println(queryNonWhereClause)
    queryWhereClause shouldBe an[String]
    queryNonWhereClause shouldBe an[String]
  }

  "getDesiredDate" should "return the desired date" in {
    val year = StringOperations.getDesiredDate(column, "YEAR")
    val month = StringOperations.getDesiredDate(column, "MONTH")
    val day = StringOperations.getDesiredDate(column, "DAY")
    val default = StringOperations.getDesiredDate(column, "INVALID")

    year shouldEqual s"YEAR(${column})"
    month shouldEqual s"MONTH(${column})"
    day shouldEqual s"DAY(${column})"
    default shouldEqual s""
  }

  "getSelectClause" should "return a select statement containing year, month and day" in {
    val expectedResult = s" YEAR($column) as year, MONTH($column) as month, DAY($column) as day, COUNT(*) as count "
    val result = StringOperations.getSelectClause(column)
    result shouldEqual expectedResult
  }

  "getGroupByClause" should "return a group by clause by year, month, day" in {
    val expectedResult = s" GROUP BY YEAR($column), MONTH($column), DAY($column)"
    val result = StringOperations.getGroupByClause(column)
    result shouldEqual expectedResult
  }

  "addSelectClause" should "replace columns of a query by year, month and day" in {
    val query = queryNonWhereClause
    val expectedResult = querySelectReplaced
    val result = StringOperations.addSelectClause(query, column)
    result shouldEqual expectedResult
  }

  /*"addGroupByClause" should "add group by clause in the query" in {
    val query = queryNonWhereClause
    val expectedResult = queryGroupByAdded
    val result = StringOperations.addGroupByClause(query, column)
    result shouldEqual expectedResult
  }*/

  /*"addWhereClause" should "add where clause in a query" in {
    val query = queryNonWhereClause
    val expectedResult = queryNonWhereModified
    val upperBound = "2017-02-01 00:00:00"
    val lowerBound = "2017-01-01 00:00:00"
    val result = StringOperations.addWhereClause(query, column, upperBound, lowerBound)
    result shouldEqual expectedResult
  }*/

  "finalQuery" should "get the final query" in {
    val query = queryNonWhereClause
    val expectedResult = queryNonWhereFinal
    val upperBound = "2017-02-01 00:00:00"
    val lowerBound = "2017-01-01 00:00:00"
    val result = StringOperations.finalQuery(query, column, upperBound, lowerBound)
    println(result)
    result shouldEqual expectedResult
  }
}

