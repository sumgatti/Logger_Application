package ie.esb.datalake

import ie.esb.datalake.commons.Contexts
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.scalatest.{FlatSpec, Matchers}

class ConnectionSparkTest extends FlatSpec with Matchers{

  ignore should "Group the dataset with respect to the address" in {

    val conf = new SparkConf()
      .setAppName("SparkMe Application")
      .setMaster("local")
    val sqlCtx = Contexts.sqlCtx
    import sqlCtx.implicits._

    val df = Seq(
      (1, "Kanika", "Sydney"),
      (9, "Chris", "Dublin"),
      (1, "Apoorva", "Sydney"),
      (6, "Elpida", "Sydney"),
      (1, "Roy", "Sydney")
      ).toDF("ID", "Name", "Address")
    df.registerTempTable("myTempTable")

    SparkFunctions.groupby_col("myTempTable", "Address", sqlCtx)

    sqlCtx.sql("SELECT * FROM myNewTable GROUP BY Address ORDER BY ID").show()

   /* import sqlContext.implicits._

    val df = Seq(
      (8, "bat"),
      (64, "mouse"),
      (-27, "horse")
    ).toDF("number", "word")
  df.show()
    df.registerTempTable("myTempTable")
    sqlContext.sql("SELECT * FROM myTempTable WHERE number > 0").show*/
  }
}



