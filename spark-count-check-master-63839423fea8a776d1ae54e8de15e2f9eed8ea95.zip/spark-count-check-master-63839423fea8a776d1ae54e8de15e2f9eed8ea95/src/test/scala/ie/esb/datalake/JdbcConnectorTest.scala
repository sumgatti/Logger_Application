package ie.esb.datalake

import java.sql.{Connection, DriverManager, ResultSet}

import ie.esb.datalake.commons.{Contexts, LoadedProperties}
import org.scalatest.{FlatSpec, Matchers}

import scala.collection.mutable.ListBuffer
import scala.io.Source

class JdbcConnectorTest extends FlatSpec with Matchers {

  val username = LoadedProperties.conf.getString("application.cmdm.username")
  val password = LoadedProperties.conf.getString("application.cmdm.password")
  val url = LoadedProperties.conf.getString("application.cmdm.url")
  val jdbcConnection = JdbcConnector(username, password, url)
  var connection: Connection = null

  "test" should "test" in {
    val queryNonWhereFinal = Source.fromFile(getClass.getResource("/query-where.sql").getPath).getLines.mkString

    val df = jdbcConnection.getCountDataFrame(queryNonWhereFinal, "StartDate", "2017-02-01 00:00:00", "2017-01-01 00:00:00")

    df.show
  }

  "JdbcConnector" should "be able to be instantiated" in {
    jdbcConnection.username shouldEqual "hapdoop_read"
    jdbcConnection.password shouldEqual "Hap987$_pr0d"
    jdbcConnection.driver shouldEqual "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  }

  /*
  "Read Queries" should "be a string" in {
    val queryNonWhereFinal = Source.fromFile(getClass.getResource("/query-where.sql").getPath).getLines.mkString
    val resultQuery = StringOperations.finalQuery(queryNonWhereFinal, "StartDate", "2017-02-01 00:00:00", "2000-01-01 00:00:00")
    println(resultQuery)

    var counts = new ListBuffer[Blah.countJDBC]()

    try {
      connection = jdbcConnection.getConnection()
      import scala.collection.mutable.ListBuffer



      val statement = connection.createStatement()
      val resultSet: ResultSet = statement.executeQuery(resultQuery)

      while(resultSet.next) {
        val year = resultSet.getInt("year")
        val month = resultSet.getInt("month")
        val day = resultSet.getInt("day")
        val count = resultSet.getInt("count")
        counts += Blah.countJDBC(year, month, day, count)
      }
    }
    catch {
      case e => e.printStackTrace
    }
    val df = Contexts.sqlCtx.createDataFrame(Contexts.sc.parallelize(counts.toList))


    df.show
    connection.close()
  }

}*/
  object Blah {

    case class countJDBC(year: Int, month: Int, day: Int, count: Int)

  }

}
