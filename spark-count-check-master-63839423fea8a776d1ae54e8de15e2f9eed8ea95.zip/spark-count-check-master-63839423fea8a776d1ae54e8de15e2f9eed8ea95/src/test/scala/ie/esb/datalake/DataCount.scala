package ie.esb.datalake

import ie.esb.datalake.commons.Contexts
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.scalatest.{FlatSpec, Matchers}

class DataCount extends FlatSpec with Matchers {

    "Date_col" should "Find the date column " in {

      val conf = new SparkConf()
        .setAppName("SparkMe Application")
        .setMaster("local")
      val sqlCtx = Contexts.sqlCtx
      import sqlCtx.implicits._
      import sqlCtx.implicits._

      val df = Seq(
        (1, "2008-11-11 13:23:44", "Sydney"),
        (9, "2008-11-09 15:45:21", "Dublin"),
        (1, "2008-11-11 11:12:01", "Kolkata"),
        (6, "2008-10-25 14:56:59", "Sydney"),
        (6, "2008-10-29 20:45:35", "Dublin")
      ).toDF("ID", "Schedule", "Address")
      df.registerTempTable("myTempTable")

      FindDateCol.Date_col("myTempTable", "Schedule", sqlCtx)

      sqlCtx.sql("SELECT Schedule FROM myNewTable1").show()

      /*sqlContext.sql("SELECT COUNT(Schedule) FROM myNewTable1").show()

      sqlContext.sql("CREATE TABLE myNewTable2(year int, month int, day int)")
      sqlContext.sql("""INSERT INTO myNewTable2(year, month, day) SELECT DATEPART(year,Schedule), DATEPART(month,Schedule), DATEPART(day,Schedule) FROM myNewTable1""")
      sqlContext.sql("SELECT * FROM myNewTable2").show()*/
    }
}
