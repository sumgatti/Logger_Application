package ie.esb.datalake

import java.sql.{Connection, DriverManager, ResultSet}
import ie.esb.datalake.commons.{Contexts, LoadedProperties}
import scala.collection.mutable.ListBuffer
import org.scalatest.{FlatSpec, Matchers}
import com.databricks.spark.csv._
import scala.io.Source

class MainTest extends FlatSpec with Matchers {

  "run Main" should "test end to end program" in {
    val query = "SELECT * FROM mydates"
    val upperBound = "2017-01-01 00:00:00"
    val lowerBound = "2016-01-01 00:00:00"
    val column = "startDate"
    val path = "C:\\Users\\lghosh\\IdeaProjects\\ingestion-count\\myDataFrame"
    var args = Array[String](query, column, upperBound, lowerBound, path)
    println(args)
    val result = ClassMain.execute(args)
    result
  }
}


